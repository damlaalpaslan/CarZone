package com.ece.aractakip;



import android.content.Intent;

import android.os.Bundle;

import android.text.TextUtils;

import android.view.View;

import android.widget.ArrayAdapter;

import android.widget.Toast;



import androidx.activity.result.ActivityResultLauncher;

import androidx.activity.result.contract.ActivityResultContracts;

import androidx.annotation.NonNull;

import androidx.annotation.Nullable;

import androidx.appcompat.app.AppCompatActivity;



import com.bumptech.glide.Glide;

import com.ece.aractakip.data.AppPreferences;

import com.ece.aractakip.databinding.ActivityOnboardingBinding;

import com.ece.aractakip.model.UserProfile;

import com.ece.aractakip.model.VehicleModel;

import com.ece.aractakip.util.NumberInputFormatUtil;
import com.ece.aractakip.util.ThemeHelper;
import com.ece.aractakip.util.TurkishPhoneFormatter;
import com.ece.aractakip.util.TurkishTextInputHelper;

import com.google.android.material.textfield.TextInputEditText;



public class OnboardingActivity extends AppCompatActivity {



    private ActivityOnboardingBinding binding;

    @Nullable

    private String profilePhotoUri;

    @Nullable

    private String vehiclePhotoUri;

    private boolean pickingProfilePhoto;



    private final ActivityResultLauncher<String> pickImageLauncher =

            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {

                if (uri == null || binding == null) {

                    return;

                }

                String uriStr = uri.toString();

                if (pickingProfilePhoto) {

                    profilePhotoUri = uriStr;

                    binding.imageProfilePhoto.setVisibility(View.VISIBLE);

                    binding.imageProfilePlaceholder.setVisibility(View.GONE);

                    Glide.with(this).load(uri).centerCrop().into(binding.imageProfilePhoto);

                } else {

                    vehiclePhotoUri = uriStr;

                    binding.imageVehiclePhoto.setVisibility(View.VISIBLE);

                    binding.layoutVehiclePhotoPlaceholder.setVisibility(View.GONE);

                    Glide.with(this).load(uri).centerCrop().into(binding.imageVehiclePhoto);

                }

            });



    @Override

    protected void onCreate(Bundle savedInstanceState) {

        ThemeHelper.apply(this);

        super.onCreate(savedInstanceState);

        binding = ActivityOnboardingBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());



        setupFuelTypeDropdown();

        TurkishTextInputHelper.prepareNameField(binding.editFirstName);
        TurkishTextInputHelper.prepareNameField(binding.editLastName);
        TurkishPhoneFormatter.attach(binding.editPhone);
        NumberInputFormatUtil.attachGroupedInteger(binding.editCurrentKm);

        binding.frameProfilePhoto.setOnClickListener(v -> {

            pickingProfilePhoto = true;

            pickImageLauncher.launch("image/*");

        });

        binding.frameVehiclePhoto.setOnClickListener(v -> {

            pickingProfilePhoto = false;

            pickImageLauncher.launch("image/*");

        });

        binding.buttonComplete.setOnClickListener(v -> submit());

    }



    private void setupFuelTypeDropdown() {

        String[] fuels = getResources().getStringArray(R.array.fuel_types);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(

                this,

                android.R.layout.simple_dropdown_item_1line,

                fuels

        );

        binding.autoFuelType.setAdapter(adapter);

        if (fuels.length > 0) {

            binding.autoFuelType.setText(fuels[0], false);

        }

    }



    private void submit() {

        String firstName = textOrEmpty(binding.editFirstName);

        String lastName = textOrEmpty(binding.editLastName);

        String phoneDigits = TurkishPhoneFormatter.digitsOnly(textOrEmpty(binding.editPhone));

        String brand = textOrEmpty(binding.editBrand);

        String model = textOrEmpty(binding.editModel);

        String plate = textOrEmpty(binding.editPlate);



        if (TextUtils.isEmpty(firstName) || TextUtils.isEmpty(lastName) || phoneDigits.isEmpty()) {

            Toast.makeText(this, R.string.onboarding_error_profile, Toast.LENGTH_SHORT).show();

            return;

        }

        if (phoneDigits.length() < 10) {

            Toast.makeText(this, R.string.onboarding_error_profile, Toast.LENGTH_SHORT).show();

            return;

        }

        if (TextUtils.isEmpty(brand) || TextUtils.isEmpty(model) || TextUtils.isEmpty(plate)) {

            Toast.makeText(this, R.string.setup_error_required, Toast.LENGTH_SHORT).show();

            return;

        }



        int year = 0;

        String yearStr = textOrEmpty(binding.editYear);

        if (!yearStr.isEmpty()) {

            try {

                year = Integer.parseInt(yearStr);

            } catch (NumberFormatException e) {

                Toast.makeText(this, R.string.setup_error_year, Toast.LENGTH_SHORT).show();

                return;

            }

            if (year < 1900 || year > 2100) {

                Toast.makeText(this, R.string.setup_error_year, Toast.LENGTH_SHORT).show();

                return;

            }

        }



        int mileage = 0;

        String kmStr = textOrEmpty(binding.editCurrentKm);

        if (!kmStr.isEmpty()) {

            try {

                mileage = NumberInputFormatUtil.parseGroupedInteger(kmStr);

            } catch (NumberFormatException e) {

                Toast.makeText(this, R.string.onboarding_error_km, Toast.LENGTH_SHORT).show();

                return;

            }

            if (mileage < 0) {

                Toast.makeText(this, R.string.onboarding_error_km, Toast.LENGTH_SHORT).show();

                return;

            }

        }



        String fuel = binding.autoFuelType.getText() == null

                ? ""

                : binding.autoFuelType.getText().toString().trim();



        String fullName = (firstName + " " + lastName).trim();

        String phone = TurkishPhoneFormatter.formatDigits(phoneDigits);

        UserProfile profile = new UserProfile(profilePhotoUri, fullName, phone);

        VehicleModel vehicle = new VehicleModel(

                vehiclePhotoUri,

                brand,

                model,

                year,

                textOrEmpty(binding.editColor),

                plate,

                mileage,

                fuel

        );



        AppPreferences.completeOnboarding(this, profile, vehicle);



        Intent intent = new Intent(this, MainActivity.class);

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        startActivity(intent);

        finish();

    }



    @NonNull

    private static String textOrEmpty(@Nullable TextInputEditText editText) {

        if (editText == null || editText.getText() == null) {

            return "";

        }

        return editText.getText().toString().trim();

    }

}

