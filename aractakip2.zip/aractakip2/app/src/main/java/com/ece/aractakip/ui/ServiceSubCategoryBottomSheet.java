package com.ece.aractakip.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ece.aractakip.R;
import com.ece.aractakip.adapter.ServiceSubCategoryAdapter;
import com.ece.aractakip.databinding.BottomSheetServiceSubcategoryBinding;
import com.ece.aractakip.model.ServiceSubCategoryOption;
import com.ece.aractakip.util.ServiceSubCategoryCatalog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.List;

public class ServiceSubCategoryBottomSheet extends BottomSheetDialogFragment {

    private static final String ARG_CATEGORY = "arg_category";

    public interface SelectionListener {
        void onSubCategorySelected(@NonNull ServiceSubCategoryOption option);
    }

    @Nullable
    private BottomSheetServiceSubcategoryBinding binding;
    @Nullable
    private SelectionListener listener;

    public static ServiceSubCategoryBottomSheet newInstance(
            @NonNull ServiceSubCategoryCatalog.MainCategory category) {
        Bundle args = new Bundle();
        args.putString(ARG_CATEGORY, category.name());
        ServiceSubCategoryBottomSheet sheet = new ServiceSubCategoryBottomSheet();
        sheet.setArguments(args);
        return sheet;
    }

    public void setSelectionListener(@Nullable SelectionListener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = BottomSheetServiceSubcategoryBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }

        ServiceSubCategoryCatalog.MainCategory category = resolveCategory();
        List<ServiceSubCategoryOption> options =
                ServiceSubCategoryCatalog.optionsFor(requireContext(), category);

        ServiceSubCategoryAdapter adapter = new ServiceSubCategoryAdapter(
                LayoutInflater.from(requireContext()),
                option -> {
                    if (listener != null) {
                        listener.onSubCategorySelected(option);
                    }
                    dismiss();
                }
        );
        binding.recyclerSubCategoryOptions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerSubCategoryOptions.setAdapter(adapter);
        adapter.submitOptions(options);
    }

    @NonNull
    private ServiceSubCategoryCatalog.MainCategory resolveCategory() {
        String raw = getArguments() == null
                ? ServiceSubCategoryCatalog.MainCategory.PERIODIC.name()
                : getArguments().getString(ARG_CATEGORY, ServiceSubCategoryCatalog.MainCategory.PERIODIC.name());
        if (ServiceSubCategoryCatalog.MainCategory.REPAIR.name().equals(raw)) {
            return ServiceSubCategoryCatalog.MainCategory.REPAIR;
        }
        return ServiceSubCategoryCatalog.MainCategory.PERIODIC;
    }

    @Override
    public void onStart() {
        super.onStart();
        if (getDialog() != null) {
            View sheet = getDialog().findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (sheet != null) {
                sheet.setBackgroundResource(R.drawable.bg_bottom_sheet_rounded_top);
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
