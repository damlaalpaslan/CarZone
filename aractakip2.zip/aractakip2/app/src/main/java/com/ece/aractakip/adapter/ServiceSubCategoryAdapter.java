package com.ece.aractakip.adapter;

import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.ece.aractakip.databinding.ItemServiceSubcategoryOptionBinding;
import com.ece.aractakip.model.ServiceSubCategoryOption;

import java.util.ArrayList;
import java.util.List;

public class ServiceSubCategoryAdapter extends RecyclerView.Adapter<ServiceSubCategoryAdapter.OptionViewHolder> {

    public interface OptionClickListener {
        void onOptionSelected(@NonNull ServiceSubCategoryOption option);
    }

    private final LayoutInflater inflater;
    private final OptionClickListener listener;
    private final List<ServiceSubCategoryOption> options = new ArrayList<>();

    public ServiceSubCategoryAdapter(@NonNull LayoutInflater inflater,
                                     @NonNull OptionClickListener listener) {
        this.inflater = inflater;
        this.listener = listener;
    }

    public void submitOptions(@NonNull List<ServiceSubCategoryOption> items) {
        options.clear();
        options.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public OptionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemServiceSubcategoryOptionBinding binding =
                ItemServiceSubcategoryOptionBinding.inflate(inflater, parent, false);
        return new OptionViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull OptionViewHolder holder, int position) {
        ServiceSubCategoryOption option = options.get(position);
        holder.binding.textOptionLabel.setText(option.getLabel());
        holder.binding.imageOptionIcon.setImageResource(option.getIconRes());
        holder.binding.imageOptionIcon.setColorFilter(
                ContextCompat.getColor(holder.itemView.getContext(), option.getIconTintRes()));

        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(ContextCompat.getColor(holder.itemView.getContext(), option.getIconBackgroundRes()));
        holder.binding.frameOptionIcon.setBackground(circle);

        holder.itemView.setOnClickListener(v -> listener.onOptionSelected(option));
    }

    @Override
    public int getItemCount() {
        return options.size();
    }

    static class OptionViewHolder extends RecyclerView.ViewHolder {
        private final ItemServiceSubcategoryOptionBinding binding;

        OptionViewHolder(@NonNull ItemServiceSubcategoryOptionBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
