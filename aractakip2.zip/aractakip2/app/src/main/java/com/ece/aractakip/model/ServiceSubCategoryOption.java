package com.ece.aractakip.model;

import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;

public class ServiceSubCategoryOption {

    @NonNull
    private final String label;
    @DrawableRes
    private final int iconRes;
    @ColorRes
    private final int iconTintRes;
    @ColorRes
    private final int iconBackgroundRes;

    public ServiceSubCategoryOption(@NonNull String label,
                                    @DrawableRes int iconRes,
                                    @ColorRes int iconTintRes,
                                    @ColorRes int iconBackgroundRes) {
        this.label = label;
        this.iconRes = iconRes;
        this.iconTintRes = iconTintRes;
        this.iconBackgroundRes = iconBackgroundRes;
    }

    @NonNull
    public String getLabel() {
        return label;
    }

    @DrawableRes
    public int getIconRes() {
        return iconRes;
    }

    @ColorRes
    public int getIconTintRes() {
        return iconTintRes;
    }

    @ColorRes
    public int getIconBackgroundRes() {
        return iconBackgroundRes;
    }
}
