package com.ece.aractakip.model;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class DocumentEntry {

    public static final long UNLIMITED_EXPIRY_MS = Long.MAX_VALUE;

    public enum Type {
        VEHICLE_REGISTRATION,
        TRAFFIC_INSURANCE,
        CASCO,
        DRIVER_LICENSE,
        INSPECTION_EXHAUST,
        CUSTOM
    }

    private final long id;
    @NonNull
    private final Type type;
    @NonNull
    private final String title;
    @NonNull
    private final String documentNumber;
    private final long expiryDateMs;
    @Nullable
    private final String fileUri;

    public DocumentEntry(long id,
                         @NonNull Type type,
                         @NonNull String title,
                         @NonNull String documentNumber,
                         long expiryDateMs,
                         @Nullable String fileUri) {
        this.id = id;
        this.type = type;
        this.title = title;
        this.documentNumber = documentNumber;
        this.expiryDateMs = expiryDateMs;
        this.fileUri = fileUri;
    }

    public long getId() {
        return id;
    }

    @NonNull
    public Type getType() {
        return type;
    }

    @NonNull
    public String getTitle() {
        return title;
    }

    @NonNull
    public String getDocumentNumber() {
        return documentNumber;
    }

    public long getExpiryDateMs() {
        return expiryDateMs;
    }

    public boolean isUnlimitedExpiry() {
        return expiryDateMs == UNLIMITED_EXPIRY_MS;
    }

    @Nullable
    public String getFileUri() {
        return fileUri;
    }
}
