package com.ece.aractakip.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ece.aractakip.MainActivity;
import com.ece.aractakip.R;
import com.ece.aractakip.adapter.DocumentAdapter;
import com.ece.aractakip.data.AppPreferences;
import com.ece.aractakip.databinding.FragmentDocumentsBinding;
import com.ece.aractakip.model.DocumentEntry;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class DocumentsFragment extends Fragment {

    private static final int DIALOG_THEME = R.style.ThemeOverlay_Aractakip_AlertDialog;

    public interface DocumentsHost {
        void onCloseDocuments();
    }

    @Nullable
    private FragmentDocumentsBinding binding;
    private DocumentAdapter adapter;
    private final List<DocumentEntry> documents = new ArrayList<>();

    public static DocumentsFragment newInstance() {
        return new DocumentsFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentDocumentsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }

        adapter = new DocumentAdapter(requireContext());
        adapter.setDocumentClickListener(this::confirmDeleteDocument);
        binding.recyclerDocuments.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerDocuments.setAdapter(adapter);

        binding.buttonDocumentsBack.setOnClickListener(v -> closeScreen());
        binding.fabAddDocument.setOnClickListener(v -> showAddDocumentSheet());

        loadDocuments();
        renderScreen();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadDocuments();
        renderScreen();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void closeScreen() {
        if (requireActivity() instanceof DocumentsHost) {
            ((DocumentsHost) requireActivity()).onCloseDocuments();
        } else if (requireActivity() instanceof MainActivity) {
            requireActivity().getOnBackPressedDispatcher().onBackPressed();
        }
    }

    private void showAddDocumentSheet() {
        AddDocumentBottomSheet sheet = AddDocumentBottomSheet.newInstance();
        sheet.setDocumentFormListener(entry -> {
            AppPreferences.addDocument(requireContext(), entry);
            loadDocuments();
            renderScreen();
        });
        sheet.show(getParentFragmentManager(), "add_document");
    }

    private void confirmDeleteDocument(@NonNull DocumentEntry entry) {
        new MaterialAlertDialogBuilder(requireActivity(), DIALOG_THEME)
                .setMessage(getString(R.string.document_delete_message, entry.getTitle()))
                .setNegativeButton(R.string.stats_cancel, null)
                .setPositiveButton(R.string.action_delete, (dialog, which) -> {
                    AppPreferences.removeDocument(requireContext(), entry.getId());
                    loadDocuments();
                    renderScreen();
                    Toast.makeText(requireContext(), R.string.document_deleted, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void loadDocuments() {
        documents.clear();
        documents.addAll(AppPreferences.getDocuments(requireContext()));
        documents.sort(Comparator.comparingLong(DocumentEntry::getExpiryDateMs));
    }

    private void renderScreen() {
        if (binding == null) {
            return;
        }
        adapter.submitList(documents);
        updateEmptyState();
    }

    private void updateEmptyState() {
        if (binding == null) {
            return;
        }
        boolean isEmpty = documents.isEmpty();
        binding.layoutDocumentsEmpty.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        binding.recyclerDocuments.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
    }
}
