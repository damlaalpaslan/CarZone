package com.ece.aractakip.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ece.aractakip.databinding.BottomSheetStatsCategoryBinding;
import com.ece.aractakip.model.ExpenseEntry;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class StatsCategoryBottomSheet extends BottomSheetDialogFragment {

    public interface Listener {
        void onCategorySelected(@NonNull ExpenseEntry.Category category);
    }

    @Nullable
    private BottomSheetStatsCategoryBinding binding;
    @Nullable
    private Listener listener;

    public static StatsCategoryBottomSheet newInstance() {
        return new StatsCategoryBottomSheet();
    }

    public void setListener(@Nullable Listener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = BottomSheetStatsCategoryBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }
        binding.cardService.setOnClickListener(v -> select(ExpenseEntry.Category.SERVIS));
        binding.cardInsurance.setOnClickListener(v -> select(ExpenseEntry.Category.SIGORTA));
        binding.cardMaintenance.setOnClickListener(v -> select(ExpenseEntry.Category.BAKIM));
        binding.cardFuel.setOnClickListener(v -> select(ExpenseEntry.Category.YAKIT));
        binding.buttonCancel.setOnClickListener(v -> dismiss());
    }

    private void select(@NonNull ExpenseEntry.Category category) {
        if (listener != null) {
            listener.onCategorySelected(category);
        }
        dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
