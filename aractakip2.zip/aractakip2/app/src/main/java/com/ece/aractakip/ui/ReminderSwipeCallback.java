package com.ece.aractakip.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.ece.aractakip.R;
import com.ece.aractakip.adapter.ReminderSectionAdapter;
import com.ece.aractakip.model.Reminder;

public class ReminderSwipeCallback extends ItemTouchHelper.SimpleCallback {

    public interface DeleteListener {
        void onItemDeleted(@NonNull Reminder reminder);
    }

    private static final int TYPE_ITEM = ReminderSectionAdapter.TYPE_ITEM;

    private final ReminderSectionAdapter adapter;
    private final DeleteListener deleteListener;
    private final ColorDrawable background;
    private final Drawable deleteIcon;
    private final String deleteLabel;
    private final Paint textPaint;
    private final int actionWidthPx;
    private final int textGapPx;

    public ReminderSwipeCallback(@NonNull Context context,
                                 @NonNull ReminderSectionAdapter adapter,
                                 @NonNull DeleteListener deleteListener) {
        super(0, ItemTouchHelper.LEFT);
        this.adapter = adapter;
        this.deleteListener = deleteListener;
        background = new ColorDrawable(ContextCompat.getColor(context, R.color.service_accent_red));
        deleteIcon = ContextCompat.getDrawable(context, R.drawable.ic_delete_white);
        deleteLabel = context.getString(R.string.action_delete);
        float density = context.getResources().getDisplayMetrics().density;
        actionWidthPx = (int) (96f * density);
        textGapPx = (int) (6f * density);
        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(ContextCompat.getColor(context, android.R.color.white));
        textPaint.setTextSize(13f * density);
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    public int getMovementFlags(@NonNull RecyclerView recyclerView,
                                @NonNull RecyclerView.ViewHolder viewHolder) {
        if (viewHolder.getItemViewType() != TYPE_ITEM) {
            return makeMovementFlags(0, 0);
        }
        return makeMovementFlags(0, ItemTouchHelper.LEFT);
    }

    @Override
    public boolean onMove(@NonNull RecyclerView recyclerView,
                          @NonNull RecyclerView.ViewHolder viewHolder,
                          @NonNull RecyclerView.ViewHolder target) {
        return false;
    }

    @Override
    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
        int position = viewHolder.getBindingAdapterPosition();
        Reminder reminder = adapter.getReminderAt(position);
        if (reminder != null) {
            deleteListener.onItemDeleted(reminder);
        } else {
            adapter.notifyItemChanged(position);
        }
    }

    @Override
    public void onChildDraw(@NonNull Canvas canvas,
                            @NonNull RecyclerView recyclerView,
                            @NonNull RecyclerView.ViewHolder viewHolder,
                            float dX,
                            float dY,
                            int actionState,
                            boolean isCurrentlyActive) {
        if (dX < 0f && deleteIcon != null) {
            int top = viewHolder.itemView.getTop();
            int bottom = viewHolder.itemView.getBottom();
            int right = viewHolder.itemView.getRight();
            int left = right + (int) dX;

            background.setBounds(left, top, right, bottom);
            background.draw(canvas);

            float revealed = Math.min(-dX, actionWidthPx);
            float centerX = right - revealed / 2f;

            int iconSize = deleteIcon.getIntrinsicWidth();
            Rect textBounds = new Rect();
            textPaint.getTextBounds(deleteLabel, 0, deleteLabel.length(), textBounds);
            int blockHeight = iconSize + textGapPx + textBounds.height();
            int blockTop = top + (bottom - top - blockHeight) / 2;
            int iconLeft = (int) (centerX - iconSize / 2f);
            deleteIcon.setBounds(iconLeft, blockTop, iconLeft + iconSize, blockTop + iconSize);
            deleteIcon.draw(canvas);

            float textY = blockTop + iconSize + textGapPx + textBounds.height();
            canvas.drawText(deleteLabel, centerX, textY, textPaint);
        }
        super.onChildDraw(canvas, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
    }

    @Override
    public float getSwipeThreshold(@NonNull RecyclerView.ViewHolder viewHolder) {
        return 0.35f;
    }
}
