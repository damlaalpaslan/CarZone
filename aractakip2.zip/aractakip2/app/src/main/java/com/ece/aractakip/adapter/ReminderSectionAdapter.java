package com.ece.aractakip.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.ece.aractakip.R;
import com.ece.aractakip.databinding.ItemReminderCardBinding;
import com.ece.aractakip.databinding.ItemReminderSectionHeaderBinding;
import com.ece.aractakip.model.Reminder;
import com.ece.aractakip.util.DateInputUtils;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ReminderSectionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface ReminderActionListener {
        void onMarkAsDone(@NonNull Reminder reminder);

        void onEditReminder(@NonNull Reminder reminder);
    }

    private static final int TYPE_HEADER = 0;
    public static final int TYPE_ITEM = 1;

    public static class ReminderUiModel {
        @NonNull
        public final Reminder reminder;
        public final boolean criticalHighlight;
        @NonNull
        public final String dueText;
        public final boolean showProgress;
        public final int progressPercent;
        @NonNull
        public final String progressText;
        public final boolean completed;

        public ReminderUiModel(@NonNull Reminder reminder,
                               boolean criticalHighlight,
                               @NonNull String dueText,
                               boolean showProgress,
                               int progressPercent,
                               @NonNull String progressText,
                               boolean completed) {
            this.reminder = reminder;
            this.criticalHighlight = criticalHighlight;
            this.dueText = dueText;
            this.showProgress = showProgress;
            this.progressPercent = progressPercent;
            this.progressText = progressText;
            this.completed = completed;
        }
    }

    public static class RowItem {
        @NonNull
        final String headerTitle;
        final ReminderUiModel reminderUiModel;
        final int viewType;

        private RowItem(@NonNull String headerTitle) {
            this.headerTitle = headerTitle;
            this.reminderUiModel = null;
            this.viewType = TYPE_HEADER;
        }

        private RowItem(@NonNull ReminderUiModel reminderUiModel) {
            this.headerTitle = "";
            this.reminderUiModel = reminderUiModel;
            this.viewType = TYPE_ITEM;
        }
    }

    private static class HeaderViewHolder extends RecyclerView.ViewHolder {
        private final ItemReminderSectionHeaderBinding binding;

        HeaderViewHolder(@NonNull ItemReminderSectionHeaderBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    private static class ItemViewHolder extends RecyclerView.ViewHolder {
        private final ItemReminderCardBinding binding;

        ItemViewHolder(@NonNull ItemReminderCardBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    private final LayoutInflater inflater;
    private final ReminderActionListener actionListener;
    private final List<RowItem> rows = new ArrayList<>();

    public ReminderSectionAdapter(@NonNull Context context,
                                  @NonNull ReminderActionListener actionListener) {
        this.inflater = LayoutInflater.from(context);
        this.actionListener = actionListener;
    }

    public void submitRows(@NonNull List<RowItem> rowItems) {
        rows.clear();
        rows.addAll(rowItems);
        notifyDataSetChanged();
    }

    @Nullable
    public Reminder getReminderAt(int position) {
        if (position < 0 || position >= rows.size()) {
            return null;
        }
        RowItem row = rows.get(position);
        if (row.viewType != TYPE_ITEM || row.reminderUiModel == null) {
            return null;
        }
        return row.reminderUiModel.reminder;
    }

    public static RowItem header(@NonNull String title) {
        return new RowItem(title);
    }

    public static RowItem item(@NonNull ReminderUiModel uiModel) {
        return new RowItem(uiModel);
    }

    @Override
    public int getItemViewType(int position) {
        return rows.get(position).viewType;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_HEADER) {
            ItemReminderSectionHeaderBinding binding = ItemReminderSectionHeaderBinding.inflate(
                    inflater, parent, false);
            return new HeaderViewHolder(binding);
        }
        ItemReminderCardBinding binding = ItemReminderCardBinding.inflate(inflater, parent, false);
        return new ItemViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        RowItem row = rows.get(position);
        if (row.viewType == TYPE_HEADER) {
            HeaderViewHolder headerHolder = (HeaderViewHolder) holder;
            headerHolder.binding.textSectionHeader.setText(row.headerTitle);
            return;
        }

        ItemViewHolder itemHolder = (ItemViewHolder) holder;
        ReminderUiModel ui = row.reminderUiModel;
        if (ui == null) {
            return;
        }

        itemHolder.binding.textReminderTitle.setText(ui.reminder.getName());
        itemHolder.binding.textReminderSubtitle.setText(ui.dueText);

        if (ui.showProgress) {
            itemHolder.binding.layoutProgress.setVisibility(View.VISIBLE);
            itemHolder.binding.progressMaintenance.setProgress(ui.progressPercent);
            itemHolder.binding.textProgressLabel.setText(ui.progressText);
        } else {
            itemHolder.binding.layoutProgress.setVisibility(View.GONE);
        }

        int cardColor;
        if (ui.criticalHighlight
                || (!ui.completed && (ui.reminder.getCategory() == Reminder.Category.LEGAL
                || ui.reminder.getCategory() == Reminder.Category.TECHNICAL))) {
            cardColor = ContextCompat.getColor(itemHolder.itemView.getContext(), R.color.reminder_critical_bg);
        } else {
            cardColor = ContextCompat.getColor(itemHolder.itemView.getContext(), R.color.white);
        }
        itemHolder.binding.cardReminder.setCardBackgroundColor(cardColor);
        itemHolder.binding.cardReminder.setAlpha(ui.completed ? 0.58f : 1f);

        int indicatorColor = resolveCategoryColor(itemHolder.itemView.getContext(),
                ui.criticalHighlight ? Reminder.Category.CRITICAL : ui.reminder.getCategory());
        itemHolder.binding.viewCategoryIndicator.setBackgroundColor(indicatorColor);

        itemHolder.binding.buttonDone.setEnabled(!ui.completed);
        itemHolder.binding.buttonDone.setAlpha(ui.completed ? 0.5f : 1f);
        itemHolder.binding.buttonDone.setOnClickListener(v -> {
            if (!ui.completed) {
                actionListener.onMarkAsDone(ui.reminder);
            }
        });
        itemHolder.binding.buttonEdit.setOnClickListener(v -> actionListener.onEditReminder(ui.reminder));
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    public static int resolveCategoryColor(@NonNull Context context, @NonNull Reminder.Category category) {
        if (category == Reminder.Category.CRITICAL) {
            return ContextCompat.getColor(context, R.color.reminder_orange);
        } else if (category == Reminder.Category.LEGAL) {
            return ContextCompat.getColor(context, R.color.reminder_purple);
        }
        return ContextCompat.getColor(context, R.color.reminder_blue);
    }

    @NonNull
    public static String formatMileage(@NonNull Context context, int km) {
        NumberFormat nf = NumberFormat.getNumberInstance(new Locale("tr", "TR"));
        return context.getString(R.string.reminder_km_value, nf.format(km));
    }

    @NonNull
    public static String buildDateText(@NonNull Context context, long dueDateMs, long dayDiff) {
        String date = DateInputUtils.formatTurkishDate(dueDateMs);
        if (dayDiff < 0) {
            return context.getString(R.string.reminder_due_date_overdue, date, Math.abs(dayDiff));
        }
        return context.getString(R.string.reminder_due_date_left, date, dayDiff);
    }
}
