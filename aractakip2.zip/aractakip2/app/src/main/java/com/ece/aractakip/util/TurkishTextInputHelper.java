package com.ece.aractakip.util;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;
import android.text.InputType;
import android.text.method.TextKeyListener;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.NonNull;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Locale;

public final class TurkishTextInputHelper {

    private static final Locale TR = Locale.forLanguageTag("tr-TR");

    private TurkishTextInputHelper() {
    }

    public static void prepareNameField(@NonNull TextInputEditText editText) {
        editText.setRawInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editText.setKeyListener(TextKeyListener.getInstance(false, TextKeyListener.Capitalize.NONE));
        editText.setShowSoftInputOnFocus(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            editText.setImeHintLocales(new LocaleList(TR));
            editText.setTextLocale(TR);
        }
        editText.setOnFocusChangeListener((view, hasFocus) -> {
            if (hasFocus && hasPhysicalKeyboard(view.getContext())) {
                view.post(() -> showKeyboard(view));
            }
        });
    }

    private static boolean hasPhysicalKeyboard(@NonNull Context context) {
        return context.getResources().getConfiguration().keyboard != Configuration.KEYBOARD_NOKEYS;
    }

    private static void showKeyboard(@NonNull View view) {
        InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
        }
    }
}
