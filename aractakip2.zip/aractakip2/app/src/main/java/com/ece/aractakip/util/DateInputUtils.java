package com.ece.aractakip.util;

import androidx.annotation.NonNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public final class DateInputUtils {

    private static final SimpleDateFormat TR_DATE = new SimpleDateFormat("dd.MM.yyyy", new Locale("tr", "TR"));

    private DateInputUtils() {
    }

    /**
     * Parses dd.MM.yyyy into millis for that local calendar day. Empty → 0, invalid → -1.
     */
    @NonNull
    public static String formatTurkishDate(long localMillis) {
        if (localMillis <= 0) {
            return "";
        }
        synchronized (TR_DATE) {
            return TR_DATE.format(new Date(localMillis));
        }
    }

    public static long parseTurkishDateOrZero(@NonNull String raw) {
        String s = raw.trim();
        if (s.isEmpty()) {
            return 0L;
        }
        try {
            TR_DATE.setLenient(false);
            return TR_DATE.parse(s).getTime();
        } catch (ParseException e) {
            return -1L;
        }
    }

    public static long addYears(long localMillis, int years) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(localMillis);
        cal.add(Calendar.YEAR, years);
        return cal.getTimeInMillis();
    }

    /**
     * Full calendar days from today's local date to target's local date (midnight-based).
     */
    public static long fullDaysUntilLocalDate(long targetMillis) {
        Calendar today = Calendar.getInstance();
        stripToDate(today);
        Calendar target = Calendar.getInstance();
        target.setTimeInMillis(targetMillis);
        stripToDate(target);
        long diff = target.getTimeInMillis() - today.getTimeInMillis();
        return TimeUnit.MILLISECONDS.toDays(diff);
    }

    private static void stripToDate(Calendar c) {
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
    }
}
