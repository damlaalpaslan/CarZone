package com.ece.aractakip.data;

import android.content.Context;

import androidx.annotation.NonNull;

import com.ece.aractakip.model.AnomalyNotification;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class AnomalyNotificationRepository {

    private static final String PREFS = "anomaly_notifications_prefs";
    private static final String KEY_RECORDS = "records";
    private static final String FIELD_SEP = "|";
    private static final String RECORD_SEP = ";";
    private static final int MAX_RECORDS = 100;

    private AnomalyNotificationRepository() {
    }

    public static void add(@NonNull Context context, @NonNull String message) {
        String trimmed = message.trim();
        if (trimmed.isEmpty()) {
            return;
        }
        List<AnomalyNotification> all = getAll(context);
        all.add(0, new AnomalyNotification(
                System.currentTimeMillis(),
                trimmed,
                System.currentTimeMillis(),
                false
        ));
        if (all.size() > MAX_RECORDS) {
            all = new ArrayList<>(all.subList(0, MAX_RECORDS));
        }
        save(context, all);
    }

    @NonNull
    public static List<AnomalyNotification> getAll(@NonNull Context context) {
        String raw = prefs(context).getString(KEY_RECORDS, "");
        List<AnomalyNotification> list = new ArrayList<>();
        if (raw == null || raw.isEmpty()) {
            return list;
        }
        String[] rows = raw.split(RECORD_SEP, -1);
        for (String row : rows) {
            if (row.isEmpty()) {
                continue;
            }
            String[] parts = row.split("\\|", -1);
            if (parts.length != 4) {
                continue;
            }
            try {
                list.add(new AnomalyNotification(
                        Long.parseLong(parts[0]),
                        unescape(parts[1]),
                        Long.parseLong(parts[2]),
                        "1".equals(parts[3])
                ));
            } catch (Exception ignored) {
            }
        }
        list.sort(Comparator.comparingLong(AnomalyNotification::getTimestampMs).reversed());
        return list;
    }

    public static int getUnreadCount(@NonNull Context context) {
        int count = 0;
        for (AnomalyNotification item : getAll(context)) {
            if (!item.isRead()) {
                count++;
            }
        }
        return count;
    }

    public static void markAllRead(@NonNull Context context) {
        List<AnomalyNotification> updated = new ArrayList<>();
        for (AnomalyNotification item : getAll(context)) {
            updated.add(item.isRead() ? item : item.asRead());
        }
        save(context, updated);
    }

    public static void clearAll(@NonNull Context context) {
        prefs(context).edit().remove(KEY_RECORDS).apply();
    }

    public static void delete(@NonNull Context context, long id) {
        List<AnomalyNotification> updated = new ArrayList<>();
        for (AnomalyNotification item : getAll(context)) {
            if (item.getId() != id) {
                updated.add(item);
            }
        }
        save(context, updated);
    }

    private static void save(@NonNull Context context, @NonNull List<AnomalyNotification> items) {
        StringBuilder sb = new StringBuilder();
        for (AnomalyNotification item : items) {
            if (sb.length() > 0) {
                sb.append(RECORD_SEP);
            }
            sb.append(item.getId())
                    .append(FIELD_SEP)
                    .append(escape(item.getMessage()))
                    .append(FIELD_SEP)
                    .append(item.getTimestampMs())
                    .append(FIELD_SEP)
                    .append(item.isRead() ? "1" : "0");
        }
        prefs(context).edit().putString(KEY_RECORDS, sb.toString()).apply();
    }

    @NonNull
    private static android.content.SharedPreferences prefs(@NonNull Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    @NonNull
    private static String escape(@NonNull String value) {
        return value.replace("\\", "\\\\").replace("|", "\\|").replace(";", "\\;");
    }

    @NonNull
    private static String unescape(@NonNull String value) {
        StringBuilder sb = new StringBuilder();
        boolean escape = false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (escape) {
                sb.append(c);
                escape = false;
            } else if (c == '\\') {
                escape = true;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
