package com.ece.aractakip.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ece.aractakip.R;
import com.ece.aractakip.databinding.BottomSheetStatsEntryBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class StatsEntryBottomSheet extends BottomSheetDialogFragment {

    public interface Listener {
        void onSelectMileageUpdate();

        void onSelectExpenseAdd();
    }

    @Nullable
    private BottomSheetStatsEntryBinding binding;
    @Nullable
    private Listener listener;

    public static StatsEntryBottomSheet newInstance() {
        return new StatsEntryBottomSheet();
    }

    public void setListener(@Nullable Listener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = BottomSheetStatsEntryBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }
        binding.cardMileage.setOnClickListener(v -> {
            if (listener != null) {
                listener.onSelectMileageUpdate();
            }
            dismiss();
        });
        binding.cardExpense.setOnClickListener(v -> {
            if (listener != null) {
                listener.onSelectExpenseAdd();
            }
            dismiss();
        });
        binding.buttonCancel.setOnClickListener(v -> dismiss());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
