package com.ece.aractakip.util;

import android.text.Editable;
import android.text.TextWatcher;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.textfield.TextInputEditText;

/**
 * Formats Turkish mobile numbers as (5XX) XXX XX XX while typing.
 */
public final class TurkishPhoneFormatter implements TextWatcher {

    private static final int MAX_DIGITS = 10;

    private final TextInputEditText editText;
    private boolean selfChange;

    private TurkishPhoneFormatter(@NonNull TextInputEditText editText) {
        this.editText = editText;
    }

    public static void attach(@NonNull TextInputEditText editText) {
        editText.addTextChangedListener(new TurkishPhoneFormatter(editText));
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        // no-op
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        // no-op
    }

    @Override
    public void afterTextChanged(@Nullable Editable s) {
        if (selfChange || s == null) {
            return;
        }
        String digits = digitsOnly(s.toString());
        if (digits.length() > MAX_DIGITS) {
            digits = digits.substring(0, MAX_DIGITS);
        }
        String formatted = formatDigits(digits);
        if (formatted.contentEquals(s)) {
            return;
        }
        selfChange = true;
        editText.setText(formatted);
        editText.setSelection(formatted.length());
        selfChange = false;
    }

    @NonNull
    public static String formatDigits(@NonNull String digits) {
        int len = digits.length();
        if (len == 0) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append('(');
        int group1End = Math.min(3, len);
        sb.append(digits, 0, group1End);
        if (group1End == 3) {
            sb.append(')');
        }
        if (len > 3) {
            sb.append(' ');
            int group2End = Math.min(6, len);
            sb.append(digits, 3, group2End);
        }
        if (len > 6) {
            sb.append(' ');
            int group3End = Math.min(8, len);
            sb.append(digits, 6, group3End);
        }
        if (len > 8) {
            sb.append(' ');
            sb.append(digits, 8, len);
        }
        return sb.toString();
    }

    @NonNull
    public static String digitsOnly(@Nullable String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (Character.isDigit(c)) {
                digits.append(c);
            }
        }
        return digits.toString();
    }
}
