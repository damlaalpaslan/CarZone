package com.ece.aractakip.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.ColorRes;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.ece.aractakip.R;
import com.ece.aractakip.databinding.ItemServiceBinding;
import com.ece.aractakip.model.NearbyServiceItem;

import java.util.ArrayList;
import java.util.List;

public class ServiceAdapter extends RecyclerView.Adapter<ServiceAdapter.ServiceViewHolder> {

    public interface ServiceClickListener {
        void onServiceClick(@NonNull NearbyServiceItem item);
    }

    private final LayoutInflater inflater;
    private final ServiceClickListener clickListener;
    private final List<NearbyServiceItem> items = new ArrayList<>();

    public ServiceAdapter(@NonNull Context context, @NonNull ServiceClickListener clickListener) {
        this.inflater = LayoutInflater.from(context);
        this.clickListener = clickListener;
    }

    public void submitList(@NonNull List<NearbyServiceItem> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ServiceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemServiceBinding binding = ItemServiceBinding.inflate(inflater, parent, false);
        return new ServiceViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ServiceViewHolder holder, int position) {
        holder.bind(items.get(position));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class ServiceViewHolder extends RecyclerView.ViewHolder {

        private final ItemServiceBinding binding;

        ServiceViewHolder(@NonNull ItemServiceBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(@NonNull NearbyServiceItem item) {
            Context context = binding.getRoot().getContext();
            binding.textServiceName.setText(item.getName());
            binding.textServiceDistance.setText(item.getDistanceText());

            if (item.getType() == NearbyServiceItem.Type.FUEL) {
                binding.frameServiceIcon.setBackgroundResource(R.drawable.bg_near_service_icon_fuel);
                binding.imageServiceIcon.setImageResource(R.drawable.ic_fuel_pump);
                binding.imageServiceIcon.setColorFilter(color(context, R.color.setup_primary));
                binding.textServiceType.setText(R.string.near_services_type_fuel);
                binding.textServiceType.setTextColor(color(context, R.color.setup_primary_dark));
                binding.textServiceDistance.setBackgroundResource(R.drawable.bg_service_distance_fuel);
                binding.textServiceDistance.setTextColor(color(context, R.color.setup_primary));
            } else {
                binding.frameServiceIcon.setBackgroundResource(R.drawable.bg_near_service_icon_ev);
                binding.imageServiceIcon.setImageResource(R.drawable.ic_ev_bolt);
                binding.imageServiceIcon.setColorFilter(color(context, R.color.near_services_ev_blue));
                binding.textServiceType.setText(R.string.near_services_type_ev);
                binding.textServiceType.setTextColor(color(context, R.color.near_services_ev_blue_dark));
                binding.textServiceDistance.setBackgroundResource(R.drawable.bg_service_distance_ev);
                binding.textServiceDistance.setTextColor(color(context, R.color.near_services_ev_blue));
            }

            if (item.isOpen()) {
                binding.textServiceStatus.setVisibility(View.VISIBLE);
            } else {
                binding.textServiceStatus.setVisibility(View.GONE);
            }

            binding.cardService.setOnClickListener(v -> clickListener.onServiceClick(item));
        }

        private int color(@NonNull Context context, @ColorRes int colorRes) {
            return ContextCompat.getColor(context, colorRes);
        }
    }
}
