package com.ece.aractakip.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class VehicleModel implements Parcelable {

    private String photoUri;
    private String brand;
    private String model;
    private int year;
    private String color;
    private String plate;
    private int mileage;
    private String fuelType;

    public VehicleModel() {
    }

    public VehicleModel(
            String photoUri,
            String brand,
            String model,
            int year,
            String color,
            String plate,
            int mileage
    ) {
        this(photoUri, brand, model, year, color, plate, mileage, "");
    }

    public VehicleModel(
            String photoUri,
            String brand,
            String model,
            int year,
            String color,
            String plate,
            int mileage,
            String fuelType
    ) {
        this.photoUri = photoUri;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.color = color;
        this.plate = plate;
        this.mileage = mileage;
        this.fuelType = fuelType != null ? fuelType : "";
    }

    protected VehicleModel(@NonNull Parcel in) {
        photoUri = in.readString();
        brand = in.readString();
        model = in.readString();
        year = in.readInt();
        color = in.readString();
        plate = in.readString();
        mileage = in.readInt();
        fuelType = in.readString();
    }

    public String getPhotoUri() {
        return photoUri;
    }

    public void setPhotoUri(String photoUri) {
        this.photoUri = photoUri;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getPlate() {
        return plate;
    }

    public void setPlate(String plate) {
        this.plate = plate;
    }

    public int getMileage() {
        return mileage;
    }

    public void setMileage(int mileage) {
        this.mileage = mileage;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(photoUri);
        dest.writeString(brand);
        dest.writeString(model);
        dest.writeInt(year);
        dest.writeString(color);
        dest.writeString(plate);
        dest.writeInt(mileage);
        dest.writeString(fuelType);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<VehicleModel> CREATOR = new Creator<VehicleModel>() {
        @Override
        public VehicleModel createFromParcel(Parcel in) {
            return new VehicleModel(in);
        }

        @Override
        public VehicleModel[] newArray(int size) {
            return new VehicleModel[size];
        }
    };
}
