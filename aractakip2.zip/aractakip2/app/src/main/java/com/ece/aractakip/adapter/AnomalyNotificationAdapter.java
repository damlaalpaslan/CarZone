package com.ece.aractakip.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ece.aractakip.databinding.ItemAnomalyNotificationBinding;
import com.ece.aractakip.model.AnomalyNotification;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AnomalyNotificationAdapter extends RecyclerView.Adapter<AnomalyNotificationAdapter.ViewHolder> {

    private final LayoutInflater inflater;
    private final List<AnomalyNotification> items = new ArrayList<>();
    private final SimpleDateFormat dateFormat =
            new SimpleDateFormat("dd/MM/yyyy, HH:mm", new Locale("tr", "TR"));

    public AnomalyNotificationAdapter(@NonNull Context context) {
        this.inflater = LayoutInflater.from(context);
    }

    public void submitList(@NonNull List<AnomalyNotification> notifications) {
        items.clear();
        items.addAll(notifications);
        notifyDataSetChanged();
    }

    @NonNull
    public AnomalyNotification getItem(int position) {
        return items.get(position);
    }

    public void removeAt(int position) {
        if (position < 0 || position >= items.size()) {
            return;
        }
        items.remove(position);
        notifyItemRemoved(position);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(ItemAnomalyNotificationBinding.inflate(inflater, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AnomalyNotification item = items.get(position);
        holder.binding.textAnomalyMessage.setText(item.getMessage());
        holder.binding.textAnomalyTime.setText(dateFormat.format(new Date(item.getTimestampMs())));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        private final ItemAnomalyNotificationBinding binding;

        ViewHolder(@NonNull ItemAnomalyNotificationBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
