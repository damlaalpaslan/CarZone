package com.ece.aractakip.data;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import com.ece.aractakip.model.DocumentEntry;
import com.ece.aractakip.model.ExpenseEntry;
import com.ece.aractakip.model.ServiceHistoryEntry;
import com.ece.aractakip.model.UserProfile;
import com.ece.aractakip.model.VehicleModel;
import com.ece.aractakip.util.DocumentFileHelper;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.time.YearMonth;

public final class AppPreferences {

    public static final int THEME_SYSTEM = 0;
    public static final int THEME_LIGHT = 1;
    public static final int THEME_DARK = 2;

    private static final String PREFS = "aractakip_app_prefs";

    private static final String KEY_SETUP_COMPLETE = "setup_complete";
    private static final String KEY_PROFILE_PHOTO_URI = "profile_photo_uri";
    private static final String KEY_PROFILE_NAME = "profile_name";
    private static final String KEY_PROFILE_PHONE = "profile_phone";
    private static final String KEY_PHOTO_URI = "vehicle_photo_uri";
    private static final String KEY_BRAND = "vehicle_brand";
    private static final String KEY_MODEL = "vehicle_model";
    private static final String KEY_YEAR = "vehicle_year";
    private static final String KEY_COLOR = "vehicle_color";
    private static final String KEY_PLATE = "vehicle_plate";
    private static final String KEY_MILEAGE = "vehicle_mileage";
    private static final String KEY_FUEL_TYPE = "vehicle_fuel_type";
    private static final String KEY_TUV_INSPECTION_MS = "tuv_last_inspection_ms";
    private static final String KEY_INSURANCE_START_MS = "insurance_start_ms";
    private static final String KEY_STATS_ODOMETER = "stats_odometer";
    private static final String KEY_STATS_ODOMETER_BASELINE = "stats_odometer_baseline";
    private static final String KEY_STATS_EXPENSES = "stats_expenses";
    private static final String KEY_NOTIFY_LEGAL = "notify_legal";
    private static final String KEY_NOTIFY_MAINTENANCE = "notify_maintenance";
    private static final String KEY_REMINDER_THRESHOLDS = "reminder_thresholds";
    private static final String KEY_THEME_MODE = "theme_mode";
    private static final String KEY_SERVICE_HISTORY = "service_history_records";
    private static final String KEY_DOCUMENTS = "vehicle_documents";
    private static final String KEY_REMINDERS = "reminder_records";

    public static final String[] REMINDER_THRESHOLD_KEYS = {"1", "3", "5", "7", "15", "30"};

    private AppPreferences() {
    }

    @NonNull
    private static SharedPreferences prefs(@NonNull Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isSetupCompleted(@NonNull Context context) {
        return prefs(context).getBoolean(KEY_SETUP_COMPLETE, false);
    }

    public static boolean isOnboardingCompleted(@NonNull Context context) {
        return isSetupCompleted(context);
    }

    public static void saveUserProfile(@NonNull Context context, @NonNull UserProfile profile) {
        prefs(context).edit()
                .putString(KEY_PROFILE_PHOTO_URI, profile.getPhotoUri())
                .putString(KEY_PROFILE_NAME, profile.getFullName())
                .putString(KEY_PROFILE_PHONE, profile.getPhone())
                .apply();
    }

    @NonNull
    public static UserProfile loadUserProfile(@NonNull Context context) {
        SharedPreferences p = prefs(context);
        return new UserProfile(
                p.getString(KEY_PROFILE_PHOTO_URI, null),
                p.getString(KEY_PROFILE_NAME, ""),
                p.getString(KEY_PROFILE_PHONE, "")
        );
    }

    public static void saveVehicle(@NonNull Context context, @NonNull VehicleModel vehicle) {
        prefs(context).edit()
                .putString(KEY_PHOTO_URI, vehicle.getPhotoUri())
                .putString(KEY_BRAND, vehicle.getBrand())
                .putString(KEY_MODEL, vehicle.getModel())
                .putInt(KEY_YEAR, vehicle.getYear())
                .putString(KEY_COLOR, vehicle.getColor())
                .putString(KEY_PLATE, vehicle.getPlate())
                .putInt(KEY_MILEAGE, vehicle.getMileage())
                .putString(KEY_FUEL_TYPE, vehicle.getFuelType())
                .apply();
    }

    public static void completeOnboarding(
            @NonNull Context context,
            @NonNull UserProfile profile,
            @NonNull VehicleModel vehicle
    ) {
        SharedPreferences.Editor e = prefs(context).edit();
        e.putBoolean(KEY_SETUP_COMPLETE, true);
        e.putString(KEY_PROFILE_PHOTO_URI, profile.getPhotoUri());
        e.putString(KEY_PROFILE_NAME, profile.getFullName());
        e.putString(KEY_PROFILE_PHONE, profile.getPhone());
        e.putString(KEY_PHOTO_URI, vehicle.getPhotoUri());
        e.putString(KEY_BRAND, vehicle.getBrand());
        e.putString(KEY_MODEL, vehicle.getModel());
        e.putInt(KEY_YEAR, vehicle.getYear());
        e.putString(KEY_COLOR, vehicle.getColor());
        e.putString(KEY_PLATE, vehicle.getPlate());
        e.putInt(KEY_MILEAGE, vehicle.getMileage());
        e.putString(KEY_FUEL_TYPE, vehicle.getFuelType());
        e.apply();
    }

    public static void saveVehicleAndDates(
            @NonNull Context context,
            @NonNull VehicleModel vehicle,
            long tuvLastInspectionMs,
            long insuranceStartMs
    ) {
        SharedPreferences.Editor e = prefs(context).edit();
        e.putBoolean(KEY_SETUP_COMPLETE, true);
        e.putString(KEY_PHOTO_URI, vehicle.getPhotoUri());
        e.putString(KEY_BRAND, vehicle.getBrand());
        e.putString(KEY_MODEL, vehicle.getModel());
        e.putInt(KEY_YEAR, vehicle.getYear());
        e.putString(KEY_COLOR, vehicle.getColor());
        e.putString(KEY_PLATE, vehicle.getPlate());
        e.putInt(KEY_MILEAGE, vehicle.getMileage());
        e.putString(KEY_FUEL_TYPE, vehicle.getFuelType());
        if (tuvLastInspectionMs > 0) {
            e.putLong(KEY_TUV_INSPECTION_MS, tuvLastInspectionMs);
        } else {
            e.remove(KEY_TUV_INSPECTION_MS);
        }
        if (insuranceStartMs > 0) {
            e.putLong(KEY_INSURANCE_START_MS, insuranceStartMs);
        } else {
            e.remove(KEY_INSURANCE_START_MS);
        }
        e.apply();
    }

    public static void setTuvInspectionDateMs(@NonNull Context context, long utcMillis) {
        SharedPreferences.Editor e = prefs(context).edit();
        if (utcMillis > 0) {
            e.putLong(KEY_TUV_INSPECTION_MS, utcMillis);
        } else {
            e.remove(KEY_TUV_INSPECTION_MS);
        }
        e.apply();
    }

    public static void setInsuranceStartDateMs(@NonNull Context context, long utcMillis) {
        SharedPreferences.Editor e = prefs(context).edit();
        if (utcMillis > 0) {
            e.putLong(KEY_INSURANCE_START_MS, utcMillis);
        } else {
            e.remove(KEY_INSURANCE_START_MS);
        }
        e.apply();
    }

    public static long getTuvInspectionDateMs(@NonNull Context context) {
        return prefs(context).getLong(KEY_TUV_INSPECTION_MS, -1L);
    }

    public static long getInsuranceStartDateMs(@NonNull Context context) {
        return prefs(context).getLong(KEY_INSURANCE_START_MS, -1L);
    }

    @NonNull
    public static VehicleModel loadVehicle(@NonNull Context context) {
        SharedPreferences p = prefs(context);
        return new VehicleModel(
                p.getString(KEY_PHOTO_URI, null),
                p.getString(KEY_BRAND, ""),
                p.getString(KEY_MODEL, ""),
                p.getInt(KEY_YEAR, 0),
                p.getString(KEY_COLOR, ""),
                p.getString(KEY_PLATE, ""),
                p.getInt(KEY_MILEAGE, 0),
                p.getString(KEY_FUEL_TYPE, "")
        );
    }

    public static boolean isLegalNotificationsEnabled(@NonNull Context context) {
        return prefs(context).getBoolean(KEY_NOTIFY_LEGAL, true);
    }

    public static void setLegalNotificationsEnabled(@NonNull Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_NOTIFY_LEGAL, enabled).apply();
    }

    public static boolean isMaintenanceNotificationsEnabled(@NonNull Context context) {
        return prefs(context).getBoolean(KEY_NOTIFY_MAINTENANCE, true);
    }

    public static void setMaintenanceNotificationsEnabled(@NonNull Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_NOTIFY_MAINTENANCE, enabled).apply();
    }

    @NonNull
    public static List<String> getReminderThresholdKeys(@NonNull Context context) {
        String raw = prefs(context).getString(KEY_REMINDER_THRESHOLDS, "3,7");
        List<String> result = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) {
            return result;
        }
        for (String part : raw.split(",")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) {
                result.add(trimmed);
            }
        }
        return result;
    }

    public static void setReminderThresholdKeys(@NonNull Context context, @NonNull List<String> keys) {
        StringBuilder sb = new StringBuilder();
        for (String key : keys) {
            if (sb.length() > 0) {
                sb.append(",");
            }
            sb.append(key);
        }
        prefs(context).edit().putString(KEY_REMINDER_THRESHOLDS, sb.toString()).apply();
    }

    @NonNull
    public static String getReminderRecordsRaw(@NonNull Context context) {
        String raw = prefs(context).getString(KEY_REMINDERS, "");
        return raw == null ? "" : raw;
    }

    public static void setReminderRecordsRaw(@NonNull Context context, @NonNull String raw) {
        prefs(context).edit().putString(KEY_REMINDERS, raw).apply();
    }

    public static int getThemeMode(@NonNull Context context) {
        return prefs(context).getInt(KEY_THEME_MODE, THEME_SYSTEM);
    }

    public static void setThemeMode(@NonNull Context context, int mode) {
        prefs(context).edit().putInt(KEY_THEME_MODE, mode).apply();
    }

    public static void clear(@NonNull Context context) {
        prefs(context).edit().clear().apply();
    }

    public static void clearAllData(@NonNull Context context) {
        clear(context);
    }

    public static void saveMonthlyOdometer(@NonNull Context context,
                                           @NonNull String monthKey,
                                           int odometerKm) {
        Map<String, Integer> map = getMonthlyOdometers(context);
        boolean isFirstEntry = map.isEmpty();
        map.put(monthKey, odometerKm);
        TreeMap<String, Integer> sorted = new TreeMap<>(map);
        SharedPreferences.Editor editor = prefs(context).edit();
        if (isFirstEntry) {
            int vehicleKm = loadVehicle(context).getMileage();
            if (vehicleKm > 0) {
                editor.putInt(KEY_STATS_ODOMETER_BASELINE, vehicleKm);
            }
        } else {
            applyInferredBaselineIfNeeded(context, sorted, editor);
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> entry : sorted.entrySet()) {
            if (sb.length() > 0) {
                sb.append(";");
            }
            sb.append(entry.getKey()).append(":").append(entry.getValue());
        }
        editor.putString(KEY_STATS_ODOMETER, sb.toString());
        if (monthKey.equals(YearMonth.now().toString())) {
            editor.putInt(KEY_MILEAGE, odometerKm);
        }
        editor.apply();
    }

    public static int getMonthlyOdometerBaseline(@NonNull Context context) {
        SharedPreferences p = prefs(context);
        LinkedHashMap<String, Integer> map = getMonthlyOdometers(context);
        if (p.contains(KEY_STATS_ODOMETER_BASELINE)) {
            int stored = p.getInt(KEY_STATS_ODOMETER_BASELINE, 0);
            if (stored > 0) {
                return stored;
            }
        }
        if (map.size() >= 2) {
            int inferred = inferBaselineFromReadings(new ArrayList<>(map.values()));
            if (inferred >= 0) {
                p.edit().putInt(KEY_STATS_ODOMETER_BASELINE, inferred).apply();
                return inferred;
            }
        }
        if (map.size() == 1) {
            int onlyReading = map.values().iterator().next();
            int vehicleKm = loadVehicle(context).getMileage();
            if (vehicleKm > 0 && vehicleKm < onlyReading) {
                return vehicleKm;
            }
        }
        return Math.max(0, loadVehicle(context).getMileage());
    }

    private static void applyInferredBaselineIfNeeded(@NonNull Context context,
                                                      @NonNull TreeMap<String, Integer> sorted,
                                                      @NonNull SharedPreferences.Editor editor) {
        SharedPreferences p = prefs(context);
        int stored = p.contains(KEY_STATS_ODOMETER_BASELINE)
                ? p.getInt(KEY_STATS_ODOMETER_BASELINE, 0) : 0;
        if (stored > 0 || sorted.size() < 2) {
            return;
        }
        int inferred = inferBaselineFromReadings(new ArrayList<>(sorted.values()));
        if (inferred >= 0) {
            editor.putInt(KEY_STATS_ODOMETER_BASELINE, inferred);
        }
    }

    private static int inferBaselineFromReadings(@NonNull List<Integer> chronologicalReadings) {
        if (chronologicalReadings.size() < 2) {
            return -1;
        }
        int first = chronologicalReadings.get(0);
        int second = chronologicalReadings.get(1);
        int inferred = (2 * first) - second;
        if (inferred >= 0 && inferred < first) {
            return inferred;
        }
        return -1;
    }

    @NonNull
    public static LinkedHashMap<String, Integer> getMonthlyOdometers(@NonNull Context context) {
        String raw = prefs(context).getString(KEY_STATS_ODOMETER, "");
        TreeMap<String, Integer> sorted = new TreeMap<>();
        if (raw == null || raw.trim().isEmpty()) {
            return new LinkedHashMap<>();
        }
        String[] rows = raw.split(";");
        for (String row : rows) {
            String[] parts = row.split(":");
            if (parts.length != 2) {
                continue;
            }
            try {
                sorted.put(parts[0], Integer.parseInt(parts[1].trim()));
            } catch (NumberFormatException ignored) {
            }
        }
        return new LinkedHashMap<>(sorted);
    }

    public static void addExpense(@NonNull Context context, @NonNull ExpenseEntry entry) {
        List<ExpenseEntry> all = getExpenses(context);
        all.add(entry);
        StringBuilder sb = new StringBuilder();
        for (ExpenseEntry item : all) {
            if (sb.length() > 0) {
                sb.append(";");
            }
            sb.append(item.getCreatedAtMs())
                    .append(",")
                    .append(item.getCategory().name())
                    .append(",")
                    .append(item.getAmount());
        }
        prefs(context).edit().putString(KEY_STATS_EXPENSES, sb.toString()).apply();
    }

    @NonNull
    public static List<ExpenseEntry> getExpenses(@NonNull Context context) {
        String raw = prefs(context).getString(KEY_STATS_EXPENSES, "");
        List<ExpenseEntry> list = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) {
            return list;
        }
        String[] rows = raw.split(";");
        for (String row : rows) {
            String[] parts = row.split(",");
            if (parts.length != 3) {
                continue;
            }
            try {
                long createdAt = Long.parseLong(parts[0]);
                ExpenseEntry.Category category = ExpenseEntry.Category.valueOf(parts[1]);
                float amount = Float.parseFloat(parts[2]);
                list.add(new ExpenseEntry(createdAt, category, amount));
            } catch (Exception ignored) {
            }
        }
        return list;
    }

    public static void saveServiceHistory(@NonNull Context context,
                                          @NonNull List<ServiceHistoryEntry> entries) {
        StringBuilder sb = new StringBuilder();
        for (ServiceHistoryEntry entry : entries) {
            if (sb.length() > 0) {
                sb.append(";");
            }
            sb.append(entry.getId())
                    .append("|")
                    .append(escape(entry.getTitle()))
                    .append("|")
                    .append(entry.getType().name())
                    .append("|")
                    .append(entry.getMileage())
                    .append("|")
                    .append(escape(entry.getDateText()))
                    .append("|")
                    .append(escape(entry.getLocation()))
                    .append("|")
                    .append(entry.getCost())
                    .append("|")
                    .append(entry.getServiceDateMs());
        }
        prefs(context).edit().putString(KEY_SERVICE_HISTORY, sb.toString()).apply();
    }

    public static void addServiceHistoryEntry(@NonNull Context context,
                                              @NonNull ServiceHistoryEntry entry) {
        DatabaseHelper.getInstance(context).insertServiceRecord(entry);
        List<ServiceHistoryEntry> all = DatabaseHelper.getInstance(context).getAllServiceRecords();
        saveServiceHistory(context, all);
    }

    public static void removeServiceHistoryEntry(@NonNull Context context, long id) {
        DatabaseHelper.getInstance(context).deleteServiceRecord(id);
        saveServiceHistory(context, DatabaseHelper.getInstance(context).getAllServiceRecords());
    }

    @NonNull
    public static List<ServiceHistoryEntry> getServiceHistory(@NonNull Context context) {
        return DatabaseHelper.getInstance(context).getAllServiceRecords();
    }

    @NonNull
    static List<ServiceHistoryEntry> getLegacyServiceHistoryRecords(@NonNull Context context) {
        String raw = prefs(context).getString(KEY_SERVICE_HISTORY, "");
        List<ServiceHistoryEntry> list = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) {
            return list;
        }
        String[] rows = raw.split(";");
        for (String row : rows) {
            String[] parts = row.split("\\|", -1);
            if (parts.length != 8) {
                continue;
            }
            try {
                list.add(new ServiceHistoryEntry(
                        Long.parseLong(parts[0]),
                        unescape(parts[1]),
                        ServiceHistoryEntry.Type.valueOf(parts[2]),
                        Integer.parseInt(parts[3]),
                        unescape(parts[4]),
                        unescape(parts[5]),
                        Double.parseDouble(parts[6]),
                        Long.parseLong(parts[7])
                ));
            } catch (Exception ignored) {
            }
        }
        return list;
    }

    public static void saveDocuments(@NonNull Context context, @NonNull List<DocumentEntry> entries) {
        StringBuilder sb = new StringBuilder();
        for (DocumentEntry entry : entries) {
            if (sb.length() > 0) {
                sb.append(";");
            }
            sb.append(entry.getId())
                    .append("|")
                    .append(entry.getType().name())
                    .append("|")
                    .append(escape(entry.getTitle()))
                    .append("|")
                    .append(escape(entry.getDocumentNumber()))
                    .append("|")
                    .append(entry.getExpiryDateMs())
                    .append("|")
                    .append(escape(entry.getFileUri() == null ? "" : entry.getFileUri()));
        }
        prefs(context).edit().putString(KEY_DOCUMENTS, sb.toString()).apply();
    }

    public static void addDocument(@NonNull Context context, @NonNull DocumentEntry entry) {
        List<DocumentEntry> all = getDocuments(context);
        all.add(entry);
        saveDocuments(context, all);
    }

    public static void removeDocument(@NonNull Context context, long id) {
        List<DocumentEntry> all = getDocuments(context);
        List<DocumentEntry> updated = new ArrayList<>();
        for (DocumentEntry entry : all) {
            if (entry.getId() == id) {
                DocumentFileHelper.deleteStoredFile(entry.getFileUri());
            } else {
                updated.add(entry);
            }
        }
        saveDocuments(context, updated);
    }

    @NonNull
    public static List<DocumentEntry> getDocuments(@NonNull Context context) {
        String raw = prefs(context).getString(KEY_DOCUMENTS, "");
        List<DocumentEntry> list = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) {
            return list;
        }
        String[] rows = raw.split(";");
        for (String row : rows) {
            String[] parts = row.split("\\|", -1);
            if (parts.length != 6) {
                continue;
            }
            try {
                String fileUri = unescape(parts[5]);
                list.add(new DocumentEntry(
                        Long.parseLong(parts[0]),
                        DocumentEntry.Type.valueOf(parts[1]),
                        unescape(parts[2]),
                        unescape(parts[3]),
                        Long.parseLong(parts[4]),
                        fileUri.isEmpty() ? null : fileUri
                ));
            } catch (Exception ignored) {
            }
        }
        return list;
    }

    @NonNull
    private static String escape(@NonNull String value) {
        return value.replace("\\", "\\\\").replace("|", "\\|");
    }

    @NonNull
    private static String unescape(@NonNull String value) {
        StringBuilder sb = new StringBuilder();
        boolean escape = false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (escape) {
                sb.append(c);
                escape = false;
            } else if (c == '\\') {
                escape = true;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
