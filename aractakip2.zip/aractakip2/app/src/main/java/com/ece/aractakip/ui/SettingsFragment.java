package com.ece.aractakip.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.ece.aractakip.OnboardingActivity;
import com.ece.aractakip.R;
import com.ece.aractakip.data.AppPreferences;
import com.ece.aractakip.databinding.DialogEditProfileBinding;
import com.ece.aractakip.databinding.DialogEditVehicleBinding;
import com.ece.aractakip.databinding.DialogNotificationPrefsBinding;
import com.ece.aractakip.databinding.DialogReminderHeaderBinding;
import com.ece.aractakip.databinding.FragmentSettingsBinding;
import com.ece.aractakip.databinding.ItemSettingsRowBinding;
import com.ece.aractakip.model.UserProfile;
import com.ece.aractakip.model.VehicleModel;
import com.ece.aractakip.util.ThemeHelper;
import com.ece.aractakip.util.TurkishPhoneFormatter;
import com.ece.aractakip.util.TurkishTextInputHelper;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

public class SettingsFragment extends Fragment {

    private static final int DIALOG_THEME = R.style.ThemeOverlay_Aractakip_AlertDialog;

    @Nullable
    private FragmentSettingsBinding binding;
    @Nullable
    private String pendingVehiclePhotoUri;

    private final ActivityResultLauncher<String> pickVehiclePhotoLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    pendingVehiclePhotoUri = uri.toString();
                }
            });

    public static SettingsFragment newInstance() {
        return new SettingsFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentSettingsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }
        setupRows();
        bindProfile();
        bindRowValues();
        binding.cardProfile.setOnClickListener(v -> showEditProfileDialog());
        binding.rowVehicleDetails.getRoot().setOnClickListener(v -> showEditVehicleDialog());
        binding.rowNotificationPrefs.getRoot().setOnClickListener(v -> showNotificationPrefsDialog());
        binding.rowReminderTime.getRoot().setOnClickListener(v -> showReminderTimeDialog());
        binding.rowTheme.getRoot().setOnClickListener(v -> showThemeDialog());
        binding.cardDeleteAll.setOnClickListener(v -> confirmDeleteAll());
    }

    @Override
    public void onResume() {
        super.onResume();
        bindProfile();
        bindRowValues();
    }

    private void setupRows() {
        if (binding == null) {
            return;
        }
        setRow(binding.rowVehicleDetails, R.string.settings_vehicle_details, R.drawable.ic_car_card, null);
        setRow(binding.rowNotificationPrefs, R.string.settings_notification_prefs,
                R.drawable.ic_toolbar_notifications, null);
        setRow(binding.rowReminderTime, R.string.settings_reminder_time,
                R.drawable.ic_service_calendar, null);
        setRow(binding.rowTheme, R.string.settings_theme, R.drawable.ic_toolbar_settings, null);
    }

    private void setRow(@NonNull ItemSettingsRowBinding row,
                        int titleRes,
                        int iconRes,
                        @Nullable String value) {
        row.imageRowIcon.setImageResource(iconRes);
        row.imageRowIcon.setColorFilter(ContextCompat.getColor(requireContext(), R.color.brand_orange));
        row.textRowTitle.setText(titleRes);
        if (value != null && !value.isEmpty()) {
            row.textRowValue.setVisibility(View.VISIBLE);
            row.textRowValue.setText(value);
        } else {
            row.textRowValue.setVisibility(View.GONE);
        }
    }

    private void bindProfile() {
        if (binding == null) {
            return;
        }
        UserProfile profile = AppPreferences.loadUserProfile(requireContext());

        String displayName = profile.getFullName().isEmpty()
                ? getString(R.string.settings_profile_placeholder)
                : profile.getFullName();
        binding.textProfileName.setText(displayName);

        String photo = profile.getPhotoUri();
        if (photo != null && !photo.isEmpty()) {
            binding.imageProfile.setVisibility(View.VISIBLE);
            binding.textProfileInitials.setVisibility(View.GONE);
            Glide.with(this)
                    .load(Uri.parse(photo))
                    .circleCrop()
                    .placeholder(R.drawable.ic_profile_placeholder)
                    .into(binding.imageProfile);
        } else {
            binding.imageProfile.setVisibility(View.GONE);
            binding.textProfileInitials.setVisibility(View.VISIBLE);
            binding.textProfileInitials.setText(getInitials(displayName));
        }
    }

    @NonNull
    private String getInitials(@NonNull String fullName) {
        String trimmed = fullName.trim();
        if (trimmed.isEmpty() || getString(R.string.settings_profile_placeholder).equals(trimmed)) {
            return "?";
        }
        String[] parts = trimmed.split("\\s+");
        StringBuilder initials = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                initials.append(Character.toUpperCase(part.charAt(0)));
                if (initials.length() >= 2) {
                    break;
                }
            }
        }
        return initials.length() == 0 ? "?" : initials.toString();
    }

    private void bindRowValues() {
        if (binding == null) {
            return;
        }
        VehicleModel vehicle = AppPreferences.loadVehicle(requireContext());
        String vehicleSummary = (vehicle.getBrand() + " " + vehicle.getModel()).trim();
        if (!vehicle.getPlate().isEmpty()) {
            vehicleSummary = vehicleSummary + " • " + vehicle.getPlate();
        }
        setRow(binding.rowVehicleDetails, R.string.settings_vehicle_details, R.drawable.ic_car_card, vehicleSummary);
        setRow(binding.rowNotificationPrefs, R.string.settings_notification_prefs,
                R.drawable.ic_toolbar_notifications, getNotificationSummary());
        setRow(binding.rowReminderTime, R.string.settings_reminder_time,
                R.drawable.ic_service_calendar,
                formatThresholdSummary(AppPreferences.getReminderThresholdKeys(requireContext())));
        setRow(binding.rowTheme, R.string.settings_theme, R.drawable.ic_toolbar_settings,
                getThemeLabel(AppPreferences.getThemeMode(requireContext())));
    }

    @NonNull
    private String getNotificationSummary() {
        boolean legal = AppPreferences.isLegalNotificationsEnabled(requireContext());
        boolean maintenance = AppPreferences.isMaintenanceNotificationsEnabled(requireContext());
        if (legal && maintenance) {
            return getString(R.string.settings_notify_both_on);
        }
        if (!legal && !maintenance) {
            return getString(R.string.settings_notify_both_off);
        }
        if (legal) {
            return getString(R.string.settings_notify_legal);
        }
        return getString(R.string.settings_notify_maintenance);
    }

    private void showEditProfileDialog() {
        DialogEditProfileBinding dialogBinding = DialogEditProfileBinding.inflate(getLayoutInflater());
        UserProfile profile = AppPreferences.loadUserProfile(requireContext());
        dialogBinding.editFullName.setText(profile.getFullName());
        TurkishTextInputHelper.prepareNameField(dialogBinding.editFullName);
        String digits = TurkishPhoneFormatter.digitsOnly(profile.getPhone());
        if (!digits.isEmpty()) {
            dialogBinding.editPhone.setText(TurkishPhoneFormatter.formatDigits(digits));
        }
        TurkishPhoneFormatter.attach(dialogBinding.editPhone);

        new MaterialAlertDialogBuilder(requireActivity(), DIALOG_THEME)
                .setTitle(R.string.settings_edit_profile_title)
                .setView(dialogBinding.getRoot())
                .setNegativeButton(R.string.stats_cancel, null)
                .setPositiveButton(R.string.dialog_ok, (d, w) -> {
                    String name = textOrEmpty(dialogBinding.editFullName);
                    String phoneDigits = TurkishPhoneFormatter.digitsOnly(textOrEmpty(dialogBinding.editPhone));
                    if (TextUtils.isEmpty(name) || phoneDigits.isEmpty()) {
                        Toast.makeText(requireContext(), R.string.onboarding_error_profile, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String phone = TurkishPhoneFormatter.formatDigits(phoneDigits);
                    UserProfile updated = new UserProfile(profile.getPhotoUri(), name, phone);
                    AppPreferences.saveUserProfile(requireContext(), updated);
                    bindProfile();
                    Toast.makeText(requireContext(), R.string.settings_saved, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void showEditVehicleDialog() {
        DialogEditVehicleBinding dialogBinding = DialogEditVehicleBinding.inflate(getLayoutInflater());
        VehicleModel vehicle = AppPreferences.loadVehicle(requireContext());
        pendingVehiclePhotoUri = vehicle.getPhotoUri();

        dialogBinding.editBrand.setText(vehicle.getBrand());
        dialogBinding.editModel.setText(vehicle.getModel());
        dialogBinding.editColor.setText(vehicle.getColor());
        dialogBinding.editPlate.setText(vehicle.getPlate());

        String[] fuels = getResources().getStringArray(R.array.fuel_types);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_dropdown_item_1line,
                fuels
        );
        dialogBinding.autoFuelType.setAdapter(adapter);
        String fuel = vehicle.getFuelType();
        if (fuel == null || fuel.isEmpty()) {
            if (fuels.length > 0) {
                dialogBinding.autoFuelType.setText(fuels[0], false);
            }
        } else {
            dialogBinding.autoFuelType.setText(fuel, false);
        }

        dialogBinding.buttonChangeVehiclePhoto.setOnClickListener(v ->
                pickVehiclePhotoLauncher.launch("image/*"));

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireActivity(), DIALOG_THEME)
                .setTitle(R.string.settings_vehicle_details)
                .setView(dialogBinding.getRoot());

        AlertDialog dialog = builder.create();

        dialogBinding.buttonCancel.setOnClickListener(v -> dialog.dismiss());
        dialogBinding.buttonOk.setOnClickListener(v -> {
            if (!saveVehicleFromDialog(dialogBinding, vehicle)) {
                return;
            }
            dialog.dismiss();
        });

        dialog.show();
    }

    private boolean saveVehicleFromDialog(@NonNull DialogEditVehicleBinding dialogBinding,
                                          @NonNull VehicleModel vehicle) {
        String brand = textOrEmpty(dialogBinding.editBrand);
        String model = textOrEmpty(dialogBinding.editModel);
        String plate = textOrEmpty(dialogBinding.editPlate);
        if (TextUtils.isEmpty(brand) || TextUtils.isEmpty(model) || TextUtils.isEmpty(plate)) {
            Toast.makeText(requireContext(), R.string.setup_error_required, Toast.LENGTH_SHORT).show();
            return false;
        }
        String fuelType = dialogBinding.autoFuelType.getText() == null
                ? ""
                : dialogBinding.autoFuelType.getText().toString().trim();
        VehicleModel updated = new VehicleModel(
                pendingVehiclePhotoUri,
                brand,
                model,
                vehicle.getYear(),
                textOrEmpty(dialogBinding.editColor),
                plate,
                vehicle.getMileage(),
                fuelType
        );
        AppPreferences.saveVehicle(requireContext(), updated);
        bindProfile();
        bindRowValues();
        Toast.makeText(requireContext(), R.string.settings_saved, Toast.LENGTH_SHORT).show();
        return true;
    }

    private void showNotificationPrefsDialog() {
        DialogNotificationPrefsBinding dialogBinding =
                DialogNotificationPrefsBinding.inflate(getLayoutInflater());
        dialogBinding.switchLegal.setChecked(
                AppPreferences.isLegalNotificationsEnabled(requireContext()));
        dialogBinding.switchMaintenance.setChecked(
                AppPreferences.isMaintenanceNotificationsEnabled(requireContext()));

        new MaterialAlertDialogBuilder(requireActivity(), DIALOG_THEME)
                .setTitle(R.string.settings_notification_prefs)
                .setView(dialogBinding.getRoot())
                .setNegativeButton(R.string.stats_cancel, null)
                .setPositiveButton(R.string.dialog_ok, (d, w) -> {
                    AppPreferences.setLegalNotificationsEnabled(
                            requireContext(), dialogBinding.switchLegal.isChecked());
                    AppPreferences.setMaintenanceNotificationsEnabled(
                            requireContext(), dialogBinding.switchMaintenance.isChecked());
                    bindRowValues();
                })
                .show();
    }

    private void showReminderTimeDialog() {
        final String[] keys = AppPreferences.REMINDER_THRESHOLD_KEYS;
        final boolean[] checked = buildReminderCheckedState(keys);

        DialogReminderHeaderBinding headerBinding =
                DialogReminderHeaderBinding.inflate(getLayoutInflater());

        AlertDialog dialog = new AlertDialog.Builder(requireActivity(), DIALOG_THEME)
                .setCustomTitle(headerBinding.getRoot())
                .setMultiChoiceItems(R.array.reminder_threshold_labels, checked,
                        (d, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton(R.string.stats_cancel, null)
                .setPositiveButton(R.string.dialog_ok, (d, which) -> {
                    List<String> selected = collectSelectedReminderKeys(keys, checked);
                    AppPreferences.setReminderThresholdKeys(requireContext(), selected);
                    bindRowValues();
                })
                .create();

        dialog.show();
    }

    @NonNull
    private boolean[] buildReminderCheckedState(@NonNull String[] keys) {
        boolean[] checked = new boolean[keys.length];
        List<String> saved = AppPreferences.getReminderThresholdKeys(requireContext());
        for (int i = 0; i < keys.length; i++) {
            checked[i] = saved.contains(keys[i]);
        }
        return checked;
    }

    @NonNull
    private List<String> collectSelectedReminderKeys(@NonNull String[] keys, @NonNull boolean[] checked) {
        List<String> selected = new ArrayList<>();
        for (int i = 0; i < keys.length; i++) {
            if (checked[i]) {
                selected.add(keys[i]);
            }
        }
        if (selected.isEmpty()) {
            selected.add("7");
        }
        return selected;
    }

    private void showThemeDialog() {
        final String[] labels = {
                getString(R.string.settings_theme_system),
                getString(R.string.settings_theme_light),
                getString(R.string.settings_theme_dark)
        };
        final int[] values = {
                AppPreferences.THEME_SYSTEM,
                AppPreferences.THEME_LIGHT,
                AppPreferences.THEME_DARK
        };
        int current = AppPreferences.getThemeMode(requireContext());
        int checkedItem = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i] == current) {
                checkedItem = i;
                break;
            }
        }
        final int[] selectedIndex = {checkedItem};

        AlertDialog themeDialog = new AlertDialog.Builder(requireActivity(), DIALOG_THEME)
                .setTitle(R.string.settings_theme)
                .setSingleChoiceItems(labels, checkedItem, (dialog, which) -> selectedIndex[0] = which)
                .setNegativeButton(R.string.stats_cancel, null)
                .setPositiveButton(R.string.dialog_ok, (dialog, which) -> {
                    int newMode = values[selectedIndex[0]];
                    if (newMode == AppPreferences.getThemeMode(requireContext())) {
                        return;
                    }
                    AppPreferences.setThemeMode(requireContext(), newMode);
                    ThemeHelper.apply(requireContext());
                    if (getActivity() != null) {
                        getActivity().recreate();
                    }
                })
                .create();
        themeDialog.show();
    }

    private void confirmDeleteAll() {
        new MaterialAlertDialogBuilder(requireActivity(), DIALOG_THEME)
                .setTitle(R.string.settings_delete_all)
                .setMessage(R.string.settings_delete_confirm)
                .setNegativeButton(R.string.stats_cancel, null)
                .setPositiveButton(R.string.settings_delete_yes, (d, w) -> {
                    AppPreferences.clearAllData(requireContext());
                    Intent intent = new Intent(requireContext(), OnboardingActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    requireActivity().finish();
                })
                .show();
    }

    @NonNull
    private String formatThresholdSummary(@NonNull List<String> keys) {
        if (keys.isEmpty()) {
            return getString(R.string.settings_not_set);
        }
        List<String> labels = new ArrayList<>();
        for (String key : keys) {
            labels.add(thresholdLabel(key));
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < labels.size(); i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(labels.get(i));
        }
        return sb.toString();
    }

    @NonNull
    private String thresholdLabel(@NonNull String key) {
        switch (key) {
            case "1":
                return getString(R.string.reminder_threshold_1_day);
            case "3":
                return getString(R.string.reminder_threshold_3_days);
            case "5":
                return getString(R.string.reminder_threshold_5_days);
            case "15":
                return getString(R.string.reminder_threshold_15_days);
            case "30":
                return getString(R.string.reminder_threshold_1_month);
            case "7":
            default:
                return getString(R.string.reminder_threshold_7_days);
        }
    }

    @NonNull
    private String getThemeLabel(int mode) {
        if (mode == AppPreferences.THEME_LIGHT) {
            return getString(R.string.settings_theme_light);
        }
        if (mode == AppPreferences.THEME_DARK) {
            return getString(R.string.settings_theme_dark);
        }
        return getString(R.string.settings_theme_system);
    }

    @NonNull
    private static String textOrEmpty(@Nullable TextInputEditText editText) {
        if (editText == null || editText.getText() == null) {
            return "";
        }
        return editText.getText().toString().trim();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
