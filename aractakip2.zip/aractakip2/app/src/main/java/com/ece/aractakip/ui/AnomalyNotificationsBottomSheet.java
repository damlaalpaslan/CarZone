package com.ece.aractakip.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ece.aractakip.R;
import com.ece.aractakip.adapter.AnomalyNotificationAdapter;
import com.ece.aractakip.data.AnomalyNotificationRepository;
import com.ece.aractakip.databinding.BottomSheetAnomalyNotificationsBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class AnomalyNotificationsBottomSheet extends BottomSheetDialogFragment {

    public interface Listener {
        void onNotificationsUpdated();
    }

    @Nullable
    private BottomSheetAnomalyNotificationsBinding binding;
    @Nullable
    private Listener listener;
    private AnomalyNotificationAdapter adapter;

    public static AnomalyNotificationsBottomSheet newInstance() {
        return new AnomalyNotificationsBottomSheet();
    }

    public void setListener(@Nullable Listener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = BottomSheetAnomalyNotificationsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }

        AnomalyNotificationRepository.markAllRead(requireContext());
        notifyHost();

        adapter = new AnomalyNotificationAdapter(requireContext());
        binding.recyclerAnomalyNotifications.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerAnomalyNotifications.setAdapter(adapter);

        AnomalyNotificationSwipeCallback swipeCallback = new AnomalyNotificationSwipeCallback(
                requireContext(),
                adapter,
                item -> {
                    AnomalyNotificationRepository.delete(requireContext(), item.getId());
                    updateEmptyState();
                    notifyHost();
                }
        );
        new ItemTouchHelper(swipeCallback).attachToRecyclerView(binding.recyclerAnomalyNotifications);

        binding.buttonClearAnomalies.setOnClickListener(v -> {
            AnomalyNotificationRepository.clearAll(requireContext());
            renderList();
            Toast.makeText(requireContext(), R.string.anomaly_notifications_cleared, Toast.LENGTH_SHORT).show();
            notifyHost();
        });

        renderList();
    }

    private void updateEmptyState() {
        if (binding == null || adapter == null) {
            return;
        }
        boolean isEmpty = adapter.getItemCount() == 0;
        binding.textAnomalyEmpty.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        binding.recyclerAnomalyNotifications.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
        binding.buttonClearAnomalies.setEnabled(!isEmpty);
    }

    private void renderList() {
        if (binding == null || adapter == null) {
            return;
        }
        adapter.submitList(AnomalyNotificationRepository.getAll(requireContext()));
        updateEmptyState();
    }

    private void notifyHost() {
        if (listener != null) {
            listener.onNotificationsUpdated();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
