package com.ece.aractakip.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.ece.aractakip.R;
import com.ece.aractakip.data.AppPreferences;
import com.ece.aractakip.data.DatabaseHelper;
import com.ece.aractakip.databinding.FragmentExpenseAnalysisBinding;
import com.ece.aractakip.model.ExpenseEntry;
import com.ece.aractakip.util.ExpenseChartHelper;
import com.ece.aractakip.util.NumberInputFormatUtil;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.text.NumberFormat;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

public class ExpenseAnalysisFragment extends Fragment implements StatsCategoryBottomSheet.Listener {

    public interface ExpenseAnalysisHost {
        void onCloseExpenseAnalysis();
    }

    private static final int DIALOG_THEME = R.style.ThemeOverlay_Aractakip_AlertDialog;

    @Nullable
    private FragmentExpenseAnalysisBinding binding;
    private DatabaseHelper databaseHelper;
    private final Locale trLocale = new Locale("tr", "TR");

    public static ExpenseAnalysisFragment newInstance() {
        return new ExpenseAnalysisFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentExpenseAnalysisBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }
        databaseHelper = DatabaseHelper.getInstance(requireContext());
        binding.buttonExpenseAnalysisBack.setOnClickListener(v -> closeScreen());
        binding.fabExpenseAdd.setOnClickListener(v -> openCategorySheet());
        binding.cardMonthlyDistanceEntry.setOnClickListener(v -> showMileageInputDialog());
        renderAll();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (binding != null) {
            renderAll();
        }
    }

    private void openCategorySheet() {
        StatsCategoryBottomSheet sheet = StatsCategoryBottomSheet.newInstance();
        sheet.setListener(this);
        sheet.show(getParentFragmentManager(), "expense_category");
    }

    @Override
    public void onCategorySelected(@NonNull ExpenseEntry.Category category) {
        showExpenseAmountDialog(category);
    }

    private void renderAll() {
        if (binding == null || databaseHelper == null) {
            return;
        }
        ExpenseChartHelper.Totals totals = ExpenseChartHelper.loadTotals(requireContext(), databaseHelper);
        ExpenseChartHelper.renderPieChart(
                requireContext(),
                binding.chartExpenses,
                binding.textExpenseEmpty,
                totals);
        updateCategoryCards(totals);
        updateHighestExpense(totals);
    }

    private void updateCategoryCards(@NonNull ExpenseChartHelper.Totals totals) {
        if (binding == null) {
            return;
        }
        NumberFormat currency = NumberFormat.getCurrencyInstance(trLocale);
        binding.textAmountService.setText(currency.format(totals.servis));
        binding.textAmountInsurance.setText(currency.format(totals.sigorta));
        binding.textAmountMaintenance.setText(currency.format(totals.bakim));
        binding.textAmountFuel.setText(currency.format(totals.yakit));
        binding.textAmountService.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.expense_chart_service));
        binding.textAmountInsurance.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.expense_chart_insurance));
        binding.textAmountMaintenance.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.expense_chart_maintenance));
        binding.textAmountFuel.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.expense_chart_fuel));
    }

    private void updateHighestExpense(@NonNull ExpenseChartHelper.Totals totals) {
        if (binding == null) {
            return;
        }
        ExpenseChartHelper.CategoryAmount highest = totals.getHighestCategory(requireContext());
        if (highest == null) {
            binding.textHighestExpense.setText(R.string.stats_no_expense_data);
            return;
        }
        NumberFormat currency = NumberFormat.getCurrencyInstance(trLocale);
        binding.textHighestExpense.setText(getString(
                R.string.expense_analysis_highest_template,
                highest.label,
                currency.format(highest.amount)));
    }

    private void showMileageInputDialog() {
        View dialogView = LayoutInflater.from(requireContext())
                .inflate(R.layout.dialog_stats_mileage_input, null, false);
        com.google.android.material.textfield.MaterialAutoCompleteTextView autoMonth =
                dialogView.findViewById(R.id.autoMonth);
        com.google.android.material.textfield.TextInputEditText editKm =
                dialogView.findViewById(R.id.editCurrentKm);
        com.google.android.material.textfield.TextInputLayout tilKm =
                dialogView.findViewById(R.id.tilCurrentKm);

        List<YearMonth> monthValues = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        DateTimeFormatter display = DateTimeFormatter.ofPattern("MMMM yyyy", trLocale);
        YearMonth now = YearMonth.now();
        for (int i = 0; i < 12; i++) {
            YearMonth value = now.minusMonths(i);
            monthValues.add(value);
            String label = value.atDay(1).format(display);
            labels.add(label.substring(0, 1).toUpperCase(trLocale) + label.substring(1));
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_dropdown_item_1line,
                labels
        );
        autoMonth.setAdapter(adapter);
        if (!labels.isEmpty()) {
            autoMonth.setText(labels.get(0), false);
        }

        LinkedHashMap<String, Integer> savedOdometers =
                AppPreferences.getMonthlyOdometers(requireContext());
        final int[] selectedMonthIndex = {0};
        Runnable fillKmForSelectedMonth = () -> {
            Integer existing = savedOdometers.get(monthValues.get(selectedMonthIndex[0]).toString());
            editKm.setText(existing == null ? "" : NumberInputFormatUtil.formatGroupedInteger(existing));
        };
        fillKmForSelectedMonth.run();
        NumberInputFormatUtil.attachGroupedInteger(editKm);
        autoMonth.setOnItemClickListener((parent, view, position, id) -> {
            selectedMonthIndex[0] = position;
            fillKmForSelectedMonth.run();
        });

        AlertDialog dialog = new MaterialAlertDialogBuilder(requireActivity(), DIALOG_THEME)
                .setTitle(R.string.stats_action_update_mileage)
                .setView(dialogView)
                .setNegativeButton(R.string.stats_cancel, null)
                .setPositiveButton(R.string.stats_save, null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String kmRaw = editKm.getText() == null ? "" : editKm.getText().toString().trim();
            if (TextUtils.isEmpty(kmRaw)) {
                tilKm.setError(getString(R.string.stats_error_km_required));
                return;
            }
            int km;
            try {
                km = NumberInputFormatUtil.parseGroupedInteger(kmRaw);
                if (km <= 0) {
                    throw new NumberFormatException("km");
                }
            } catch (NumberFormatException e) {
                tilKm.setError(getString(R.string.stats_error_km_invalid));
                return;
            }
            tilKm.setError(null);
            String selectedMonthLabel = autoMonth.getText() == null
                    ? "" : autoMonth.getText().toString().trim();
            for (int i = 0; i < labels.size(); i++) {
                if (labels.get(i).equalsIgnoreCase(selectedMonthLabel)) {
                    selectedMonthIndex[0] = i;
                    break;
                }
            }
            YearMonth selectedMonth = monthValues.get(selectedMonthIndex[0]);
            AppPreferences.saveMonthlyOdometer(requireContext(), selectedMonth.toString(), km);
            Toast.makeText(requireContext(), R.string.stats_saved, Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void showExpenseAmountDialog(@NonNull ExpenseEntry.Category category) {
        View dialogView = LayoutInflater.from(requireContext())
                .inflate(R.layout.dialog_stats_expense_amount, null, false);
        com.google.android.material.textfield.TextInputEditText editAmount =
                dialogView.findViewById(R.id.editExpenseAmount);
        com.google.android.material.textfield.TextInputLayout tilAmount =
                dialogView.findViewById(R.id.tilExpenseAmount);

        NumberInputFormatUtil.attachGroupedDecimal(editAmount);

        new MaterialAlertDialogBuilder(requireActivity(), DIALOG_THEME)
                .setTitle(R.string.stats_action_add_expense)
                .setView(dialogView)
                .setNegativeButton(R.string.stats_cancel, null)
                .setPositiveButton(R.string.stats_save, (dialog, which) -> {
                    String amountRaw = editAmount.getText() == null ? "" : editAmount.getText().toString().trim();
                    if (TextUtils.isEmpty(amountRaw)) {
                        Toast.makeText(requireContext(), R.string.stats_error_amount_required, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    float amount;
                    try {
                        amount = ExpenseChartHelper.parseAmount(amountRaw);
                    } catch (NumberFormatException e) {
                        tilAmount.setError(getString(R.string.stats_error_amount_invalid));
                        return;
                    }
                    tilAmount.setError(null);
                    AppPreferences.addExpense(requireContext(),
                            new ExpenseEntry(System.currentTimeMillis(), category, amount));
                    renderAll();
                    Toast.makeText(requireContext(), R.string.stats_saved, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void closeScreen() {
        if (getActivity() instanceof ExpenseAnalysisHost) {
            ((ExpenseAnalysisHost) getActivity()).onCloseExpenseAnalysis();
        } else {
            requireActivity().getOnBackPressedDispatcher().onBackPressed();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
