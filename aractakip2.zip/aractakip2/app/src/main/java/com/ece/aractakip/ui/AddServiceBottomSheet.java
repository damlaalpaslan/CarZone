package com.ece.aractakip.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.ece.aractakip.R;
import com.ece.aractakip.data.AppPreferences;
import com.ece.aractakip.databinding.DialogAddServiceBinding;
import com.ece.aractakip.model.ServiceHistoryEntry;
import com.ece.aractakip.model.ServiceSubCategoryOption;
import com.ece.aractakip.util.DateInputUtils;
import com.ece.aractakip.util.MaterialDatePickerHelper;
import com.ece.aractakip.util.NumberInputFormatUtil;
import com.ece.aractakip.util.ServiceSubCategoryCatalog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class AddServiceBottomSheet extends BottomSheetDialogFragment {

    public interface ServiceFormListener {
        void onServiceSaved(@NonNull ServiceHistoryEntry entry);
    }

    @Nullable
    private DialogAddServiceBinding binding;
    @Nullable
    private ServiceSubCategoryCatalog.MainCategory selectedMainCategory;
    @Nullable
    private String selectedSubCategoryLabel;
    @Nullable
    private ServiceFormListener formListener;

    public static AddServiceBottomSheet newInstance() {
        return new AddServiceBottomSheet();
    }

    public void setServiceFormListener(@Nullable ServiceFormListener listener) {
        this.formListener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DialogAddServiceBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }

        binding.radioMainCategory.clearCheck();
        resetSubCategorySelection();
        setupCategoryListeners();
        MaterialDatePickerHelper.attachToDateField(this, binding.editServiceDate);
        NumberInputFormatUtil.attachGroupedDecimal(binding.editServiceCost);
        binding.buttonSaveService.setOnClickListener(v -> saveService());
    }

    private void setupCategoryListeners() {
        if (binding == null) {
            return;
        }

        binding.radioMainCategory.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioPeriodicMaintenance) {
                selectedMainCategory = ServiceSubCategoryCatalog.MainCategory.PERIODIC;
            } else if (checkedId == R.id.radioRepair) {
                selectedMainCategory = ServiceSubCategoryCatalog.MainCategory.REPAIR;
            } else {
                selectedMainCategory = null;
            }
            resetSubCategorySelection();
        });

        binding.layoutSubCategoryDropdown.getRoot().setOnClickListener(v -> openSubCategoryPicker());
    }

    private void openSubCategoryPicker() {
        if (selectedMainCategory == null) {
            Toast.makeText(requireContext(), R.string.service_select_main_category_first, Toast.LENGTH_SHORT).show();
            return;
        }

        ServiceSubCategoryBottomSheet sheet =
                ServiceSubCategoryBottomSheet.newInstance(selectedMainCategory);
        sheet.setSelectionListener(this::onSubCategorySelected);
        sheet.show(getChildFragmentManager(), "service_sub_category");
    }

    private void onSubCategorySelected(@NonNull ServiceSubCategoryOption option) {
        if (binding == null) {
            return;
        }

        selectedSubCategoryLabel = option.getLabel();
        binding.layoutSubCategoryDropdown.textSubCategoryValue.setText(option.getLabel());
        binding.layoutSubCategoryDropdown.textSubCategoryValue.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.black));
        updateCustomInputVisibility(option.getLabel());
    }

    private void resetSubCategorySelection() {
        if (binding == null) {
            return;
        }

        selectedSubCategoryLabel = null;
        binding.layoutSubCategoryDropdown.textSubCategoryValue.setText(R.string.service_sub_category_placeholder);
        binding.layoutSubCategoryDropdown.textSubCategoryValue.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.setup_text_secondary));
        updateCustomInputVisibility(null);
    }

    private void updateCustomInputVisibility(@Nullable String selectedLabel) {
        if (binding == null) {
            return;
        }

        boolean showCustom = getString(R.string.service_custom_operation_option).equals(selectedLabel);
        ViewGroup root = (ViewGroup) binding.getRoot();
        TransitionManager.beginDelayedTransition(root, new AutoTransition());

        binding.tilCustomOperation.setVisibility(showCustom ? View.VISIBLE : View.GONE);
        if (!showCustom && binding.editCustomOperation.getText() != null) {
            binding.editCustomOperation.setText("");
        }
    }

    private void saveService() {
        if (binding == null || formListener == null) {
            dismiss();
            return;
        }

        if (selectedMainCategory == null) {
            Toast.makeText(requireContext(), R.string.service_select_main_category_first, Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(selectedSubCategoryLabel)) {
            Toast.makeText(requireContext(), R.string.service_error_subcategory_required, Toast.LENGTH_SHORT).show();
            return;
        }

        String title = selectedSubCategoryLabel;
        if (getString(R.string.service_custom_operation_option).equals(selectedSubCategoryLabel)) {
            title = binding.editCustomOperation.getText() == null
                    ? "" : binding.editCustomOperation.getText().toString().trim();
            if (title.isEmpty()) {
                binding.tilCustomOperation.setError(getString(R.string.service_error_custom_required));
                return;
            }
            binding.tilCustomOperation.setError(null);
        }

        String costRaw = binding.editServiceCost.getText() == null
                ? "" : binding.editServiceCost.getText().toString().trim();
        if (costRaw.isEmpty()) {
            binding.tilServiceCost.setError(getString(R.string.stats_error_amount_required));
            return;
        }
        double cost;
        try {
            cost = NumberInputFormatUtil.parseGroupedDecimal(costRaw);
        } catch (NumberFormatException e) {
            binding.tilServiceCost.setError(getString(R.string.stats_error_amount_invalid));
            return;
        }
        binding.tilServiceCost.setError(null);

        String dateRaw = binding.editServiceDate.getText() == null
                ? "" : binding.editServiceDate.getText().toString().trim();
        if (dateRaw.isEmpty()) {
            binding.tilServiceDate.setError(getString(R.string.setup_error_date));
            return;
        }
        long dateMs = DateInputUtils.parseTurkishDateOrZero(dateRaw);
        if (dateMs == -1L) {
            binding.tilServiceDate.setError(getString(R.string.setup_error_date));
            return;
        }
        binding.tilServiceDate.setError(null);

        String note = binding.editServiceNote.getText() == null
                ? "" : binding.editServiceNote.getText().toString().trim();
        int mileage = Math.max(0, AppPreferences.loadVehicle(requireContext()).getMileage());

        ServiceHistoryEntry.Type type = selectedMainCategory == ServiceSubCategoryCatalog.MainCategory.REPAIR
                ? ServiceHistoryEntry.Type.REPAIR
                : ServiceHistoryEntry.Type.PERIODIC_MAINTENANCE;

        ServiceHistoryEntry entry = new ServiceHistoryEntry(
                System.currentTimeMillis(),
                title,
                type,
                mileage,
                dateRaw,
                note,
                cost,
                dateMs
        );
        formListener.onServiceSaved(entry);
        dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
