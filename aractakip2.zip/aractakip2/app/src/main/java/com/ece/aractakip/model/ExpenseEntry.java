package com.ece.aractakip.model;

import androidx.annotation.NonNull;

public class ExpenseEntry {

    public enum Category {
        SERVIS,
        SIGORTA,
        BAKIM,
        YAKIT
    }

    private final long createdAtMs;
    @NonNull
    private final Category category;
    private final float amount;

    public ExpenseEntry(long createdAtMs, @NonNull Category category, float amount) {
        this.createdAtMs = createdAtMs;
        this.category = category;
        this.amount = amount;
    }

    public long getCreatedAtMs() {
        return createdAtMs;
    }

    @NonNull
    public Category getCategory() {
        return category;
    }

    public float getAmount() {
        return amount;
    }
}
