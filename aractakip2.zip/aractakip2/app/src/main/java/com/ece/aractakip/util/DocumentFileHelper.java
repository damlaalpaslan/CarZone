package com.ece.aractakip.util;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;

import com.ece.aractakip.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

public final class DocumentFileHelper {

    private DocumentFileHelper() {
    }

    @Nullable
    public static String persistDocumentFile(@NonNull Context context,
                                             @NonNull Uri sourceUri,
                                             long documentId) {
        try {
            String ext = resolveExtension(context, sourceUri);
            File dir = new File(context.getFilesDir(), "documents");
            if (!dir.exists() && !dir.mkdirs()) {
                return null;
            }
            File dest = new File(dir, documentId + ext);
            try (InputStream in = context.getContentResolver().openInputStream(sourceUri);
                 OutputStream out = new FileOutputStream(dest)) {
                if (in == null) {
                    return null;
                }
                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
            }
            return dest.getAbsolutePath();
        } catch (IOException ignored) {
            return null;
        }
    }

    @NonNull
    private static String resolveExtension(@NonNull Context context, @NonNull Uri uri) {
        String mime = context.getContentResolver().getType(uri);
        if (mime != null) {
            if (mime.equals("application/pdf")) {
                return ".pdf";
            }
            if (mime.startsWith("image/")) {
                String sub = mime.substring("image/".length());
                if ("jpeg".equals(sub)) {
                    return ".jpg";
                }
                if (!sub.isEmpty()) {
                    return "." + sub;
                }
            }
        }

        String name = queryDisplayName(context, uri);
        if (name != null) {
            int dot = name.lastIndexOf('.');
            if (dot >= 0 && dot < name.length() - 1) {
                return name.substring(dot).toLowerCase(Locale.ROOT);
            }
        }

        String path = uri.getPath();
        if (path != null) {
            int dot = path.lastIndexOf('.');
            if (dot >= 0 && dot < path.length() - 1) {
                return path.substring(dot).toLowerCase(Locale.ROOT);
            }
        }

        return ".jpg";
    }

    @Nullable
    private static String queryDisplayName(@NonNull Context context, @NonNull Uri uri) {
        try (Cursor cursor = context.getContentResolver().query(
                uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    return cursor.getString(index);
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    @Nullable
    public static String displayName(@NonNull Context context, @NonNull String storedUri) {
        if (storedUri.startsWith("content://")) {
            String name = queryDisplayName(context, Uri.parse(storedUri));
            if (name != null && !name.isEmpty()) {
                return name;
            }
        }
        File file = new File(storedUri);
        String name = file.getName();
        return name.isEmpty() ? null : name;
    }

    @Nullable
    public static Uri resolveViewUri(@NonNull Context context, @NonNull String storedUri) {
        if (storedUri.startsWith("content://")) {
            return Uri.parse(storedUri);
        }
        File file = new File(storedUri);
        if (!file.exists()) {
            return null;
        }
        return FileProvider.getUriForFile(
                context,
                context.getPackageName() + ".fileprovider",
                file
        );
    }

    public static boolean isImage(@Nullable String storedUri) {
        if (storedUri == null || storedUri.isEmpty()) {
            return false;
        }
        String lower = storedUri.toLowerCase(Locale.ROOT);
        return lower.endsWith(".jpg")
                || lower.endsWith(".jpeg")
                || lower.endsWith(".png")
                || lower.endsWith(".webp")
                || lower.endsWith(".gif");
    }

    public static boolean isPdf(@Nullable String storedUri) {
        return storedUri != null && storedUri.toLowerCase(Locale.ROOT).endsWith(".pdf");
    }

    public static boolean hasAttachment(@Nullable String storedUri) {
        return storedUri != null && !storedUri.isEmpty();
    }

    public static void openDocument(@NonNull Context context, @NonNull String storedUri) {
        Uri uri = resolveViewUri(context, storedUri);
        if (uri == null) {
            return;
        }
        String mime = isPdf(storedUri)
                ? "application/pdf"
                : context.getContentResolver().getType(uri);
        if (mime == null || mime.isEmpty()) {
            String ext = MimeTypeMap.getFileExtensionFromUrl(uri.toString());
            String guessed = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            mime = guessed != null ? guessed : "image/*";
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, mime);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        context.startActivity(Intent.createChooser(
                intent,
                context.getString(R.string.document_open_file)
        ));
    }

    @NonNull
    public static File createCameraOutputFile(@NonNull Context context, long documentId) throws IOException {
        File dir = new File(context.getCacheDir(), "camera");
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Cannot create camera cache directory");
        }
        return new File(dir, "capture_" + documentId + ".jpg");
    }

    public static void deleteStoredFile(@Nullable String storedUri) {
        if (storedUri == null || storedUri.isEmpty() || storedUri.startsWith("content://")) {
            return;
        }
        File file = new File(storedUri);
        if (file.exists()) {
            file.delete();
        }
    }
}
