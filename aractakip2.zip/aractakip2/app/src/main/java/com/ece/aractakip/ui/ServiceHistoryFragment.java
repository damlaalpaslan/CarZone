package com.ece.aractakip.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ece.aractakip.MainActivity;
import com.ece.aractakip.R;
import com.ece.aractakip.adapter.ServiceHistoryAdapter;
import com.ece.aractakip.data.AppPreferences;
import com.ece.aractakip.databinding.FragmentServiceHistoryBinding;
import com.ece.aractakip.model.ServiceHistoryEntry;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class ServiceHistoryFragment extends Fragment implements
        ServiceHistoryAdapter.ServiceHistoryClickListener {

    public interface ServiceHistoryHost {
        void onCloseServiceHistory();
    }

    private static final int DIALOG_THEME = R.style.ThemeOverlay_Aractakip_AlertDialog;

    @Nullable
    private FragmentServiceHistoryBinding binding;
    private ServiceHistoryAdapter adapter;
    private final List<ServiceHistoryEntry> entries = new ArrayList<>();
    private ServiceHistoryAdapter.FilterType activeFilter = ServiceHistoryAdapter.FilterType.ALL;

    public static ServiceHistoryFragment newInstance() {
        return new ServiceHistoryFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentServiceHistoryBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }

        adapter = new ServiceHistoryAdapter(requireContext(), this);
        binding.recyclerServiceHistory.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerServiceHistory.setAdapter(adapter);

        binding.buttonServiceBack.setOnClickListener(v -> closeScreen());
        binding.fabAddService.setOnClickListener(v -> showAddServiceBottomSheet());

        binding.chipFilterAll.setOnClickListener(v -> selectFilter(ServiceHistoryAdapter.FilterType.ALL));
        binding.chipFilterPeriodic.setOnClickListener(v ->
                selectFilter(ServiceHistoryAdapter.FilterType.PERIODIC));
        binding.chipFilterRepair.setOnClickListener(v ->
                selectFilter(ServiceHistoryAdapter.FilterType.REPAIR));

        loadEntries();
        renderScreen();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadEntries();
        renderScreen();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onServiceEntryClick(@NonNull ServiceHistoryEntry entry) {
        new MaterialAlertDialogBuilder(requireActivity(), DIALOG_THEME)
                .setMessage(getString(R.string.service_history_delete_message, entry.getTitle()))
                .setNegativeButton(R.string.stats_cancel, null)
                .setPositiveButton(R.string.action_delete, (dialog, which) -> {
                    AppPreferences.removeServiceHistoryEntry(requireContext(), entry.getId());
                    loadEntries();
                    renderScreen();
                    Toast.makeText(requireContext(), R.string.service_history_deleted, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void closeScreen() {
        if (requireActivity() instanceof ServiceHistoryHost) {
            ((ServiceHistoryHost) requireActivity()).onCloseServiceHistory();
        } else if (requireActivity() instanceof MainActivity) {
            requireActivity().getOnBackPressedDispatcher().onBackPressed();
        }
    }

    private void showAddServiceBottomSheet() {
        AddServiceBottomSheet sheet = AddServiceBottomSheet.newInstance();
        sheet.setServiceFormListener(entry -> {
            AppPreferences.addServiceHistoryEntry(requireContext(), entry);
            loadEntries();
            renderScreen();
        });
        sheet.show(getParentFragmentManager(), "add_service");
    }

    private void selectFilter(@NonNull ServiceHistoryAdapter.FilterType filterType) {
        activeFilter = filterType;
        updateChipStyles();
        adapter.setFilter(filterType);
        updateEmptyState();
    }

    private void updateChipStyles() {
        if (binding == null) {
            return;
        }
        styleChip(binding.chipFilterAll, activeFilter == ServiceHistoryAdapter.FilterType.ALL);
        styleChip(binding.chipFilterPeriodic, activeFilter == ServiceHistoryAdapter.FilterType.PERIODIC);
        styleChip(binding.chipFilterRepair, activeFilter == ServiceHistoryAdapter.FilterType.REPAIR);
    }

    private void styleChip(@NonNull TextView chip, boolean selected) {
        Context context = chip.getContext();
        if (selected) {
            chip.setBackgroundResource(R.drawable.bg_service_chip_active);
            chip.setTextColor(ContextCompat.getColor(context, R.color.white));
            chip.setTypeface(chip.getTypeface(), android.graphics.Typeface.BOLD);
        } else {
            chip.setBackgroundResource(R.drawable.bg_service_chip_inactive);
            chip.setTextColor(ContextCompat.getColor(context, R.color.black));
            chip.setTypeface(chip.getTypeface(), android.graphics.Typeface.NORMAL);
        }
    }

    private void loadEntries() {
        entries.clear();
        entries.addAll(AppPreferences.getServiceHistory(requireContext()));
        entries.sort(Comparator.comparingLong(ServiceHistoryEntry::getServiceDateMs).reversed());
    }

    private void renderScreen() {
        if (binding == null) {
            return;
        }

        double totalCost = 0;
        int minYear = Integer.MAX_VALUE;
        int maxYear = Integer.MIN_VALUE;
        for (ServiceHistoryEntry entry : entries) {
            totalCost += entry.getCost();
            Calendar calendar = Calendar.getInstance(Locale.forLanguageTag("tr-TR"));
            calendar.setTimeInMillis(entry.getServiceDateMs());
            int year = calendar.get(Calendar.YEAR);
            minYear = Math.min(minYear, year);
            maxYear = Math.max(maxYear, year);
        }

        binding.textTotalServiceCost.setText(ServiceHistoryAdapter.formatTotalCost(totalCost));
        if (!entries.isEmpty()) {
            binding.textServiceYearRange.setText(
                    getString(R.string.service_history_year_range, minYear, maxYear));
            binding.textServiceYearRange.setVisibility(View.VISIBLE);
        } else {
            binding.textServiceYearRange.setVisibility(View.GONE);
            binding.textDaysSinceService.setText("—");
            binding.textLastServiceDate.setText("—");
        }

        ServiceHistoryEntry latest = entries.isEmpty() ? null : entries.get(0);
        if (latest != null) {
            long daysSince = TimeUnit.MILLISECONDS.toDays(
                    System.currentTimeMillis() - latest.getServiceDateMs());
            binding.textDaysSinceService.setText(
                    getString(R.string.service_history_days_since, Math.max(0, (int) daysSince)));
            binding.textLastServiceDate.setText(formatLongTurkishDate(latest.getServiceDateMs()));
        }

        updateChipStyles();
        adapter.submitList(entries);
        adapter.setFilter(activeFilter);
        updateEmptyState();
    }

    private void updateEmptyState() {
        if (binding == null) {
            return;
        }
        boolean isEmpty = entries.isEmpty();
        binding.layoutEmptyState.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        binding.recyclerServiceHistory.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
    }

    @NonNull
    private String formatLongTurkishDate(long dateMs) {
        SimpleDateFormat formatter = new SimpleDateFormat("d MMMM yyyy", new Locale("tr", "TR"));
        return formatter.format(dateMs);
    }
}
