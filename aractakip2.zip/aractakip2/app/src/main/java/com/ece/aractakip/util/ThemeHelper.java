package com.ece.aractakip.util;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;

import com.ece.aractakip.data.AppPreferences;

public final class ThemeHelper {

    private ThemeHelper() {
    }

    public static void apply(@NonNull Context context) {
        int mode = AppPreferences.getThemeMode(context);
        if (mode == AppPreferences.THEME_LIGHT) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        } else if (mode == AppPreferences.THEME_DARK) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        }
    }
}
