package com.ece.aractakip.ui;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.ColorRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ece.aractakip.R;
import com.ece.aractakip.adapter.ServiceAdapter;
import com.ece.aractakip.databinding.FragmentNearServicesBinding;
import com.ece.aractakip.model.NearbyServiceItem;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONObject;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class NearServicesFragment extends Fragment implements ServiceAdapter.ServiceClickListener {

    public interface NearServicesHost {
        void onCloseNearServices();
    }

    private enum TypeTab {
        ALL,
        FUEL,
        EV
    }

    private static final double DEFAULT_ZOOM = 15.0;
    private static final long LOCATION_MIN_TIME_MS = 1_000L;
    private static final float LOCATION_MIN_DISTANCE_M = 0f;
    private static final float REFETCH_STATIONS_DISTANCE_M = 150f;
    private static final long STATION_FETCH_TIMEOUT_MS = 40_000L;
    private static final int MAX_FUEL_STATIONS = 5;
    private static final int MAX_EV_STATIONS = 5;
    private static final String[] OVERPASS_ENDPOINTS = {
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter",
            "https://lz4.overpass-api.de/api/interpreter"
    };
    private static final int SEARCH_RADIUS_METERS = 5_000;

    private final OkHttpClient overpassClient = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build();
    @Nullable
    private ExecutorService fetchExecutor;
    private volatile long fetchGeneration;
    private volatile boolean stationsLoading;

    @Nullable
    private FragmentNearServicesBinding binding;
    @Nullable
    private ServiceAdapter adapter;
    @Nullable
    private LocationManager locationManager;
    @Nullable
    private LocationListener locationListener;

    private final List<NearbyServiceItem> allStations = new ArrayList<>();
    private final Map<String, Marker> markerById = new HashMap<>();

    private TypeTab activeTypeTab = TypeTab.ALL;

    @Nullable
    private Marker highlightedMarker;
    @Nullable
    private Marker myLocationMarker;
    @Nullable
    private GeoPoint userLocation;
    private double lastFetchedLat = Double.NaN;
    private double lastFetchedLon = Double.NaN;
    private long suppressUserMapCenterUntilMs;
    @Nullable
    private Runnable stationFetchTimeoutRunnable;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final ActivityResultLauncher<String[]> locationPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean granted = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION))
                        || Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_COARSE_LOCATION));
                if (granted) {
                    startLocationUpdates();
                } else {
                    showWaitingForLocation();
                }
            });

    public static NearServicesFragment newInstance() {
        return new NearServicesFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Context appContext = requireContext().getApplicationContext();
        Configuration.getInstance().load(appContext,
                PreferenceManager.getDefaultSharedPreferences(appContext));
        Configuration.getInstance().setUserAgentValue(requireContext().getPackageName());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentNearServicesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }

        adapter = new ServiceAdapter(requireContext(), this);
        binding.recyclerServices.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerServices.setAdapter(adapter);

        binding.buttonNearServicesBack.setOnClickListener(v -> closeScreen());
        setupMap();
        setupTabs();
        fetchExecutor = Executors.newSingleThreadExecutor();
        showWaitingForLocation();
        requestLocationPermissionAndStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (binding != null) {
            binding.mapView.onResume();
        }
        if (hasLocationPermission()) {
            startLocationUpdates();
        }
    }

    @Override
    public void onPause() {
        stopLocationUpdates();
        if (binding != null) {
            binding.mapView.onPause();
        }
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        fetchGeneration++;
        stationsLoading = false;
        clearStationFetchTimeout();
        overpassClient.dispatcher().cancelAll();
        if (fetchExecutor != null) {
            fetchExecutor.shutdownNow();
            fetchExecutor = null;
        }
        stopLocationUpdates();
        if (binding != null) {
            binding.mapView.getOverlays().clear();
        }
        allStations.clear();
        markerById.clear();
        highlightedMarker = null;
        myLocationMarker = null;
        userLocation = null;
        lastFetchedLat = Double.NaN;
        lastFetchedLon = Double.NaN;
        binding = null;
        adapter = null;
        super.onDestroyView();
    }

    @Override
    public void onServiceClick(@NonNull NearbyServiceItem item) {
        focusStationOnMap(item, true);
    }

    private void requestLocationPermissionAndStart() {
        if (hasLocationPermission()) {
            startLocationUpdates();
            return;
        }
        locationPermissionLauncher.launch(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        });
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("MissingPermission")
    private void startLocationUpdates() {
        if (!hasLocationPermission() || binding == null) {
            return;
        }

        locationManager = (LocationManager) requireContext().getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) {
            return;
        }

        if (locationListener == null) {
            locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(@NonNull Location location) {
                    onUserLocationChanged(location.getLatitude(), location.getLongitude());
                }

                @Override
                public void onProviderEnabled(@NonNull String provider) {
                }

                @Override
                public void onProviderDisabled(@NonNull String provider) {
                }
            };
        }

        try {
            Location lastKnown = getLastKnownLocation();
            if (lastKnown != null) {
                onUserLocationChanged(lastKnown.getLatitude(), lastKnown.getLongitude());
            }

            requestSingleFix(LocationManager.GPS_PROVIDER);
            requestSingleFix(LocationManager.NETWORK_PROVIDER);

            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        LOCATION_MIN_TIME_MS,
                        LOCATION_MIN_DISTANCE_M,
                        locationListener,
                        Looper.getMainLooper());
            }
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        LOCATION_MIN_TIME_MS,
                        LOCATION_MIN_DISTANCE_M,
                        locationListener,
                        Looper.getMainLooper());
            }
        } catch (SecurityException ignored) {
        }
    }

    @SuppressLint("MissingPermission")
    private void requestSingleFix(@NonNull String provider) {
        if (locationManager == null || locationListener == null) {
            return;
        }
        if (!locationManager.isProviderEnabled(provider)) {
            return;
        }
        locationManager.requestSingleUpdate(provider, locationListener, Looper.getMainLooper());
    }

    @SuppressLint("MissingPermission")
    @Nullable
    private Location getLastKnownLocation() {
        if (locationManager == null) {
            return null;
        }
        Location best = null;
        try {
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                best = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (gps != null && (best == null || gps.getTime() > best.getTime())) {
                    best = gps;
                }
            }
        } catch (SecurityException ignored) {
        }
        return best;
    }

    private void stopLocationUpdates() {
        if (locationManager != null && locationListener != null) {
            locationManager.removeUpdates(locationListener);
        }
    }

    private void onUserLocationChanged(double latitude, double longitude) {
        if (binding == null) {
            return;
        }

        userLocation = new GeoPoint(latitude, longitude);
        binding.textLocationBadge.setText(R.string.near_services_current_location);
        updateMyLocationMarker();

        if (shouldRefetchStations(latitude, longitude)) {
            if (beginStationFetch(latitude, longitude)) {
                showLoadingStations();
            }
        } else {
            recalculateDistances();
            applyFilters();
        }

        if (System.currentTimeMillis() >= suppressUserMapCenterUntilMs) {
            binding.mapView.getController().animateTo(userLocation, DEFAULT_ZOOM, 700L);
        }
    }

    private boolean shouldRefetchStations(double latitude, double longitude) {
        if (stationsLoading) {
            return false;
        }
        if (allStations.isEmpty() || Double.isNaN(lastFetchedLat) || Double.isNaN(lastFetchedLon)) {
            return true;
        }
        float[] moved = new float[1];
        Location.distanceBetween(lastFetchedLat, lastFetchedLon, latitude, longitude, moved);
        return moved[0] >= REFETCH_STATIONS_DISTANCE_M;
    }

    private boolean beginStationFetch(double latitude, double longitude) {
        if (fetchExecutor == null || stationsLoading) {
            return false;
        }
        stationsLoading = true;
        final long generation = fetchGeneration;
        scheduleStationFetchTimeout(generation);

        fetchExecutor.execute(() -> {
            List<NearbyServiceItem> fetched = Collections.emptyList();
            boolean failed = false;
            try {
                fetched = fetchLiveStationsFromOverpass(latitude, longitude);
            } catch (Exception e) {
                failed = true;
            }
            final List<NearbyServiceItem> stations = fetched;
            final boolean requestFailed = failed;
            mainHandler.post(() -> finishStationFetch(
                    generation, latitude, longitude, stations, requestFailed));
        });
        return true;
    }

    private void scheduleStationFetchTimeout(long generation) {
        clearStationFetchTimeout();
        stationFetchTimeoutRunnable = () -> {
            if (generation != fetchGeneration || !stationsLoading) {
                return;
            }
            stationsLoading = false;
            overpassClient.dispatcher().cancelAll();
            if (binding != null && allStations.isEmpty()) {
                onStationsLoadFailed();
            }
        };
        mainHandler.postDelayed(stationFetchTimeoutRunnable, STATION_FETCH_TIMEOUT_MS);
    }

    private void clearStationFetchTimeout() {
        if (stationFetchTimeoutRunnable != null) {
            mainHandler.removeCallbacks(stationFetchTimeoutRunnable);
            stationFetchTimeoutRunnable = null;
        }
    }

    private void finishStationFetch(long generation,
                                    double latitude,
                                    double longitude,
                                    @NonNull List<NearbyServiceItem> stations,
                                    boolean requestFailed) {
        clearStationFetchTimeout();
        stationsLoading = false;
        if (binding == null || generation != fetchGeneration) {
            return;
        }
        if (requestFailed) {
            onStationsLoadFailed();
        } else if (stations.isEmpty()) {
            allStations.clear();
            markerById.clear();
            lastFetchedLat = latitude;
            lastFetchedLon = longitude;
            applyFilters();
        } else {
            onStationsLoaded(stations, latitude, longitude);
        }
    }

    @NonNull
    private String buildOverpassQuery(double userLat, double userLon) {
        String lat = String.format(Locale.US, "%.6f", userLat);
        String lon = String.format(Locale.US, "%.6f", userLon);
        return "[out:json][timeout:25];"
                + "(node[\"amenity\"=\"fuel\"](around:" + SEARCH_RADIUS_METERS + "," + lat + "," + lon + ");"
                + "node[\"amenity\"=\"charging_station\"](around:" + SEARCH_RADIUS_METERS + "," + lat + "," + lon + ");"
                + "way[\"amenity\"=\"fuel\"](around:" + SEARCH_RADIUS_METERS + "," + lat + "," + lon + ");"
                + "way[\"amenity\"=\"charging_station\"](around:" + SEARCH_RADIUS_METERS + "," + lat + "," + lon + ");"
                + ");out center tags;";
    }

    @NonNull
    private List<NearbyServiceItem> fetchLiveStationsFromOverpass(double userLat, double userLon)
            throws IOException {
        IOException lastError = null;
        for (String endpoint : OVERPASS_ENDPOINTS) {
            try {
                List<NearbyServiceItem> stations = fetchFromOverpassEndpoint(endpoint, userLat, userLon);
                if (!stations.isEmpty()) {
                    return stations;
                }
            } catch (IOException e) {
                lastError = e;
            }
        }
        if (lastError != null) {
            throw lastError;
        }
        return Collections.emptyList();
    }

    @NonNull
    private List<NearbyServiceItem> fetchFromOverpassEndpoint(@NonNull String endpointUrl,
                                                              double userLat,
                                                              double userLon) throws IOException {
        String query = buildOverpassQuery(userLat, userLon);
        FormBody body = new FormBody.Builder()
                .add("data", query)
                .build();
        Request request = new Request.Builder()
                .url(endpointUrl)
                .post(body)
                .header("Accept", "application/json")
                .header("User-Agent", "Aractakip/1.0 (Android; OpenStreetMap Overpass)")
                .build();

        try (Response response = overpassClient.newCall(request).execute()) {
            ResponseBody responseBody = response.body();
            if (!response.isSuccessful() || responseBody == null) {
                throw new IOException(endpointUrl + " HTTP " + response.code());
            }
            return parseOverpassResponse(responseBody.string(), userLat, userLon);
        }
    }

    @NonNull
    private List<NearbyServiceItem> parseOverpassResponse(@NonNull String json,
                                                          double userLat,
                                                          double userLon) throws IOException {
        try {
            JSONObject root = new JSONObject(json);
            JSONArray elements = root.optJSONArray("elements");
            if (elements == null || elements.length() == 0) {
                return Collections.emptyList();
            }

            List<NearbyServiceItem> fuelStations = new ArrayList<>();
            List<NearbyServiceItem> evStations = new ArrayList<>();
            Set<String> seenKeys = new HashSet<>();

            for (int i = 0; i < elements.length(); i++) {
                JSONObject element = elements.getJSONObject(i);
                JSONObject tags = element.optJSONObject("tags");
                if (tags == null) {
                    continue;
                }

                String amenity = tags.optString("amenity", "");
                NearbyServiceItem.Type type;
                if ("fuel".equals(amenity)) {
                    type = NearbyServiceItem.Type.FUEL;
                } else if ("charging_station".equals(amenity)) {
                    type = NearbyServiceItem.Type.EV;
                } else {
                    continue;
                }

                double lat = element.optDouble("lat", Double.NaN);
                double lon = element.optDouble("lon", Double.NaN);
                if (Double.isNaN(lat) || Double.isNaN(lon)) {
                    JSONObject center = element.optJSONObject("center");
                    if (center != null) {
                        lat = center.optDouble("lat", Double.NaN);
                        lon = center.optDouble("lon", Double.NaN);
                    }
                }
                if (Double.isNaN(lat) || Double.isNaN(lon)) {
                    continue;
                }

                String name = resolveStationName(tags, type);
                String dedupeKey = Math.round(lat * 10_000d) + "|" + Math.round(lon * 10_000d);
                if (!seenKeys.add(dedupeKey)) {
                    continue;
                }

                int distanceMeters = Math.round(measureDistanceMeters(userLat, userLon, lat, lon));
                String id = "osm_" + element.optString("type", "node") + "_"
                        + element.optLong("id", i);

                NearbyServiceItem item = new NearbyServiceItem(
                        id,
                        name,
                        buildStationSubtitle(tags, type),
                        lat,
                        lon,
                        formatDistance(distanceMeters),
                        distanceMeters,
                        0f,
                        isOpenFromTags(tags),
                        type
                );

                if (type == NearbyServiceItem.Type.FUEL) {
                    fuelStations.add(item);
                } else {
                    evStations.add(item);
                }
            }

            Comparator<NearbyServiceItem> byDistance =
                    Comparator.comparingInt(NearbyServiceItem::getDistanceMeters);
            fuelStations.sort(byDistance);
            evStations.sort(byDistance);

            List<NearbyServiceItem> stations = new ArrayList<>();
            for (int i = 0; i < Math.min(MAX_FUEL_STATIONS, fuelStations.size()); i++) {
                stations.add(fuelStations.get(i));
            }
            for (int i = 0; i < Math.min(MAX_EV_STATIONS, evStations.size()); i++) {
                stations.add(evStations.get(i));
            }
            stations.sort(byDistance);
            return stations;
        } catch (Exception e) {
            throw new IOException("Overpass JSON parse failed", e);
        }
    }

    @NonNull
    private String resolveStationName(@NonNull JSONObject tags, @NonNull NearbyServiceItem.Type type) {
        String name = firstNonEmpty(
                tags.optString("name", ""),
                tags.optString("brand", ""),
                tags.optString("operator", ""));
        if (name != null) {
            return name;
        }
        if (type == NearbyServiceItem.Type.EV) {
            return "Elektrikli Şarj Noktası";
        }
        return "Akaryakıt İstasyonu";
    }

    @NonNull
    private String buildStationSubtitle(@NonNull JSONObject tags, @NonNull NearbyServiceItem.Type type) {
        if (type == NearbyServiceItem.Type.FUEL) {
            String brand = tags.optString("brand", "");
            if (!brand.isEmpty()) {
                return brand;
            }
            return tags.optString("operator", "OpenStreetMap");
        }
        String operator = tags.optString("operator", "");
        if (!operator.isEmpty()) {
            return operator;
        }
        return tags.optString("brand", "OpenStreetMap");
    }

    private boolean isOpenFromTags(@NonNull JSONObject tags) {
        String hours = tags.optString("opening_hours", "");
        if (hours.isEmpty()) {
            return true;
        }
        String lower = hours.toLowerCase(Locale.ROOT);
        return !lower.contains("off") && !lower.equals("closed");
    }

    private float measureDistanceMeters(double userLat, double userLon,
                                        double stationLat, double stationLon) {
        float[] results = new float[1];
        Location.distanceBetween(userLat, userLon, stationLat, stationLon, results);
        return results[0];
    }

    @Nullable
    private String firstNonEmpty(@NonNull String... values) {
        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
        }
        return null;
    }

    private void onStationsLoaded(@NonNull List<NearbyServiceItem> stations,
                                  double latitude,
                                  double longitude) {
        allStations.clear();
        allStations.addAll(stations);
        lastFetchedLat = latitude;
        lastFetchedLon = longitude;
        markerById.clear();
        recalculateDistances();
        applyFilters();
    }

    private void onStationsLoadFailed() {
        allStations.clear();
        markerById.clear();
        lastFetchedLat = Double.NaN;
        lastFetchedLon = Double.NaN;
        if (adapter != null) {
            adapter.submitList(Collections.emptyList());
        }
        if (binding != null) {
            binding.textEmptyServices.setText(R.string.near_services_fetch_error);
            binding.textEmptyServices.setVisibility(View.VISIBLE);
            binding.recyclerServices.setVisibility(View.GONE);
            binding.mapView.getOverlays().clear();
            if (myLocationMarker != null) {
                binding.mapView.getOverlays().add(myLocationMarker);
            }
            binding.mapView.invalidate();
        }
    }

    private void recalculateDistances() {
        if (userLocation == null || allStations.isEmpty()) {
            return;
        }
        float[] results = new float[1];
        for (int i = 0; i < allStations.size(); i++) {
            NearbyServiceItem station = allStations.get(i);
            Location.distanceBetween(
                    userLocation.getLatitude(),
                    userLocation.getLongitude(),
                    station.getLatitude(),
                    station.getLongitude(),
                    results);
            int meters = Math.round(results[0]);
            allStations.set(i, station.withDistance(meters, formatDistance(meters)));
        }
    }

    @NonNull
    private String formatDistance(int meters) {
        if (meters < 1000) {
            return meters + " m";
        }
        return String.format(Locale.getDefault(), "%.1f km", meters / 1000f);
    }

    private void showWaitingForLocation() {
        if (binding == null || adapter == null) {
            return;
        }
        adapter.submitList(Collections.emptyList());
        binding.textEmptyServices.setText(R.string.near_services_loading_location);
        binding.textEmptyServices.setVisibility(View.VISIBLE);
        binding.recyclerServices.setVisibility(View.GONE);
    }

    private void showLoadingStations() {
        if (binding == null || adapter == null) {
            return;
        }
        adapter.submitList(Collections.emptyList());
        binding.textEmptyServices.setText(R.string.near_services_loading_stations);
        binding.textEmptyServices.setVisibility(View.VISIBLE);
        binding.recyclerServices.setVisibility(View.GONE);
    }

    private void updateMyLocationMarker() {
        if (binding == null || userLocation == null) {
            return;
        }
        MapView mapView = binding.mapView;
        if (myLocationMarker == null) {
            myLocationMarker = new Marker(mapView);
            myLocationMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER);
            myLocationMarker.setIcon(createMyLocationDrawable());
            myLocationMarker.setTitle(getString(R.string.near_services_current_location));
        }
        myLocationMarker.setPosition(userLocation);
        if (!binding.mapView.getOverlays().contains(myLocationMarker)) {
            binding.mapView.getOverlays().add(myLocationMarker);
            binding.mapView.invalidate();
        }
    }

    @NonNull
    private Drawable createMyLocationDrawable() {
        GradientDrawable outer = new GradientDrawable();
        outer.setShape(GradientDrawable.OVAL);
        outer.setColor(Color.argb(60, 33, 150, 243));
        outer.setSize(36, 36);

        GradientDrawable inner = new GradientDrawable();
        inner.setShape(GradientDrawable.OVAL);
        inner.setColor(color(R.color.near_services_ev_blue));
        inner.setStroke(3, Color.WHITE);
        inner.setSize(18, 18);

        int size = 36;
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        outer.setBounds(0, 0, size, size);
        outer.draw(canvas);
        int inset = 9;
        inner.setBounds(inset, inset, size - inset, size - inset);
        inner.draw(canvas);
        return new BitmapDrawable(requireContext().getResources(), bitmap);
    }

    private void setupMap() {
        if (binding == null) {
            return;
        }
        MapView mapView = binding.mapView;
        mapView.setTileSource(TileSourceFactory.MAPNIK);
        mapView.setMultiTouchControls(true);
        mapView.setTilesScaledToDpi(true);
        mapView.setBuiltInZoomControls(true);
        mapView.getZoomController().setVisibility(
                CustomZoomButtonsController.Visibility.SHOW_AND_FADEOUT);
        mapView.getController().setZoom(DEFAULT_ZOOM);
    }

    @NonNull
    private Marker createMarker(@NonNull MapView mapView, @NonNull NearbyServiceItem station) {
        Marker marker = new Marker(mapView);
        marker.setPosition(new GeoPoint(station.getLatitude(), station.getLongitude()));
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        marker.setTitle(station.getName());
        marker.setSnippet(station.getDistanceText());
        marker.setIcon(createMarkerDrawable(station));
        marker.setRelatedObject(station.getId());
        marker.setOnMarkerClickListener((m, map) -> {
            NearbyServiceItem item = findStationById(String.valueOf(m.getRelatedObject()));
            if (item != null) {
                focusStationOnMap(item, false);
            }
            return true;
        });
        return marker;
    }

    @NonNull
    private Drawable createMarkerDrawable(@NonNull NearbyServiceItem station) {
        View markerView = LayoutInflater.from(requireContext())
                .inflate(R.layout.map_marker_bubble, null, false);
        TextView distanceView = markerView.findViewById(R.id.textMarkerDistance);
        ImageView pointerView = markerView.findViewById(R.id.imageMarkerPointer);

        distanceView.setText(station.getDistanceText());
        if (station.getType() == NearbyServiceItem.Type.FUEL) {
            distanceView.setBackgroundResource(R.drawable.bg_map_marker_fuel);
            pointerView.setColorFilter(color(R.color.setup_primary));
        } else {
            distanceView.setBackgroundResource(R.drawable.bg_map_marker_ev);
            pointerView.setColorFilter(color(R.color.near_services_ev_blue));
        }

        markerView.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        markerView.layout(0, 0, markerView.getMeasuredWidth(), markerView.getMeasuredHeight());

        Bitmap bitmap = Bitmap.createBitmap(
                markerView.getMeasuredWidth(),
                markerView.getMeasuredHeight(),
                Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        markerView.draw(canvas);
        return new BitmapDrawable(requireContext().getResources(), bitmap);
    }

    private void setupTabs() {
        if (binding == null) {
            return;
        }
        binding.tabServiceType.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                if (position == 1) {
                    activeTypeTab = TypeTab.FUEL;
                } else if (position == 2) {
                    activeTypeTab = TypeTab.EV;
                } else {
                    activeTypeTab = TypeTab.ALL;
                }
                applyFilters();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }

    private void applyFilters() {
        if (userLocation == null) {
            showWaitingForLocation();
            return;
        }
        if (allStations.isEmpty()) {
            if (stationsLoading) {
                showLoadingStations();
            } else {
                if (adapter != null) {
                    adapter.submitList(Collections.emptyList());
                }
                updateMapMarkers(Collections.emptyList());
                updateEmptyState(true);
            }
            return;
        }

        List<NearbyServiceItem> filtered = new ArrayList<>();
        for (NearbyServiceItem station : allStations) {
            if (matchesTypeTab(station)) {
                filtered.add(station);
            }
        }
        Collections.sort(filtered, Comparator.comparingInt(NearbyServiceItem::getDistanceMeters));

        if (adapter != null) {
            adapter.submitList(new ArrayList<>(filtered));
        }
        updateMapMarkers(filtered);
        updateEmptyState(filtered.isEmpty());
    }

    private boolean matchesTypeTab(@NonNull NearbyServiceItem station) {
        if (activeTypeTab == TypeTab.FUEL) {
            return station.getType() == NearbyServiceItem.Type.FUEL;
        }
        if (activeTypeTab == TypeTab.EV) {
            return station.getType() == NearbyServiceItem.Type.EV;
        }
        return true;
    }

    private void updateMapMarkers(@NonNull List<NearbyServiceItem> visibleStations) {
        if (binding == null) {
            return;
        }
        MapView mapView = binding.mapView;
        mapView.getOverlays().clear();
        if (myLocationMarker != null) {
            mapView.getOverlays().add(myLocationMarker);
        }
        for (NearbyServiceItem station : visibleStations) {
            Marker marker = markerById.get(station.getId());
            if (marker == null) {
                marker = createMarker(mapView, station);
                markerById.put(station.getId(), marker);
            } else {
                marker.setSnippet(station.getDistanceText());
                marker.setIcon(createMarkerDrawable(station));
            }
            mapView.getOverlays().add(marker);
        }
        mapView.invalidate();
    }

    private void updateEmptyState(boolean empty) {
        if (binding == null) {
            return;
        }
        binding.textEmptyServices.setText(R.string.near_services_empty);
        binding.textEmptyServices.setVisibility(empty ? View.VISIBLE : View.GONE);
        binding.recyclerServices.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private void focusStationOnMap(@NonNull NearbyServiceItem item, boolean fromList) {
        if (binding == null) {
            return;
        }
        Marker marker = markerById.get(item.getId());
        if (marker == null) {
            return;
        }

        suppressUserMapCenterUntilMs = System.currentTimeMillis() + 8_000L;

        if (highlightedMarker != null) {
            highlightedMarker.setAlpha(1.0f);
        }
        highlightedMarker = marker;
        highlightedMarker.setAlpha(0.85f);

        MapView mapView = binding.mapView;
        GeoPoint target = marker.getPosition();
        double zoom = fromList ? 17.5 : Math.max(mapView.getZoomLevelDouble(), 16.5);

        mapView.post(() -> {
            if (binding == null) {
                return;
            }
            binding.mapView.getController().animateTo(target, zoom, 900L);
            marker.showInfoWindow();
            binding.mapView.invalidate();
        });
    }

    @Nullable
    private NearbyServiceItem findStationById(@NonNull String id) {
        for (NearbyServiceItem station : allStations) {
            if (station.getId().equals(id)) {
                return station;
            }
        }
        return null;
    }

    private void closeScreen() {
        if (getActivity() instanceof NearServicesHost) {
            ((NearServicesHost) getActivity()).onCloseNearServices();
        } else {
            requireActivity().getOnBackPressedDispatcher().onBackPressed();
        }
    }

    private int color(@ColorRes int colorRes) {
        return ContextCompat.getColor(requireContext(), colorRes);
    }
}
