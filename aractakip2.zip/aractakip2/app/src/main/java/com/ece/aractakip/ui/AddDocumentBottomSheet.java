package com.ece.aractakip.ui;

import android.net.Uri;
import android.os.Bundle;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.ece.aractakip.R;
import com.ece.aractakip.databinding.DialogAddDocumentBinding;
import com.ece.aractakip.model.DocumentEntry;
import com.ece.aractakip.util.DateInputUtils;
import com.ece.aractakip.util.DocumentFileHelper;
import com.ece.aractakip.util.MaterialDatePickerHelper;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.io.File;

public class AddDocumentBottomSheet extends BottomSheetDialogFragment {

    private static final int SPINNER_HINT_INDEX = 0;

    public interface DocumentFormListener {
        void onDocumentSaved(@NonNull DocumentEntry entry);
    }

    @Nullable
    private DialogAddDocumentBinding binding;
    @Nullable
    private DocumentFormListener formListener;
    @Nullable
    private DocumentEntry.Type selectedType;
    @Nullable
    private Uri selectedFileUri;
    private long selectedExpiryMs;
    private boolean expiryDateOptional;
    @Nullable
    private Uri cameraOutputUri;

    private final ActivityResultLauncher<String> pickImageLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), this::onFilePicked);

    private final ActivityResultLauncher<String> pickDocumentLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), this::onFilePicked);

    private final ActivityResultLauncher<Uri> takePictureLauncher =
            registerForActivityResult(new ActivityResultContracts.TakePicture(), success -> {
                if (success && cameraOutputUri != null) {
                    onFilePicked(cameraOutputUri);
                }
            });

    public static AddDocumentBottomSheet newInstance() {
        return new AddDocumentBottomSheet();
    }

    public void setDocumentFormListener(@Nullable DocumentFormListener listener) {
        this.formListener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DialogAddDocumentBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }

        setupDocumentTypeSpinner();
        binding.buttonDocumentExpiry.setOnClickListener(v -> showDatePicker());
        binding.buttonSaveDocument.setOnClickListener(v -> saveDocument());
        binding.frameDocumentUpload.setOnClickListener(v -> pickImageLauncher.launch("image/*"));
        binding.buttonPickGallery.setOnClickListener(v -> pickImageLauncher.launch("image/*"));
        binding.buttonPickCamera.setOnClickListener(v -> launchCamera());
        binding.buttonPickFile.setOnClickListener(v -> pickDocumentLauncher.launch("*/*"));
        showFormForUnselectedType();
    }

    private void setupDocumentTypeSpinner() {
        if (binding == null) {
            return;
        }

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                requireContext(),
                R.array.document_types,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerDocumentType.setAdapter(adapter);
        binding.spinnerDocumentType.setSelection(SPINNER_HINT_INDEX, false);

        binding.spinnerDocumentType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(@Nullable AdapterView<?> parent,
                                       @Nullable View itemView,
                                       int position,
                                       long id) {
                if (position == SPINNER_HINT_INDEX) {
                    selectedType = null;
                    showFormForUnselectedType();
                    return;
                }
                selectedType = resolveType(position);
                applyTypeUi(selectedType);
            }

            @Override
            public void onNothingSelected(@Nullable AdapterView<?> parent) {
                selectedType = null;
                showFormForUnselectedType();
            }
        });
    }

    @Nullable
    private DocumentEntry.Type resolveType(int position) {
        switch (position) {
            case 1:
                return DocumentEntry.Type.VEHICLE_REGISTRATION;
            case 2:
                return DocumentEntry.Type.TRAFFIC_INSURANCE;
            case 3:
                return DocumentEntry.Type.CASCO;
            case 4:
                return DocumentEntry.Type.DRIVER_LICENSE;
            case 5:
                return DocumentEntry.Type.INSPECTION_EXHAUST;
            case 6:
                return DocumentEntry.Type.CUSTOM;
            default:
                return null;
        }
    }

    private void showFormForUnselectedType() {
        if (binding == null) {
            return;
        }
        TransitionManager.beginDelayedTransition((ViewGroup) binding.getRoot(), new AutoTransition());
        binding.tilCustomDocumentName.setVisibility(View.GONE);
        binding.tilDocumentNumber.setVisibility(View.GONE);
        binding.layoutExpirySection.setVisibility(View.GONE);
        binding.layoutAttachmentSection.setVisibility(View.GONE);
        binding.editDocumentNumber.setEnabled(false);
        binding.buttonDocumentExpiry.setEnabled(false);
        binding.buttonSaveDocument.setEnabled(false);
        expiryDateOptional = false;
        resetExpiryField();
        clearAttachmentPreview();
    }

    private void applyTypeUi(@Nullable DocumentEntry.Type type) {
        if (binding == null || type == null) {
            showFormForUnselectedType();
            return;
        }

        TransitionManager.beginDelayedTransition((ViewGroup) binding.getRoot(), new AutoTransition());
        binding.tilDocumentNumber.setVisibility(View.VISIBLE);
        binding.editDocumentNumber.setEnabled(true);
        binding.buttonSaveDocument.setEnabled(true);
        binding.layoutAttachmentSection.setVisibility(View.VISIBLE);
        binding.tilCustomDocumentName.setVisibility(View.GONE);
        binding.editCustomDocumentName.setText("");
        resetExpiryField();

        if (type == DocumentEntry.Type.VEHICLE_REGISTRATION) {
            binding.tilDocumentNumber.setHint(getString(R.string.document_hint_registration));
            binding.layoutExpirySection.setVisibility(View.GONE);
            binding.buttonDocumentExpiry.setEnabled(false);
            expiryDateOptional = false;
            return;
        }

        binding.layoutExpirySection.setVisibility(View.VISIBLE);
        binding.buttonDocumentExpiry.setEnabled(true);

        if (type == DocumentEntry.Type.TRAFFIC_INSURANCE || type == DocumentEntry.Type.CASCO) {
            binding.tilDocumentNumber.setHint(getString(R.string.document_hint_policy));
            binding.textDocumentExpiryLabel.setText(R.string.document_expiry_policy);
            expiryDateOptional = false;
        } else if (type == DocumentEntry.Type.DRIVER_LICENSE) {
            binding.tilDocumentNumber.setHint(getString(R.string.document_hint_license));
            binding.textDocumentExpiryLabel.setText(R.string.document_expiry_license);
            expiryDateOptional = false;
        } else if (type == DocumentEntry.Type.INSPECTION_EXHAUST) {
            binding.tilDocumentNumber.setHint(getString(R.string.document_hint_inspection));
            binding.textDocumentExpiryLabel.setText(R.string.document_expiry_inspection);
            expiryDateOptional = false;
        } else if (type == DocumentEntry.Type.CUSTOM) {
            binding.tilDocumentNumber.setHint(getString(R.string.document_hint_custom_number));
            binding.textDocumentExpiryLabel.setText(R.string.document_expiry_custom_optional);
            expiryDateOptional = true;
        }
    }

    private void launchCamera() {
        try {
            File output = DocumentFileHelper.createCameraOutputFile(requireContext(), System.currentTimeMillis());
            cameraOutputUri = FileProvider.getUriForFile(
                    requireContext(),
                    requireContext().getPackageName() + ".fileprovider",
                    output
            );
            takePictureLauncher.launch(cameraOutputUri);
        } catch (Exception e) {
            Toast.makeText(requireContext(), R.string.document_error_file_save, Toast.LENGTH_SHORT).show();
        }
    }

    private void onFilePicked(@Nullable Uri uri) {
        if (binding == null || uri == null) {
            return;
        }
        selectedFileUri = uri;
        updateAttachmentPreview(uri);
    }

    private void updateAttachmentPreview(@NonNull Uri uri) {
        if (binding == null) {
            return;
        }
        String path = uri.toString();
        boolean isPdf = DocumentFileHelper.isPdf(path)
                || "application/pdf".equals(requireContext().getContentResolver().getType(uri));

        binding.layoutDocumentUploadPlaceholder.setVisibility(View.GONE);
        if (isPdf) {
            binding.imageDocumentPreview.setVisibility(View.GONE);
            binding.layoutDocumentFileBadge.setVisibility(View.VISIBLE);
            String name = DocumentFileHelper.displayName(requireContext(), path);
            binding.textDocumentFileName.setText(
                    name != null ? name : getString(R.string.document_attachment_added));
            return;
        }

        binding.layoutDocumentFileBadge.setVisibility(View.GONE);
        binding.imageDocumentPreview.setVisibility(View.VISIBLE);
        Glide.with(this)
                .load(uri)
                .centerCrop()
                .into(binding.imageDocumentPreview);
    }

    private void clearAttachmentPreview() {
        if (binding == null) {
            return;
        }
        selectedFileUri = null;
        binding.imageDocumentPreview.setVisibility(View.GONE);
        binding.layoutDocumentFileBadge.setVisibility(View.GONE);
        binding.layoutDocumentUploadPlaceholder.setVisibility(View.VISIBLE);
        binding.imageDocumentPreview.setImageDrawable(null);
        binding.textDocumentFileName.setText("");
    }

    private void showDatePicker() {
        Long initial = selectedExpiryMs > 0 && selectedExpiryMs != DocumentEntry.UNLIMITED_EXPIRY_MS
                ? selectedExpiryMs
                : null;
        MaterialDatePickerHelper.show(this, initial, selectedMs -> {
            selectedExpiryMs = selectedMs;
            if (binding != null) {
                binding.buttonDocumentExpiry.setText(
                        DateInputUtils.formatTurkishDate(selectedExpiryMs));
                binding.buttonDocumentExpiry.setTextColor(
                        ContextCompat.getColor(requireContext(), R.color.black));
            }
        });
    }

    private void resetExpiryField() {
        if (binding == null) {
            return;
        }
        selectedExpiryMs = 0;
        binding.buttonDocumentExpiry.setText(R.string.document_expiry_select);
        binding.buttonDocumentExpiry.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.setup_text_secondary));
    }

    private void saveDocument() {
        if (binding == null || formListener == null) {
            dismiss();
            return;
        }

        if (selectedType == null) {
            Toast.makeText(requireContext(), R.string.document_error_type_required, Toast.LENGTH_SHORT).show();
            return;
        }

        String title = binding.spinnerDocumentType.getSelectedItem().toString();

        String number = binding.editDocumentNumber.getText() == null
                ? "" : binding.editDocumentNumber.getText().toString().trim();
        if (number.isEmpty()) {
            binding.tilDocumentNumber.setError(getString(R.string.document_error_number_required));
            return;
        }
        binding.tilDocumentNumber.setError(null);

        long expiryMs;
        if (selectedType == DocumentEntry.Type.VEHICLE_REGISTRATION) {
            expiryMs = DocumentEntry.UNLIMITED_EXPIRY_MS;
        } else if (binding.layoutExpirySection.getVisibility() == View.VISIBLE) {
            if (selectedExpiryMs <= 0) {
                if (expiryDateOptional) {
                    expiryMs = DocumentEntry.UNLIMITED_EXPIRY_MS;
                } else {
                    Toast.makeText(
                            requireContext(),
                            R.string.document_error_expiry_required_visible,
                            Toast.LENGTH_SHORT
                    ).show();
                    return;
                }
            } else {
                expiryMs = selectedExpiryMs;
            }
        } else {
            expiryMs = DocumentEntry.UNLIMITED_EXPIRY_MS;
        }

        long id = System.currentTimeMillis();
        String savedPath = null;
        if (selectedFileUri != null) {
            savedPath = DocumentFileHelper.persistDocumentFile(requireContext(), selectedFileUri, id);
            if (savedPath == null) {
                Toast.makeText(requireContext(), R.string.document_error_file_save, Toast.LENGTH_SHORT).show();
                return;
            }
        }

        DocumentEntry entry = new DocumentEntry(
                id,
                selectedType,
                title,
                number,
                expiryMs,
                savedPath
        );
        formListener.onDocumentSaved(entry);
        dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
