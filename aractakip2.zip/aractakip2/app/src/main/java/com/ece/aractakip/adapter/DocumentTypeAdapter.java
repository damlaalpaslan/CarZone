package com.ece.aractakip.adapter;

import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.ece.aractakip.databinding.ItemDocumentTypeOptionBinding;
import com.ece.aractakip.model.DocumentTypeOption;

import java.util.ArrayList;
import java.util.List;

public class DocumentTypeAdapter extends RecyclerView.Adapter<DocumentTypeAdapter.TypeViewHolder> {

    public interface TypeClickListener {
        void onTypeSelected(@NonNull DocumentTypeOption option);
    }

    private final LayoutInflater inflater;
    private final TypeClickListener listener;
    private final List<DocumentTypeOption> options = new ArrayList<>();

    public DocumentTypeAdapter(@NonNull LayoutInflater inflater, @NonNull TypeClickListener listener) {
        this.inflater = inflater;
        this.listener = listener;
    }

    public void submitOptions(@NonNull List<DocumentTypeOption> items) {
        options.clear();
        options.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TypeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new TypeViewHolder(ItemDocumentTypeOptionBinding.inflate(inflater, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull TypeViewHolder holder, int position) {
        DocumentTypeOption option = options.get(position);
        holder.binding.textOptionLabel.setText(option.getLabelRes());
        holder.binding.imageOptionIcon.setImageResource(option.getIconRes());
        holder.binding.imageOptionIcon.setColorFilter(
                ContextCompat.getColor(holder.itemView.getContext(), option.getIconTintRes()));

        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(ContextCompat.getColor(holder.itemView.getContext(), option.getIconBackgroundRes()));
        holder.binding.frameOptionIcon.setBackground(circle);

        holder.itemView.setOnClickListener(v -> listener.onTypeSelected(option));
    }

    @Override
    public int getItemCount() {
        return options.size();
    }

    static class TypeViewHolder extends RecyclerView.ViewHolder {
        private final ItemDocumentTypeOptionBinding binding;

        TypeViewHolder(@NonNull ItemDocumentTypeOptionBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
