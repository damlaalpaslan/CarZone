package com.ece.aractakip.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.ece.aractakip.R;
import com.ece.aractakip.databinding.ItemServiceHistoryCardBinding;
import com.ece.aractakip.model.ServiceHistoryEntry;
import com.ece.aractakip.util.MileageFormatUtil;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class ServiceHistoryAdapter extends RecyclerView.Adapter<ServiceHistoryAdapter.ServiceViewHolder> {

    public enum FilterType {
        ALL,
        PERIODIC,
        REPAIR
    }

    public interface ServiceHistoryClickListener {
        void onServiceEntryClick(@NonNull ServiceHistoryEntry entry);
    }

    private final LayoutInflater inflater;
    private final ServiceHistoryClickListener clickListener;
    private final List<ServiceHistoryEntry> allEntries = new ArrayList<>();
    private final List<ServiceHistoryEntry> visibleEntries = new ArrayList<>();
    private FilterType activeFilter = FilterType.ALL;

    public ServiceHistoryAdapter(@NonNull Context context,
                                 @NonNull ServiceHistoryClickListener clickListener) {
        this.inflater = LayoutInflater.from(context);
        this.clickListener = clickListener;
    }

    public void submitList(@NonNull List<ServiceHistoryEntry> items) {
        allEntries.clear();
        allEntries.addAll(items);
        applyFilter(activeFilter);
    }

    public void setFilter(@NonNull FilterType filterType) {
        activeFilter = filterType;
        applyFilter(filterType);
    }

    private void applyFilter(@NonNull FilterType filterType) {
        visibleEntries.clear();
        for (ServiceHistoryEntry entry : allEntries) {
            if (matchesFilter(entry, filterType)) {
                visibleEntries.add(entry);
            }
        }
        notifyDataSetChanged();
    }

    private static boolean matchesFilter(@NonNull ServiceHistoryEntry entry,
                                         @NonNull FilterType filterType) {
        if (filterType == FilterType.ALL) {
            return true;
        }
        if (filterType == FilterType.PERIODIC) {
            return entry.getType() == ServiceHistoryEntry.Type.PERIODIC_MAINTENANCE
                    || entry.getType() == ServiceHistoryEntry.Type.HEAVY_MAINTENANCE;
        }
        return entry.getType() == ServiceHistoryEntry.Type.REPAIR;
    }

    @NonNull
    @Override
    public ServiceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemServiceHistoryCardBinding binding = ItemServiceHistoryCardBinding.inflate(inflater, parent, false);
        return new ServiceViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ServiceViewHolder holder, int position) {
        ServiceHistoryEntry entry = visibleEntries.get(position);
        Context context = holder.binding.getRoot().getContext();

        holder.binding.textServiceTitle.setText(entry.getTitle());
        holder.binding.textServiceCost.setText(formatCost(entry.getCost()));
        holder.binding.textServiceDate.setText(entry.getDateText());
        holder.binding.textServiceMileage.setText(MileageFormatUtil.formatKm(entry.getMileage()));

        holder.binding.textServiceTypeBadge.setText(resolveTypeChipLabel(context, entry.getType()));
        holder.binding.textServiceTypeBadge.setTextColor(
                ContextCompat.getColor(context, resolveTypeAccentColor(entry.getType())));
        holder.binding.textServiceTypeBadge.setBackgroundResource(resolveTypeBadgeBackground(entry.getType()));

        holder.binding.frameServiceIcon.setBackgroundResource(resolveIconBackground(entry.getType()));
        holder.binding.imageServiceIcon.setImageResource(resolveIcon(entry.getType()));
        if (entry.getType() == ServiceHistoryEntry.Type.HEAVY_MAINTENANCE) {
            holder.binding.imageServiceIcon.setColorFilter(
                    ContextCompat.getColor(context, R.color.service_accent_orange));
        } else {
            holder.binding.imageServiceIcon.clearColorFilter();
        }

        holder.binding.cardServiceHistory.setOnClickListener(
                v -> clickListener.onServiceEntryClick(entry));
    }

    @Override
    public int getItemCount() {
        return visibleEntries.size();
    }

    @NonNull
    public static String formatCost(double cost) {
        NumberFormat currency = NumberFormat.getCurrencyInstance(new Locale("tr", "TR"));
        currency.setMaximumFractionDigits(0);
        return currency.format(cost);
    }

    @NonNull
    public static String formatTotalCost(double totalCost) {
        return formatCost(totalCost);
    }

    @NonNull
    public static String formatPredictiveMaintenanceAlert(@NonNull Context context,
                                                          int currentOdometer,
                                                          int lastServiceMileage,
                                                          long lastServiceDateMs,
                                                          int maintenanceIntervalKm,
                                                          int maintenanceIntervalDays) {
        int remainingKm = Math.max(0, (lastServiceMileage + maintenanceIntervalKm) - currentOdometer);

        long now = System.currentTimeMillis();
        long elapsedDays = TimeUnit.MILLISECONDS.toDays(now - lastServiceDateMs);
        int remainingDays = Math.max(0, maintenanceIntervalDays - (int) elapsedDays);

        NumberFormat nf = NumberFormat.getNumberInstance(new Locale("tr", "TR"));
        return context.getString(
                R.string.service_history_predictive_alert,
                nf.format(remainingKm),
                nf.format(remainingDays));
    }

    @NonNull
    private static String resolveTypeChipLabel(@NonNull Context context,
                                               @NonNull ServiceHistoryEntry.Type type) {
        if (type == ServiceHistoryEntry.Type.REPAIR) {
            return context.getString(R.string.service_type_repair);
        }
        if (type == ServiceHistoryEntry.Type.HEAVY_MAINTENANCE) {
            return context.getString(R.string.service_type_heavy_maintenance);
        }
        return context.getString(R.string.service_type_periodic);
    }

    @DrawableRes
    private static int resolveIcon(@NonNull ServiceHistoryEntry.Type type) {
        if (type == ServiceHistoryEntry.Type.REPAIR) {
            return R.drawable.ic_service_brake;
        }
        if (type == ServiceHistoryEntry.Type.HEAVY_MAINTENANCE) {
            return R.drawable.ic_quick_wrench;
        }
        return R.drawable.ic_service_oil;
    }

    @DrawableRes
    private static int resolveIconBackground(@NonNull ServiceHistoryEntry.Type type) {
        if (type == ServiceHistoryEntry.Type.REPAIR) {
            return R.drawable.bg_service_icon_red;
        }
        if (type == ServiceHistoryEntry.Type.HEAVY_MAINTENANCE) {
            return R.drawable.bg_service_icon_orange;
        }
        return R.drawable.bg_service_icon_blue;
    }

    @ColorRes
    private static int resolveTypeAccentColor(@NonNull ServiceHistoryEntry.Type type) {
        if (type == ServiceHistoryEntry.Type.REPAIR) {
            return R.color.service_accent_red;
        }
        if (type == ServiceHistoryEntry.Type.HEAVY_MAINTENANCE) {
            return R.color.service_accent_orange;
        }
        return R.color.service_accent_green;
    }

    @DrawableRes
    private static int resolveTypeBadgeBackground(@NonNull ServiceHistoryEntry.Type type) {
        if (type == ServiceHistoryEntry.Type.REPAIR) {
            return R.drawable.bg_service_badge_red;
        }
        if (type == ServiceHistoryEntry.Type.HEAVY_MAINTENANCE) {
            return R.drawable.bg_service_badge_orange;
        }
        return R.drawable.bg_service_badge_green;
    }

    static class ServiceViewHolder extends RecyclerView.ViewHolder {
        private final ItemServiceHistoryCardBinding binding;

        ServiceViewHolder(@NonNull ItemServiceHistoryCardBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
