package com.ece.aractakip.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ece.aractakip.R;
import com.ece.aractakip.data.AppPreferences;
import com.ece.aractakip.data.DatabaseHelper;
import com.ece.aractakip.databinding.FragmentStatisticsBinding;
import com.ece.aractakip.util.ExpenseChartHelper;

import java.util.LinkedHashMap;

public class StatisticsFragment extends Fragment {

    @Nullable
    private FragmentStatisticsBinding binding;
    private DatabaseHelper databaseHelper;

    public static StatisticsFragment newInstance() {
        return new StatisticsFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentStatisticsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }
        databaseHelper = DatabaseHelper.getInstance(requireContext());
        renderAll();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (binding != null) {
            renderAll();
        }
    }

    private void renderAll() {
        renderExpensePie();
        renderMonthlyBarAndComparison();
    }

    private void renderExpensePie() {
        if (binding == null || databaseHelper == null) {
            return;
        }
        ExpenseChartHelper.Totals totals = ExpenseChartHelper.loadTotals(requireContext(), databaseHelper);
        ExpenseChartHelper.renderPieChart(
                requireContext(),
                binding.chartExpenses,
                binding.textExpenseEmpty,
                totals);
    }

    private void renderMonthlyBarAndComparison() {
        if (binding == null) {
            return;
        }
        LinkedHashMap<String, Integer> map = AppPreferences.getMonthlyOdometers(requireContext());
        ExpenseChartHelper.MonthlyDistanceData data =
                ExpenseChartHelper.buildMonthlyDistanceData(requireContext(), map);

        ExpenseChartHelper.renderMonthlyBarChart(
                requireContext(),
                binding.chartMonthlyDistance,
                binding.textDistanceEmpty,
                data);

        if (data.showFirstEntryPrompt) {
            binding.textComparisonValue.setVisibility(View.VISIBLE);
            binding.textComparisonValue.setText(R.string.stats_first_data_entry);
        } else if (data.comparisonText != null) {
            binding.textComparisonValue.setVisibility(View.VISIBLE);
            binding.textComparisonValue.setText(data.comparisonText);
        } else {
            binding.textComparisonValue.setVisibility(View.GONE);
        }

        if (data.maintenanceSuggestionText != null) {
            binding.cardMaintenanceSuggestion.setVisibility(View.VISIBLE);
            binding.textMaintenanceSuggestionBody.setText(data.maintenanceSuggestionText);
        } else {
            binding.cardMaintenanceSuggestion.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
