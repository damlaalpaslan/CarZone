package com.ece.aractakip.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ece.aractakip.R;
import com.ece.aractakip.databinding.BottomSheetAddEditReminderBinding;
import com.ece.aractakip.model.Reminder;
import com.ece.aractakip.util.DateInputUtils;
import com.ece.aractakip.util.MaterialDatePickerHelper;
import com.ece.aractakip.util.NumberInputFormatUtil;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class AddEditReminderBottomSheet extends BottomSheetDialogFragment {

    public interface ReminderFormListener {
        void onReminderSaved(@NonNull String reminderId,
                             @NonNull String name,
                             @NonNull Reminder.Category category,
                             @Nullable Long dueDateMs,
                             @Nullable Integer dueMileageKm,
                             boolean isEditMode);
    }

    private static final String ARG_ID = "arg_id";
    private static final String ARG_NAME = "arg_name";
    private static final String ARG_CATEGORY = "arg_category";
    private static final String ARG_DUE_DATE = "arg_due_date";
    private static final String ARG_DUE_KM = "arg_due_km";

    @Nullable
    private BottomSheetAddEditReminderBinding binding;
    @Nullable
    private ReminderFormListener listener;

    public static AddEditReminderBottomSheet newAdd() {
        return new AddEditReminderBottomSheet();
    }

    public static AddEditReminderBottomSheet newEdit(@NonNull Reminder reminder) {
        Bundle args = new Bundle();
        args.putString(ARG_ID, reminder.getId());
        args.putString(ARG_NAME, reminder.getName());
        args.putString(ARG_CATEGORY, reminder.getCategory().name());
        if (reminder.getDueDateMs() != null) {
            args.putLong(ARG_DUE_DATE, reminder.getDueDateMs());
        }
        if (reminder.getDueMileageKm() != null) {
            args.putInt(ARG_DUE_KM, reminder.getDueMileageKm());
        }
        AddEditReminderBottomSheet sheet = new AddEditReminderBottomSheet();
        sheet.setArguments(args);
        return sheet;
    }

    public void setReminderFormListener(@Nullable ReminderFormListener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = BottomSheetAddEditReminderBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }

        String[] categoryNames = new String[]{
                getString(R.string.reminder_category_legal),
                getString(R.string.reminder_category_technical)
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_dropdown_item_1line,
                categoryNames
        );
        binding.autoCategory.setAdapter(adapter);

        Bundle args = getArguments();
        boolean editMode = args != null && args.containsKey(ARG_ID);
        if (editMode && args != null) {
            binding.textSheetTitle.setText(R.string.reminder_edit_title);
            binding.buttonSaveReminder.setText(R.string.reminder_update);

            binding.editReminderName.setText(args.getString(ARG_NAME, ""));
            String categoryArg = args.getString(ARG_CATEGORY, Reminder.Category.LEGAL.name());
            String categoryLabel = Reminder.Category.TECHNICAL.name().equals(categoryArg)
                    ? getString(R.string.reminder_category_technical)
                    : getString(R.string.reminder_category_legal);
            binding.autoCategory.setText(categoryLabel, false);

            if (args.containsKey(ARG_DUE_DATE)) {
                binding.editReminderDate.setText(
                        DateInputUtils.formatTurkishDate(args.getLong(ARG_DUE_DATE))
                );
            }
            if (args.containsKey(ARG_DUE_KM)) {
                binding.editReminderKm.setText(
                        NumberInputFormatUtil.formatGroupedInteger(args.getInt(ARG_DUE_KM)));
            }
        } else {
            binding.autoCategory.setText(getString(R.string.reminder_category_legal), false);
        }

        updateKmFieldVisibility();
        binding.autoCategory.setOnItemClickListener((parent, itemView, position, id) -> updateKmFieldVisibility());

        MaterialDatePickerHelper.attachToDateField(this, binding.editReminderDate);
        NumberInputFormatUtil.attachGroupedInteger(binding.editReminderKm);

        binding.buttonSaveReminder.setOnClickListener(v -> saveReminder(editMode));
    }

    private void updateKmFieldVisibility() {
        if (binding == null) {
            return;
        }
        String categoryRaw = binding.autoCategory.getText() == null
                ? getString(R.string.reminder_category_legal)
                : binding.autoCategory.getText().toString().trim();
        boolean isTechnical = getString(R.string.reminder_category_technical).equalsIgnoreCase(categoryRaw);
        binding.tilReminderKm.setVisibility(isTechnical ? View.VISIBLE : View.GONE);
        if (!isTechnical && binding.editReminderKm.getText() != null) {
            binding.editReminderKm.setText("");
            binding.tilReminderKm.setError(null);
        }
    }

    private void saveReminder(boolean isEditMode) {
        if (binding == null || listener == null) {
            dismiss();
            return;
        }

        String name = binding.editReminderName.getText() == null
                ? "" : binding.editReminderName.getText().toString().trim();
        if (name.isEmpty()) {
            binding.tilReminderName.setError(getString(R.string.reminder_error_name_required));
            return;
        }
        binding.tilReminderName.setError(null);

        String categoryRaw = binding.autoCategory.getText() == null
                ? getString(R.string.reminder_category_legal)
                : binding.autoCategory.getText().toString().trim();
        Reminder.Category category = getString(R.string.reminder_category_technical).equalsIgnoreCase(categoryRaw)
                ? Reminder.Category.TECHNICAL
                : Reminder.Category.LEGAL;

        String dateRaw = binding.editReminderDate.getText() == null
                ? "" : binding.editReminderDate.getText().toString().trim();
        Long dueDateMs = null;
        if (!TextUtils.isEmpty(dateRaw)) {
            long parsed = DateInputUtils.parseTurkishDateOrZero(dateRaw);
            if (parsed == -1L) {
                binding.tilReminderDate.setError(getString(R.string.setup_error_date));
                return;
            }
            binding.tilReminderDate.setError(null);
            dueDateMs = parsed;
        } else {
            binding.tilReminderDate.setError(null);
        }

        String kmRaw = binding.editReminderKm.getText() == null
                ? "" : binding.editReminderKm.getText().toString().trim();
        Integer dueKm = null;
        if (category == Reminder.Category.TECHNICAL && !TextUtils.isEmpty(kmRaw)) {
            try {
                dueKm = NumberInputFormatUtil.parseGroupedInteger(kmRaw);
                if (dueKm <= 0) {
                    throw new NumberFormatException("km");
                }
            } catch (NumberFormatException e) {
                binding.tilReminderKm.setError(getString(R.string.reminder_error_km_invalid));
                return;
            }
            binding.tilReminderKm.setError(null);
        } else {
            binding.tilReminderKm.setError(null);
        }

        if (dueDateMs == null && dueKm == null) {
            Toast.makeText(requireContext(), R.string.reminder_error_date_or_km, Toast.LENGTH_SHORT).show();
            return;
        }

        String reminderId = isEditMode && getArguments() != null
                ? getArguments().getString(ARG_ID, "")
                : "";
        listener.onReminderSaved(reminderId, name, category, dueDateMs, dueKm, isEditMode);
        dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
