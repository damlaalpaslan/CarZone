package com.ece.aractakip.util;

import android.content.Context;

import androidx.annotation.NonNull;

import com.ece.aractakip.R;

import java.text.NumberFormat;
import java.util.Locale;

public final class MileageFormatUtil {

    private MileageFormatUtil() {
    }

    @NonNull
    public static String formatKm(int mileage) {
        NumberFormat nf = NumberFormat.getNumberInstance(new Locale("tr", "TR"));
        return nf.format(mileage) + " KM";
    }

    @NonNull
    public static String formatKmLabel(@NonNull Context context, int mileage) {
        if (mileage <= 0) {
            return context.getString(R.string.settings_km_not_set);
        }
        return context.getString(R.string.settings_current_km_label, formatKm(mileage));
    }
}
