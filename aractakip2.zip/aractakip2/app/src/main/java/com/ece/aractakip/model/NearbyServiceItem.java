package com.ece.aractakip.model;

import androidx.annotation.NonNull;

public class NearbyServiceItem {

    public enum Type {
        FUEL,
        EV
    }

    @NonNull
    private final String id;
    @NonNull
    private final String name;
    @NonNull
    private final String subtitle;
    private final double latitude;
    private final double longitude;
    @NonNull
    private final String distanceText;
    private final int distanceMeters;
    private final float rating;
    private final boolean open;
    @NonNull
    private final Type type;

    public NearbyServiceItem(@NonNull String id,
                             @NonNull String name,
                             @NonNull String subtitle,
                             double latitude,
                             double longitude,
                             @NonNull String distanceText,
                             int distanceMeters,
                             float rating,
                             boolean open,
                             @NonNull Type type) {
        this.id = id;
        this.name = name;
        this.subtitle = subtitle;
        this.latitude = latitude;
        this.longitude = longitude;
        this.distanceText = distanceText;
        this.distanceMeters = distanceMeters;
        this.rating = rating;
        this.open = open;
        this.type = type;
    }

    @NonNull
    public String getId() {
        return id;
    }

    @NonNull
    public String getName() {
        return name;
    }

    @NonNull
    public String getSubtitle() {
        return subtitle;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    @NonNull
    public String getDistanceText() {
        return distanceText;
    }

    public int getDistanceMeters() {
        return distanceMeters;
    }

    public float getRating() {
        return rating;
    }

    public boolean isOpen() {
        return open;
    }

    @NonNull
    public Type getType() {
        return type;
    }

    @NonNull
    public NearbyServiceItem withDistance(int distanceMeters, @NonNull String distanceText) {
        return new NearbyServiceItem(
                id, name, subtitle, latitude, longitude,
                distanceText, distanceMeters, rating, open, type);
    }
}
