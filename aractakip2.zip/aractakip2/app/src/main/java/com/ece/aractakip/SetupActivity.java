package com.ece.aractakip;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.ece.aractakip.data.AppPreferences;
import com.ece.aractakip.databinding.ActivitySetupBinding;
import com.ece.aractakip.model.VehicleModel;
import com.ece.aractakip.util.NumberInputFormatUtil;
import com.google.android.material.textfield.TextInputEditText;

public class SetupActivity extends AppCompatActivity {

    private ActivitySetupBinding binding;
    @Nullable
    private String selectedPhotoUri;

    private final ActivityResultLauncher<String> pickImageLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri == null) {
                    return;
                }
                selectedPhotoUri = uri.toString();
                binding.imagePhotoPreview.setVisibility(View.VISIBLE);
                binding.layoutPhotoPlaceholder.setVisibility(View.GONE);
                Glide.with(this)
                        .load(uri)
                        .centerCrop()
                        .into(binding.imagePhotoPreview);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySetupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.framePhotoUpload.setOnClickListener(v -> pickImageLauncher.launch("image/*"));

        NumberInputFormatUtil.attachGroupedInteger(binding.editMileage);

        binding.buttonContinue.setOnClickListener(v -> goToStep2());

        binding.buttonBack.setOnClickListener(v -> goToStep1());

        binding.buttonStart.setOnClickListener(v -> submitAndFinish());
    }

    private void goToStep2() {
        binding.cardStep1.setVisibility(View.GONE);
        binding.cardStep2.setVisibility(View.VISIBLE);
        binding.layoutStep2.setVisibility(View.VISIBLE);

        binding.imageStep1Indicator.setImageResource(R.drawable.setup_step_1_completed);
        binding.textStep1Number.setVisibility(View.GONE);

        binding.imageStep2Indicator.setImageResource(R.drawable.setup_step_2_active);
        binding.textStep2Number.setTextColor(getColor(R.color.white));

        binding.scrollContent.post(() -> binding.scrollContent.smoothScrollTo(0, 0));
    }

    private void goToStep1() {
        binding.cardStep2.setVisibility(View.GONE);
        binding.layoutStep2.setVisibility(View.GONE);
        binding.cardStep1.setVisibility(View.VISIBLE);

        binding.imageStep1Indicator.setImageResource(R.drawable.setup_step_1_active);
        binding.textStep1Number.setVisibility(View.VISIBLE);

        binding.imageStep2Indicator.setImageResource(R.drawable.setup_step_2_inactive);
        binding.textStep2Number.setTextColor(getColor(R.color.setup_text_secondary));

        binding.scrollContent.post(() -> binding.scrollContent.smoothScrollTo(0, 0));
    }

    private void submitAndFinish() {
        String brand = textOrEmpty(binding.editBrand);
        String model = textOrEmpty(binding.editModel);
        String plate = textOrEmpty(binding.editPlate);

        if (TextUtils.isEmpty(brand) || TextUtils.isEmpty(model) || TextUtils.isEmpty(plate)) {
            Toast.makeText(this, R.string.setup_error_required, Toast.LENGTH_SHORT).show();
            return;
        }

        int year = 0;
        String yearStr = textOrEmpty(binding.editYear);
        if (!yearStr.isEmpty()) {
            try {
                year = Integer.parseInt(yearStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, R.string.setup_error_year, Toast.LENGTH_SHORT).show();
                return;
            }
            if (year < 1900 || year > 2100) {
                Toast.makeText(this, R.string.setup_error_year, Toast.LENGTH_SHORT).show();
                return;
            }
        }

        int mileage = parseMileageSafe(binding.editMileage);
        String color = textOrEmpty(binding.editColor);

        VehicleModel vehicle = new VehicleModel(
                selectedPhotoUri,
                brand,
                model,
                year,
                color,
                plate,
                mileage
        );

        AppPreferences.saveVehicleAndDates(this, vehicle, 0L, 0L);

        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @NonNull
    private static String textOrEmpty(@Nullable TextInputEditText editText) {
        if (editText == null || editText.getText() == null) {
            return "";
        }
        return editText.getText().toString().trim();
    }

    private static int parseMileageSafe(@Nullable TextInputEditText editText) {
        String s = textOrEmpty(editText);
        if (s.isEmpty()) {
            return 0;
        }
        try {
            return NumberInputFormatUtil.parseGroupedInteger(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
