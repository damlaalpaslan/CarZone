package com.ece.aractakip.util;

import android.content.Context;
import android.content.res.Configuration;

import androidx.annotation.NonNull;

import java.util.Locale;

public final class LocaleHelper {

    private static final Locale APP_LOCALE = Locale.forLanguageTag("tr-TR");

    private LocaleHelper() {
    }

    @NonNull
    public static Context wrap(@NonNull Context context) {
        Locale.setDefault(APP_LOCALE);
        Configuration configuration = new Configuration(context.getResources().getConfiguration());
        configuration.setLocale(APP_LOCALE);
        configuration.setLayoutDirection(APP_LOCALE);
        return context.createConfigurationContext(configuration);
    }
}
