package com.ece.aractakip.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;

import com.ece.aractakip.model.ServiceHistoryEntry;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "aractakip.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_SERVICE = "servis_kayitlari";

    public static final String COL_ID = "id";
    public static final String COL_BASLIK = "baslik";
    public static final String COL_TUR = "tur";
    public static final String COL_KILOMETRE = "kilometre";
    public static final String COL_TARIH_TEXT = "tarih_text";
    public static final String COL_KONUM = "konum";
    public static final String COL_MALIYET = "maliyet";
    public static final String COL_SERVIS_TARIHI_MS = "servis_tarihi_ms";

    private static DatabaseHelper instance;

    private DatabaseHelper(@NonNull Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized DatabaseHelper getInstance(@NonNull Context context) {
        if (instance == null) {
            DatabaseHelper helper = new DatabaseHelper(context.getApplicationContext());
            helper.migrateFromPreferencesIfNeeded(context.getApplicationContext());
            instance = helper;
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + TABLE_SERVICE + " ("
                        + COL_ID + " INTEGER PRIMARY KEY, "
                        + COL_BASLIK + " TEXT NOT NULL, "
                        + COL_TUR + " TEXT NOT NULL, "
                        + COL_KILOMETRE + " INTEGER NOT NULL, "
                        + COL_TARIH_TEXT + " TEXT NOT NULL, "
                        + COL_KONUM + " TEXT NOT NULL, "
                        + COL_MALIYET + " REAL NOT NULL, "
                        + COL_SERVIS_TARIHI_MS + " INTEGER NOT NULL)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SERVICE);
        onCreate(db);
    }

    private void migrateFromPreferencesIfNeeded(@NonNull Context context) {
        if (getServiceCount() > 0) {
            return;
        }
        List<ServiceHistoryEntry> legacy = AppPreferences.getLegacyServiceHistoryRecords(context);
        for (ServiceHistoryEntry entry : legacy) {
            insertServiceRecord(entry);
        }
    }

    public long insertServiceRecord(@NonNull ServiceHistoryEntry entry) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ID, entry.getId());
        values.put(COL_BASLIK, entry.getTitle());
        values.put(COL_TUR, entry.getType().name());
        values.put(COL_KILOMETRE, entry.getMileage());
        values.put(COL_TARIH_TEXT, entry.getDateText());
        values.put(COL_KONUM, entry.getLocation());
        values.put(COL_MALIYET, entry.getCost());
        values.put(COL_SERVIS_TARIHI_MS, entry.getServiceDateMs());
        return db.insertWithOnConflict(TABLE_SERVICE, null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public boolean deleteServiceRecord(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_SERVICE, COL_ID + " = ?", new String[]{String.valueOf(id)}) > 0;
    }

    @NonNull
    public List<ServiceHistoryEntry> getAllServiceRecords() {
        List<ServiceHistoryEntry> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_SERVICE,
                null,
                null,
                null,
                null,
                null,
                COL_SERVIS_TARIHI_MS + " DESC"
        );
        if (cursor == null) {
            return list;
        }
        while (cursor.moveToNext()) {
            list.add(mapCursorToEntry(cursor));
        }
        cursor.close();
        return list;
    }

    public double getCalculatedServiceTotal() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT SUM(" + COL_MALIYET + ") FROM " + TABLE_SERVICE,
                null
        );
        double total = 0d;
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                total = cursor.getDouble(0);
            }
            cursor.close();
        }
        return total;
    }

    private int getServiceCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_SERVICE, null);
        int count = 0;
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
            cursor.close();
        }
        return count;
    }

    @NonNull
    private ServiceHistoryEntry mapCursorToEntry(@NonNull Cursor cursor) {
        return new ServiceHistoryEntry(
                cursor.getLong(cursor.getColumnIndexOrThrow(COL_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_BASLIK)),
                ServiceHistoryEntry.Type.valueOf(cursor.getString(cursor.getColumnIndexOrThrow(COL_TUR))),
                cursor.getInt(cursor.getColumnIndexOrThrow(COL_KILOMETRE)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_TARIH_TEXT)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_KONUM)),
                cursor.getDouble(cursor.getColumnIndexOrThrow(COL_MALIYET)),
                cursor.getLong(cursor.getColumnIndexOrThrow(COL_SERVIS_TARIHI_MS))
        );
    }
}
