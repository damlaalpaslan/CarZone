package com.ece.aractakip.model;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class UserProfile {

    @Nullable
    private String photoUri;
    @NonNull
    private String fullName;
    @NonNull
    private String phone;

    public UserProfile() {
        fullName = "";
        phone = "";
    }

    public UserProfile(@Nullable String photoUri, @NonNull String fullName, @NonNull String phone) {
        this.photoUri = photoUri;
        this.fullName = fullName;
        this.phone = phone;
    }

    @Nullable
    public String getPhotoUri() {
        return photoUri;
    }

    public void setPhotoUri(@Nullable String photoUri) {
        this.photoUri = photoUri;
    }

    @NonNull
    public String getFullName() {
        return fullName;
    }

    public void setFullName(@NonNull String fullName) {
        this.fullName = fullName;
    }

    @NonNull
    public String getPhone() {
        return phone;
    }

    public void setPhone(@NonNull String phone) {
        this.phone = phone;
    }
}
