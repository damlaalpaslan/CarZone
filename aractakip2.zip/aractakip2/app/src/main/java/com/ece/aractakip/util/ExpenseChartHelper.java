package com.ece.aractakip.util;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.ece.aractakip.R;
import com.ece.aractakip.data.AppPreferences;
import com.ece.aractakip.data.DatabaseHelper;
import com.ece.aractakip.model.ExpenseEntry;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import java.text.NumberFormat;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ExpenseChartHelper {

    public static final class Totals {
        public final float servis;
        public final float sigorta;
        public final float bakim;
        public final float yakit;
        public final float total;

        Totals(float servis, float sigorta, float bakim, float yakit) {
            this.servis = servis;
            this.sigorta = sigorta;
            this.bakim = bakim;
            this.yakit = yakit;
            this.total = servis + sigorta + bakim + yakit;
        }

        @Nullable
        public CategoryAmount getHighestCategory(@NonNull Context context) {
            if (total <= 0f) {
                return null;
            }
            CategoryAmount highest = new CategoryAmount(
                    context.getString(R.string.expense_category_service), servis);
            if (sigorta > highest.amount) {
                highest = new CategoryAmount(
                        context.getString(R.string.expense_category_insurance), sigorta);
            }
            if (bakim > highest.amount) {
                highest = new CategoryAmount(
                        context.getString(R.string.expense_category_maintenance), bakim);
            }
            if (yakit > highest.amount) {
                highest = new CategoryAmount(
                        context.getString(R.string.expense_category_fuel), yakit);
            }
            return highest.amount > 0f ? highest : null;
        }
    }

    public static final class CategoryAmount {
        public final String label;
        public final float amount;

        CategoryAmount(@NonNull String label, float amount) {
            this.label = label;
            this.amount = amount;
        }
    }

    public static final class MonthlyDistanceData {
        public final boolean hasEnoughData;
        public final boolean showFirstEntryPrompt;
        @NonNull
        public final List<BarEntry> barEntries;
        @NonNull
        public final List<String> monthLabels;
        @NonNull
        public final List<Integer> monthlyDiffs;
        @Nullable
        public final String comparisonText;
        @Nullable
        public final String maintenanceSuggestionText;

        MonthlyDistanceData(boolean hasEnoughData,
                            boolean showFirstEntryPrompt,
                            @NonNull List<BarEntry> barEntries,
                            @NonNull List<String> monthLabels,
                            @NonNull List<Integer> monthlyDiffs,
                            @Nullable String comparisonText,
                            @Nullable String maintenanceSuggestionText) {
            this.hasEnoughData = hasEnoughData;
            this.showFirstEntryPrompt = showFirstEntryPrompt;
            this.barEntries = barEntries;
            this.monthLabels = monthLabels;
            this.monthlyDiffs = monthlyDiffs;
            this.comparisonText = comparisonText;
            this.maintenanceSuggestionText = maintenanceSuggestionText;
        }
    }

    private ExpenseChartHelper() {
    }

    @NonNull
    public static Totals loadTotals(@NonNull Context context,
                                    @NonNull DatabaseHelper databaseHelper) {
        float servis = (float) databaseHelper.getCalculatedServiceTotal();
        float sigorta = 0f;
        float bakim = 0f;
        float yakit = 0f;
        for (ExpenseEntry item : AppPreferences.getExpenses(context)) {
            switch (item.getCategory()) {
                case SERVIS:
                    servis += item.getAmount();
                    break;
                case SIGORTA:
                    sigorta += item.getAmount();
                    break;
                case BAKIM:
                    bakim += item.getAmount();
                    break;
                case YAKIT:
                    yakit += item.getAmount();
                    break;
                default:
                    break;
            }
        }
        return new Totals(servis, sigorta, bakim, yakit);
    }

    public static void renderPieChart(@NonNull Context context,
                                      @NonNull PieChart chart,
                                      @Nullable TextView emptyView,
                                      @NonNull Totals totals) {
        if (totals.total <= 0f) {
            chart.clear();
            chart.invalidate();
            if (emptyView != null) {
                emptyView.setVisibility(View.VISIBLE);
            }
            return;
        }
        if (emptyView != null) {
            emptyView.setVisibility(View.GONE);
        }

        final float chartTotal = totals.total;
        Locale trLocale = new Locale("tr", "TR");
        List<PieEntry> entries = new ArrayList<>();
        if (totals.servis > 0f) {
            entries.add(new PieEntry(totals.servis,
                    context.getString(R.string.expense_category_service)));
        }
        if (totals.sigorta > 0f) {
            entries.add(new PieEntry(totals.sigorta,
                    context.getString(R.string.expense_category_insurance)));
        }
        if (totals.bakim > 0f) {
            entries.add(new PieEntry(totals.bakim,
                    context.getString(R.string.expense_category_maintenance)));
        }
        if (totals.yakit > 0f) {
            entries.add(new PieEntry(totals.yakit,
                    context.getString(R.string.expense_category_fuel)));
        }

        PieDataSet dataSet = new PieDataSet(entries, "");
        List<Integer> colors = new ArrayList<>();
        for (PieEntry entry : entries) {
            colors.add(colorForExpenseLabel(context, entry.getLabel()));
        }
        dataSet.setColors(colors);
        dataSet.setValueTextColor(ContextCompat.getColor(context, R.color.text_primary));
        dataSet.setValueTextSize(11f);
        dataSet.setSliceSpace(2f);
        dataSet.setSelectionShift(4f);
        dataSet.setXValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        dataSet.setYValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        dataSet.setValueLinePart1Length(0.35f);
        dataSet.setValueLinePart2Length(0.3f);
        dataSet.setValueLineWidth(1f);
        dataSet.setUsingSliceColorAsValueLineColor(true);

        ValueFormatter pieLabelFormatter = createPiePercentFormatter(chart, chartTotal, trLocale);
        dataSet.setDrawValues(true);
        dataSet.setValueFormatter(pieLabelFormatter);

        PieData pieData = new PieData(dataSet);
        pieData.setValueFormatter(pieLabelFormatter);
        pieData.setValueTextSize(11f);
        chart.setUsePercentValues(false);
        chart.setDrawEntryLabels(false);
        chart.setRotationAngle(-90f);
        chart.setRotationEnabled(false);
        chart.setHighlightPerTapEnabled(false);
        chart.setExtraOffsets(20f, 16f, 20f, 16f);
        chart.setData(pieData);
        chart.setHoleRadius(48f);
        chart.setTransparentCircleRadius(52f);
        chart.setCenterText(context.getString(R.string.stats_expense_analysis));
        chart.setCenterTextSize(13f);
        chart.setCenterTextColor(ContextCompat.getColor(context, R.color.text_primary));
        Description description = new Description();
        description.setText("");
        chart.setDescription(description);
        Legend legend = chart.getLegend();
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
        legend.setWordWrapEnabled(true);
        legend.setForm(Legend.LegendForm.SQUARE);
        legend.setFormSize(10f);
        legend.setTextSize(12f);
        legend.setTextColor(ContextCompat.getColor(context, R.color.text_primary));
        chart.notifyDataSetChanged();
        chart.invalidate();
    }

    @NonNull
    public static MonthlyDistanceData buildMonthlyDistanceData(@NonNull Context context,
                                                               @NonNull Map<String, Integer> odometerMap) {
        List<YearMonth> months = new ArrayList<>();
        for (String key : odometerMap.keySet()) {
            try {
                months.add(YearMonth.parse(key));
            } catch (Exception ignored) {
            }
        }
        Collections.sort(months);

        if (months.isEmpty()) {
            return new MonthlyDistanceData(
                    false,
                    true,
                    Collections.emptyList(),
                    Collections.emptyList(),
                    Collections.emptyList(),
                    null,
                    null);
        }

        int baselineKm = AppPreferences.getMonthlyOdometerBaseline(context);
        Locale trLocale = new Locale("tr", "TR");
        NumberFormat distanceFormat = NumberFormat.getNumberInstance(trLocale);
        DateTimeFormatter monthShort = DateTimeFormatter.ofPattern("MMM", trLocale);
        List<BarEntry> barEntries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        List<Integer> monthlyDiffs = new ArrayList<>();

        for (int i = 0; i < months.size(); i++) {
            YearMonth currentMonth = months.get(i);
            int currentKm = odometerMap.getOrDefault(currentMonth.toString(), 0);
            int previousKm;
            if (i == 0) {
                previousKm = baselineKm;
                if (months.size() >= 2) {
                    int nextKm = odometerMap.getOrDefault(months.get(i + 1).toString(), 0);
                    int monthToMonthDiff = Math.max(0, nextKm - currentKm);
                    if (previousKm <= 0 || (currentKm - previousKm) > monthToMonthDiff * 3) {
                        int inferredPrevious = (2 * currentKm) - nextKm;
                        if (inferredPrevious >= 0 && inferredPrevious < currentKm) {
                            previousKm = inferredPrevious;
                        }
                    }
                }
            } else {
                previousKm = odometerMap.getOrDefault(months.get(i - 1).toString(), 0);
            }
            int diff = Math.max(0, currentKm - previousKm);
            monthlyDiffs.add(diff);
            barEntries.add(new BarEntry(barEntries.size(), diff));
            String label = currentMonth.atDay(1).format(monthShort);
            if (!label.isEmpty()) {
                label = label.substring(0, 1).toUpperCase(trLocale) + label.substring(1);
            }
            labels.add(label);
        }

        String comparisonText = null;
        int latest = monthlyDiffs.get(monthlyDiffs.size() - 1);
        if (monthlyDiffs.size() == 1) {
            comparisonText = context.getString(
                    R.string.stats_latest_month_distance,
                    distanceFormat.format(latest));
        } else {
            int previous = monthlyDiffs.get(monthlyDiffs.size() - 2);
            if (previous > 0) {
                float ratio = ((latest - previous) * 100f) / previous;
                String sign = ratio >= 0 ? "+" : "";
                comparisonText = context.getString(
                        R.string.stats_comparison_template,
                        sign + Math.round(ratio) + "%");
            } else {
                comparisonText = context.getString(
                        R.string.stats_latest_month_distance,
                        distanceFormat.format(latest));
            }
        }

        String maintenanceSuggestionText = buildMaintenanceSuggestionText(
                context, monthlyDiffs, distanceFormat);
        return new MonthlyDistanceData(
                true,
                false,
                barEntries,
                labels,
                monthlyDiffs,
                comparisonText,
                maintenanceSuggestionText);
    }

    public static void renderMonthlyBarChart(@NonNull Context context,
                                             @NonNull BarChart chart,
                                             @Nullable TextView emptyView,
                                             @NonNull MonthlyDistanceData data) {
        if (!data.hasEnoughData || data.barEntries.isEmpty()) {
            chart.clear();
            chart.invalidate();
            if (emptyView != null) {
                emptyView.setVisibility(View.VISIBLE);
            }
            return;
        }
        if (emptyView != null) {
            emptyView.setVisibility(View.GONE);
        }

        BarDataSet dataSet = new BarDataSet(data.barEntries, context.getString(R.string.stats_monthly_distance));
        dataSet.setColor(ContextCompat.getColor(context, R.color.setup_primary));
        dataSet.setValueTextColor(ContextCompat.getColor(context, R.color.text_primary));
        dataSet.setDrawValues(true);
        Locale trLocale = new Locale("tr", "TR");
        NumberFormat distanceFormat = NumberFormat.getNumberInstance(trLocale);
        dataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return distanceFormat.format(Math.round(value));
            }
        });
        BarData barData = new BarData(dataSet);
        barData.setBarWidth(0.55f);
        barData.setValueTextSize(10f);

        chart.setData(barData);
        chart.getAxisRight().setEnabled(false);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);
        chart.setFitBars(true);
        chart.setScaleEnabled(false);
        chart.setPinchZoom(false);
        chart.setDoubleTapToZoomEnabled(false);

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setLabelCount(data.monthLabels.size(), false);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(data.monthLabels));
        xAxis.setDrawGridLines(false);
        xAxis.setCenterAxisLabels(false);
        xAxis.setAvoidFirstLastClipping(true);
        int axisTextColor = ContextCompat.getColor(context, R.color.text_primary);
        xAxis.setTextColor(axisTextColor);
        chart.getAxisLeft().setTextColor(axisTextColor);
        chart.getAxisLeft().setGridColor(ContextCompat.getColor(context, R.color.setup_step_line));
        float barCount = Math.max(data.barEntries.size(), 1);
        xAxis.setAxisMinimum(-0.5f);
        xAxis.setAxisMaximum(barCount - 0.5f);

        chart.getAxisLeft().setAxisMinimum(0f);
        chart.getAxisLeft().setGranularityEnabled(true);
        chart.setExtraBottomOffset(12f);
        chart.notifyDataSetChanged();
        chart.invalidate();
    }

    @Nullable
    private static String buildMaintenanceSuggestionText(@NonNull Context context,
                                                         @NonNull List<Integer> monthlyDiffs,
                                                         @NonNull NumberFormat distanceFormat) {
        if (monthlyDiffs.size() < 2) {
            return null;
        }
        int current = monthlyDiffs.get(monthlyDiffs.size() - 1);
        float total = 0f;
        for (int i = 0; i < monthlyDiffs.size() - 1; i++) {
            total += monthlyDiffs.get(i);
        }
        float average = total / (monthlyDiffs.size() - 1);
        if (average <= 0f) {
            return null;
        }
        float increasePercent = ((current - average) * 100f) / average;
        if (increasePercent < 20f) {
            return null;
        }
        String percentText = String.valueOf(Math.round(increasePercent));
        return context.getString(
                R.string.stats_maintenance_warning_template,
                percentText,
                distanceFormat.format(current),
                distanceFormat.format(Math.round(average)));
    }

    @NonNull
    private static ValueFormatter createPiePercentFormatter(@NonNull PieChart chart,
                                                            float chartTotal,
                                                            @NonNull Locale locale) {
        return new PercentFormatter(chart) {
            @Override
            public String getPieLabel(float value, PieEntry pieEntry) {
                float percent = chartTotal > 0f ? (pieEntry.getValue() / chartTotal) * 100f : 0f;
                return formatPercentLabel(locale, percent, pieEntry.getLabel());
            }
        };
    }

    @NonNull
    private static String formatPercentLabel(@NonNull Locale locale,
                                             float percent,
                                             @NonNull String label) {
        float rounded = Math.round(percent * 10f) / 10f;
        String percentText;
        if (Math.abs(rounded - Math.round(rounded)) < 0.05f) {
            percentText = String.format(locale, "%d", Math.round(rounded));
        } else {
            percentText = String.format(locale, "%.1f", rounded);
        }
        return percentText + "% " + label;
    }

    public static int colorForExpenseLabel(@NonNull Context context, @NonNull String label) {
        if (label.equals(context.getString(R.string.expense_category_service))) {
            return ContextCompat.getColor(context, R.color.expense_chart_service);
        }
        if (label.equals(context.getString(R.string.expense_category_insurance))) {
            return ContextCompat.getColor(context, R.color.expense_chart_insurance);
        }
        if (label.equals(context.getString(R.string.expense_category_maintenance))) {
            return ContextCompat.getColor(context, R.color.expense_chart_maintenance);
        }
        if (label.equals(context.getString(R.string.expense_category_fuel))) {
            return ContextCompat.getColor(context, R.color.expense_chart_fuel);
        }
        return ContextCompat.getColor(context, R.color.reminder_blue);
    }

    public static float parseAmount(@NonNull String raw) throws NumberFormatException {
        return (float) NumberInputFormatUtil.parseGroupedDecimal(raw);
    }
}
