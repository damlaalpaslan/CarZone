package com.ece.aractakip.util;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.ece.aractakip.R;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public final class MaterialDatePickerHelper {

    private MaterialDatePickerHelper() {
    }

    public static void show(@NonNull Fragment fragment,
                            @Nullable Long initialDateMs,
                            @NonNull DateSelectedListener listener) {
        show(fragment.getParentFragmentManager(), initialDateMs, listener);
    }

    public static void show(@NonNull FragmentManager manager,
                            @Nullable Long initialDateMs,
                            @NonNull DateSelectedListener listener) {
        MaterialDatePicker.Builder<Long> builder = MaterialDatePicker.Builder.datePicker()
                .setTheme(R.style.ThemeOverlay_Aractakip_DatePicker);
        if (initialDateMs != null && initialDateMs > 0) {
            builder.setSelection(toPickerUtcMillis(initialDateMs));
        }
        MaterialDatePicker picker = builder.build();
        picker.addOnPositiveButtonClickListener(selection -> {
            if (selection instanceof Long) {
                listener.onDateSelected(toLocalMidnightMillis((Long) selection));
            }
        });
        picker.show(manager, "material_date_picker");
    }

    public static void attachToDateField(@NonNull Fragment fragment,
                                         @NonNull TextInputEditText editText) {
        editText.setFocusable(false);
        editText.setClickable(true);
        editText.setCursorVisible(false);
        View.OnClickListener openPicker = v -> openForField(fragment, editText);
        editText.setOnClickListener(openPicker);
        View parent = (View) editText.getParent();
        if (parent != null) {
            parent.setOnClickListener(openPicker);
        }
    }

    private static void openForField(@NonNull Fragment fragment,
                                     @NonNull TextInputEditText editText) {
        Long initial = null;
        CharSequence current = editText.getText();
        if (current != null && current.length() > 0) {
            long parsed = DateInputUtils.parseTurkishDateOrZero(current.toString());
            if (parsed > 0) {
                initial = parsed;
            }
        }
        show(fragment, initial, selectedMs ->
                editText.setText(DateInputUtils.formatTurkishDate(selectedMs)));
    }

    public static long toLocalMidnightMillis(long pickerUtcMillis) {
        Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        utc.setTimeInMillis(pickerUtcMillis);
        Calendar local = Calendar.getInstance(Locale.forLanguageTag("tr-TR"));
        local.set(Calendar.YEAR, utc.get(Calendar.YEAR));
        local.set(Calendar.MONTH, utc.get(Calendar.MONTH));
        local.set(Calendar.DAY_OF_MONTH, utc.get(Calendar.DAY_OF_MONTH));
        local.set(Calendar.HOUR_OF_DAY, 0);
        local.set(Calendar.MINUTE, 0);
        local.set(Calendar.SECOND, 0);
        local.set(Calendar.MILLISECOND, 0);
        return local.getTimeInMillis();
    }

    private static long toPickerUtcMillis(long localDateMs) {
        Calendar local = Calendar.getInstance(Locale.forLanguageTag("tr-TR"));
        local.setTimeInMillis(localDateMs);
        Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        utc.set(Calendar.YEAR, local.get(Calendar.YEAR));
        utc.set(Calendar.MONTH, local.get(Calendar.MONTH));
        utc.set(Calendar.DAY_OF_MONTH, local.get(Calendar.DAY_OF_MONTH));
        utc.set(Calendar.HOUR_OF_DAY, 0);
        utc.set(Calendar.MINUTE, 0);
        utc.set(Calendar.SECOND, 0);
        utc.set(Calendar.MILLISECOND, 0);
        return utc.getTimeInMillis();
    }

    public interface DateSelectedListener {
        void onDateSelected(long localDateMs);
    }
}
