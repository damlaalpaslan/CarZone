package com.ece.aractakip.util;

import androidx.annotation.NonNull;

import com.ece.aractakip.R;
import com.ece.aractakip.model.DocumentEntry;
import com.ece.aractakip.model.DocumentTypeOption;

import java.util.Arrays;
import java.util.List;

public final class DocumentTypeCatalog {

    private DocumentTypeCatalog() {
    }

    @NonNull
    public static List<DocumentTypeOption> allOptions() {
        return Arrays.asList(
                new DocumentTypeOption(
                        DocumentEntry.Type.VEHICLE_REGISTRATION,
                        R.string.document_type_registration,
                        R.drawable.ic_car_card,
                        R.color.doc_tint_blue,
                        R.color.doc_tint_blue_bg),
                new DocumentTypeOption(
                        DocumentEntry.Type.TRAFFIC_INSURANCE,
                        R.string.document_type_traffic_insurance,
                        R.drawable.ic_shield_alert,
                        R.color.service_accent_red,
                        R.color.service_badge_red_bg),
                new DocumentTypeOption(
                        DocumentEntry.Type.CASCO,
                        R.string.document_type_casco,
                        R.drawable.ic_shield_check,
                        R.color.service_accent_green,
                        R.color.service_badge_green_bg),
                new DocumentTypeOption(
                        DocumentEntry.Type.DRIVER_LICENSE,
                        R.string.document_type_license,
                        R.drawable.ic_driver_license,
                        R.color.doc_tint_purple,
                        R.color.doc_tint_purple_bg),
                new DocumentTypeOption(
                        DocumentEntry.Type.INSPECTION_EXHAUST,
                        R.string.document_type_inspection,
                        R.drawable.ic_stamp_check,
                        R.color.doc_tint_teal,
                        R.color.doc_tint_teal_bg),
                new DocumentTypeOption(
                        DocumentEntry.Type.CUSTOM,
                        R.string.document_custom_option,
                        R.drawable.ic_custom_file,
                        R.color.service_tint_dark_gray,
                        R.color.service_tint_dark_gray_bg)
        );
    }

    @NonNull
    public static DocumentTypeOption optionForType(@NonNull DocumentEntry.Type type) {
        for (DocumentTypeOption option : allOptions()) {
            if (option.getType() == type) {
                return option;
            }
        }
        return allOptions().get(allOptions().size() - 1);
    }
}
