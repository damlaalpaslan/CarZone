package com.ece.aractakip.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ece.aractakip.R;
import com.ece.aractakip.adapter.ReminderSectionAdapter;
import com.ece.aractakip.data.AppPreferences;
import com.ece.aractakip.data.ReminderRepository;
import com.ece.aractakip.databinding.FragmentRemindersBinding;
import com.ece.aractakip.model.Reminder;
import com.ece.aractakip.model.VehicleModel;
import com.ece.aractakip.util.DateInputUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class RemindersFragment extends Fragment implements
        ReminderSectionAdapter.ReminderActionListener,
        AddEditReminderBottomSheet.ReminderFormListener {

    @Nullable
    private FragmentRemindersBinding binding;
    private ReminderSectionAdapter reminderAdapter;
    private final List<Reminder> reminders = new ArrayList<>();
    private int currentVehicleMileage;

    public static RemindersFragment newInstance() {
        return new RemindersFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentRemindersBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }
        reminderAdapter = new ReminderSectionAdapter(requireContext(), this);
        binding.recyclerReminders.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerReminders.setAdapter(reminderAdapter);
        new ItemTouchHelper(new ReminderSwipeCallback(requireContext(), reminderAdapter, reminder -> {
            reminders.removeIf(item -> item.getId().equals(reminder.getId()));
            persistReminders();
            renderReminders();
            Toast.makeText(requireContext(), R.string.reminder_deleted_toast, Toast.LENGTH_SHORT).show();
        })).attachToRecyclerView(binding.recyclerReminders);
        binding.fabReminderAdd.setOnClickListener(v -> showAddReminderBottomSheet());

        VehicleModel vehicle = AppPreferences.loadVehicle(requireContext());
        currentVehicleMileage = Math.max(0, vehicle.getMileage());
        reminders.clear();
        reminders.addAll(ReminderRepository.loadReminders(requireContext()));
        renderReminders();
    }

    @Override
    public void onResume() {
        super.onResume();
        VehicleModel vehicle = AppPreferences.loadVehicle(requireContext());
        currentVehicleMileage = Math.max(0, vehicle.getMileage());
        reminders.clear();
        reminders.addAll(ReminderRepository.loadReminders(requireContext()));
        renderReminders();
    }

    private void persistReminders() {
        ReminderRepository.saveReminders(requireContext(), reminders);
    }

    private void renderReminders() {
        if (binding == null) {
            return;
        }
        List<ReminderCardState> critical = new ArrayList<>();
        List<ReminderCardState> legal = new ArrayList<>();
        List<ReminderCardState> technical = new ArrayList<>();
        List<ReminderCardState> completed = new ArrayList<>();

        for (Reminder reminder : reminders) {
            ReminderCardState state = toCardState(reminder);
            if (reminder.isDone()) {
                completed.add(state);
                continue;
            }
            if (state.isCritical) {
                critical.add(state);
            } else if (reminder.getCategory() == Reminder.Category.LEGAL) {
                legal.add(state);
            } else if (reminder.getCategory() == Reminder.Category.TECHNICAL) {
                technical.add(state);
            }
        }

        Comparator<ReminderCardState> byUrgency = Comparator.comparingLong(s -> s.sortScore);
        critical.sort(byUrgency);
        legal.sort(byUrgency);
        technical.sort(byUrgency);
        completed.sort((a, b) -> a.reminder.getName().compareToIgnoreCase(b.reminder.getName()));

        List<ReminderSectionAdapter.RowItem> rows = new ArrayList<>();
        addSectionIfNotEmpty(rows, getString(R.string.reminder_section_critical), critical, true, false);
        addSectionIfNotEmpty(rows, getString(R.string.reminder_section_legal), legal, false, false);
        addSectionIfNotEmpty(rows, getString(R.string.reminder_section_technical), technical, false, false);
        addSectionIfNotEmpty(rows, getString(R.string.reminder_section_completed), completed, false, true);

        reminderAdapter.submitRows(rows);
        binding.textRemindersEmpty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void addSectionIfNotEmpty(@NonNull List<ReminderSectionAdapter.RowItem> rows,
                                      @NonNull String title,
                                      @NonNull List<ReminderCardState> sectionItems,
                                      boolean criticalHighlight,
                                      boolean completedSection) {
        if (sectionItems.isEmpty()) {
            return;
        }
        rows.add(ReminderSectionAdapter.header(title));
        for (ReminderCardState state : sectionItems) {
            rows.add(ReminderSectionAdapter.item(new ReminderSectionAdapter.ReminderUiModel(
                    state.reminder,
                    criticalHighlight,
                    state.dueText,
                    state.showProgress,
                    state.progressPercent,
                    state.progressText,
                    completedSection
            )));
        }
    }

    private ReminderCardState toCardState(@NonNull Reminder reminder) {
        long daysUntil = Long.MAX_VALUE;
        if (reminder.getDueDateMs() != null) {
            daysUntil = DateInputUtils.fullDaysUntilLocalDate(reminder.getDueDateMs());
        }
        long kmUntil = Long.MAX_VALUE;
        if (reminder.getDueMileageKm() != null) {
            kmUntil = reminder.getDueMileageKm() - currentVehicleMileage;
        }

        boolean hasDate = reminder.getDueDateMs() != null;
        boolean hasKm = reminder.getDueMileageKm() != null;
        boolean useKmAsPrimary = hasKm && (!hasDate || kmUntil <= (daysUntil * 120L));
        boolean isCritical = (hasDate && daysUntil <= 7) || (hasKm && kmUntil <= 500);

        String dueText;
        String progressText = "";
        boolean showProgress = false;
        int progressPercent = 0;
        long sortScore;

        if (useKmAsPrimary) {
            int dueKm = reminder.getDueMileageKm() == null ? currentVehicleMileage : reminder.getDueMileageKm();
            int kmLeft = dueKm - currentVehicleMileage;
            dueText = kmLeft < 0
                    ? getString(R.string.reminder_due_km_overdue, ReminderSectionAdapter.formatMileage(requireContext(), Math.abs(kmLeft)))
                    : getString(R.string.reminder_due_km_left,
                    ReminderSectionAdapter.formatMileage(requireContext(), kmLeft),
                    ReminderSectionAdapter.formatMileage(requireContext(), dueKm));

            showProgress = reminder.getCategory() == Reminder.Category.TECHNICAL;
            if (showProgress) {
                int completed = Math.max(0, currentVehicleMileage);
                int target = Math.max(1, dueKm);
                progressPercent = Math.min(100, (int) ((completed * 100f) / target));
                progressText = getString(R.string.reminder_progress_km_left,
                        ReminderSectionAdapter.formatMileage(requireContext(), Math.max(0, kmLeft)),
                        ReminderSectionAdapter.formatMileage(requireContext(), dueKm));
            }
            sortScore = kmUntil;
        } else if (hasDate) {
            dueText = ReminderSectionAdapter.buildDateText(requireContext(), reminder.getDueDateMs(), daysUntil);
            sortScore = daysUntil;
        } else {
            dueText = getString(R.string.alert_date_missing);
            sortScore = Long.MAX_VALUE - 1;
        }

        return new ReminderCardState(reminder, isCritical, dueText, showProgress, progressPercent, progressText, sortScore);
    }

    private void showAddReminderBottomSheet() {
        AddEditReminderBottomSheet sheet = AddEditReminderBottomSheet.newAdd();
        sheet.setReminderFormListener(this);
        sheet.show(getParentFragmentManager(), "add_reminder");
    }

    private void showEditReminderBottomSheet(@NonNull Reminder reminder) {
        AddEditReminderBottomSheet sheet = AddEditReminderBottomSheet.newEdit(reminder);
        sheet.setReminderFormListener(this);
        sheet.show(getParentFragmentManager(), "edit_reminder");
    }

    @Override
    public void onMarkAsDone(@NonNull Reminder reminder) {
        reminder.setDone(true);
        persistReminders();
        renderReminders();
        Toast.makeText(requireContext(), R.string.reminder_done_toast, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onEditReminder(@NonNull Reminder reminder) {
        showEditReminderBottomSheet(reminder);
    }

    @Override
    public void onReminderSaved(@NonNull String reminderId,
                                @NonNull String name,
                                @NonNull Reminder.Category category,
                                @Nullable Long dueDateMs,
                                @Nullable Integer dueMileageKm,
                                boolean isEditMode) {
        if (isEditMode) {
            for (Reminder item : reminders) {
                if (item.getId().equals(reminderId)) {
                    item.setName(name);
                    item.setCategory(category);
                    item.setDueDateMs(dueDateMs);
                    item.setDueMileageKm(dueMileageKm);
                    item.setDone(false);
                    persistReminders();
                    renderReminders();
                    Toast.makeText(requireContext(), R.string.reminder_updated_toast, Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        }

        reminders.add(new Reminder(name, category, dueDateMs, dueMileageKm));
        persistReminders();
        renderReminders();
        Toast.makeText(requireContext(), R.string.reminder_added_toast, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private static class ReminderCardState {
        @NonNull
        final Reminder reminder;
        final boolean isCritical;
        @NonNull
        final String dueText;
        final boolean showProgress;
        final int progressPercent;
        @NonNull
        final String progressText;
        final long sortScore;

        ReminderCardState(@NonNull Reminder reminder,
                          boolean isCritical,
                          @NonNull String dueText,
                          boolean showProgress,
                          int progressPercent,
                          @NonNull String progressText,
                          long sortScore) {
            this.reminder = reminder;
            this.isCritical = isCritical;
            this.dueText = dueText;
            this.showProgress = showProgress;
            this.progressPercent = progressPercent;
            this.progressText = progressText;
            this.sortScore = sortScore;
        }
    }
}
