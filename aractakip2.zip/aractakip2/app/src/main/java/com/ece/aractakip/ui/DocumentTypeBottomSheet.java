package com.ece.aractakip.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ece.aractakip.R;
import com.ece.aractakip.adapter.DocumentTypeAdapter;
import com.ece.aractakip.databinding.BottomSheetDocumentTypeBinding;
import com.ece.aractakip.model.DocumentTypeOption;
import com.ece.aractakip.util.DocumentTypeCatalog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class DocumentTypeBottomSheet extends BottomSheetDialogFragment {

    public interface SelectionListener {
        void onTypeSelected(@NonNull DocumentTypeOption option);
    }

    @Nullable
    private BottomSheetDocumentTypeBinding binding;
    @Nullable
    private SelectionListener listener;

    public static DocumentTypeBottomSheet newInstance() {
        return new DocumentTypeBottomSheet();
    }

    public void setSelectionListener(@Nullable SelectionListener listener) {
        this.listener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = BottomSheetDocumentTypeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (binding == null) {
            return;
        }

        DocumentTypeAdapter adapter = new DocumentTypeAdapter(
                LayoutInflater.from(requireContext()),
                option -> {
                    if (listener != null) {
                        listener.onTypeSelected(option);
                    }
                    dismiss();
                }
        );
        binding.recyclerDocumentTypes.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerDocumentTypes.setAdapter(adapter);
        adapter.submitOptions(DocumentTypeCatalog.allOptions());
    }

    @Override
    public void onStart() {
        super.onStart();
        if (getDialog() != null) {
            View sheet = getDialog().findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (sheet != null) {
                sheet.setBackgroundResource(R.drawable.bg_bottom_sheet_rounded_top);
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
