package com.ece.aractakip.model;

import androidx.annotation.NonNull;

public class ServiceHistoryEntry {

    public enum Type {
        PERIODIC_MAINTENANCE,
        REPAIR,
        HEAVY_MAINTENANCE
    }

    private final long id;
    @NonNull
    private final String title;
    @NonNull
    private final Type type;
    private final int mileage;
    @NonNull
    private final String dateText;
    @NonNull
    private final String location;
    private final double cost;
    private final long serviceDateMs;

    public ServiceHistoryEntry(long id,
                               @NonNull String title,
                               @NonNull Type type,
                               int mileage,
                               @NonNull String dateText,
                               @NonNull String location,
                               double cost,
                               long serviceDateMs) {
        this.id = id;
        this.title = title;
        this.type = type;
        this.mileage = mileage;
        this.dateText = dateText;
        this.location = location;
        this.cost = cost;
        this.serviceDateMs = serviceDateMs;
    }

    public long getId() {
        return id;
    }

    @NonNull
    public String getTitle() {
        return title;
    }

    @NonNull
    public Type getType() {
        return type;
    }

    public int getMileage() {
        return mileage;
    }

    @NonNull
    public String getDateText() {
        return dateText;
    }

    @NonNull
    public String getLocation() {
        return location;
    }

    public double getCost() {
        return cost;
    }

    public long getServiceDateMs() {
        return serviceDateMs;
    }
}
