package com.ece.aractakip.model;

import androidx.annotation.NonNull;

public final class AnomalyNotification {

    private final long id;
    @NonNull
    private final String message;
    private final long timestampMs;
    private final boolean read;

    public AnomalyNotification(long id,
                               @NonNull String message,
                               long timestampMs,
                               boolean read) {
        this.id = id;
        this.message = message;
        this.timestampMs = timestampMs;
        this.read = read;
    }

    public long getId() {
        return id;
    }

    @NonNull
    public String getMessage() {
        return message;
    }

    public long getTimestampMs() {
        return timestampMs;
    }

    public boolean isRead() {
        return read;
    }

    @NonNull
    public AnomalyNotification asRead() {
        return new AnomalyNotification(id, message, timestampMs, true);
    }
}
