package com.ece.aractakip.util;

import android.text.Editable;
import android.text.TextWatcher;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.textfield.TextInputEditText;

import java.text.NumberFormat;
import java.util.Locale;

public final class NumberInputFormatUtil {

    private static final Locale TR = new Locale("tr", "TR");

    private NumberInputFormatUtil() {
    }

    public static void attachGroupedInteger(@NonNull TextInputEditText editText) {
        editText.addTextChangedListener(new GroupedIntegerWatcher(editText));
    }

    public static void attachGroupedDecimal(@NonNull TextInputEditText editText) {
        editText.addTextChangedListener(new GroupedDecimalWatcher(editText));
    }

    @NonNull
    public static String formatGroupedInteger(int value) {
        if (value <= 0) {
            return "";
        }
        return NumberFormat.getIntegerInstance(TR).format(value);
    }

    @NonNull
    public static String formatGroupedDecimal(double value) {
        if (value <= 0d) {
            return "";
        }
        NumberFormat nf = NumberFormat.getNumberInstance(TR);
        nf.setMinimumFractionDigits(0);
        nf.setMaximumFractionDigits(2);
        return nf.format(value);
    }

    public static int parseGroupedInteger(@NonNull String raw) throws NumberFormatException {
        String digits = raw.trim().replace(".", "").replace(" ", "").replace(",", "");
        if (digits.isEmpty()) {
            throw new NumberFormatException("empty");
        }
        return Integer.parseInt(digits);
    }

    public static double parseGroupedDecimal(@NonNull String raw) throws NumberFormatException {
        String normalized = raw.trim().replace(" ", "");
        if (normalized.isEmpty()) {
            throw new NumberFormatException("empty");
        }
        if (normalized.contains(",")) {
            normalized = normalized.replace(".", "").replace(",", ".");
        } else {
            normalized = normalized.replace(".", "");
        }
        double value = Double.parseDouble(normalized);
        if (value <= 0d) {
            throw new NumberFormatException("non-positive");
        }
        return value;
    }

    private static final class GroupedIntegerWatcher implements TextWatcher {
        private final TextInputEditText editText;
        private boolean selfChange;

        private GroupedIntegerWatcher(@NonNull TextInputEditText editText) {
            this.editText = editText;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable editable) {
            if (selfChange) {
                return;
            }
            String digits = editable.toString().replace(".", "").replace(" ", "").replace(",", "");
            if (digits.isEmpty()) {
                return;
            }
            try {
                long value = Long.parseLong(digits);
                String formatted = NumberFormat.getIntegerInstance(TR).format(value);
                if (formatted.contentEquals(editable)) {
                    return;
                }
                selfChange = true;
                editText.setText(formatted);
                editText.setSelection(formatted.length());
                selfChange = false;
            } catch (NumberFormatException ignored) {
            }
        }
    }

    private static final class GroupedDecimalWatcher implements TextWatcher {
        private final TextInputEditText editText;
        private boolean selfChange;

        private GroupedDecimalWatcher(@NonNull TextInputEditText editText) {
            this.editText = editText;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable editable) {
            if (selfChange) {
                return;
            }
            String raw = editable.toString();
            if (raw.isEmpty()) {
                return;
            }

            String[] parts = raw.split(",", -1);
            if (parts.length > 2) {
                return;
            }

            String integerDigits = parts[0].replace(".", "").replaceAll("[^0-9]", "");
            @Nullable String decimalDigits = parts.length > 1
                    ? parts[1].replaceAll("[^0-9]", "")
                    : null;

            StringBuilder formatted = new StringBuilder();
            if (!integerDigits.isEmpty()) {
                try {
                    formatted.append(NumberFormat.getIntegerInstance(TR).format(Long.parseLong(integerDigits)));
                } catch (NumberFormatException ignored) {
                    return;
                }
            }
            if (decimalDigits != null) {
                formatted.append(",").append(decimalDigits);
            }

            String result = formatted.toString();
            if (result.isEmpty() || result.equals(raw)) {
                return;
            }

            selfChange = true;
            editText.setText(result);
            editText.setSelection(result.length());
            selfChange = false;
        }
    }
}
