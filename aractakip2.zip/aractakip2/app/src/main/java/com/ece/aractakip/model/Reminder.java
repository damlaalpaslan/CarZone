package com.ece.aractakip.model;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.UUID;

public class Reminder {

    public enum Category {
        CRITICAL,
        LEGAL,
        TECHNICAL
    }

    private final String id;
    private String name;
    private Category category;
    @Nullable
    private Long dueDateMs;
    @Nullable
    private Integer dueMileageKm;
    private boolean done;

    public Reminder(@NonNull String name,
                    @NonNull Category category,
                    @Nullable Long dueDateMs,
                    @Nullable Integer dueMileageKm) {
        this(UUID.randomUUID().toString(), name, category, dueDateMs, dueMileageKm, false);
    }

    public Reminder(@NonNull String id,
                    @NonNull String name,
                    @NonNull Category category,
                    @Nullable Long dueDateMs,
                    @Nullable Integer dueMileageKm,
                    boolean done) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.dueDateMs = dueDateMs;
        this.dueMileageKm = dueMileageKm;
        this.done = done;
    }

    @NonNull
    public String getId() {
        return id;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public void setName(@NonNull String name) {
        this.name = name;
    }

    @NonNull
    public Category getCategory() {
        return category;
    }

    public void setCategory(@NonNull Category category) {
        this.category = category;
    }

    @Nullable
    public Long getDueDateMs() {
        return dueDateMs;
    }

    public void setDueDateMs(@Nullable Long dueDateMs) {
        this.dueDateMs = dueDateMs;
    }

    @Nullable
    public Integer getDueMileageKm() {
        return dueMileageKm;
    }

    public void setDueMileageKm(@Nullable Integer dueMileageKm) {
        this.dueMileageKm = dueMileageKm;
    }

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }
}
