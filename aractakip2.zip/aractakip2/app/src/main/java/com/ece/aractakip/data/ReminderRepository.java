package com.ece.aractakip.data;

import android.content.Context;

import androidx.annotation.NonNull;

import com.ece.aractakip.R;
import com.ece.aractakip.model.Reminder;
import com.ece.aractakip.util.DateInputUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ReminderRepository {

    private static final String FIELD_SEP = "#";
    private static final String RECORD_SEP = ";";
    private static final long NULL_LONG = -1L;
    private static final int NULL_INT = -1;

    public static final class DashboardAlert {
        @NonNull
        public final String title;
        @NonNull
        public final String countdownText;
        @NonNull
        public final Reminder.Category category;
        public final boolean overdue;
        public final long daysUntil;

        DashboardAlert(@NonNull String title,
                         @NonNull String countdownText,
                         @NonNull Reminder.Category category,
                         boolean overdue,
                         long daysUntil) {
            this.title = title;
            this.countdownText = countdownText;
            this.category = category;
            this.overdue = overdue;
            this.daysUntil = daysUntil;
        }
    }

    private ReminderRepository() {
    }

    @NonNull
    public static List<Reminder> loadReminders(@NonNull Context context) {
        List<Reminder> saved = readSavedReminders(context);
        if (!saved.isEmpty()) {
            return saved;
        }
        int mileage = Math.max(0, AppPreferences.loadVehicle(context).getMileage());
        List<Reminder> defaults = buildDefaultReminders(context, mileage);
        saveReminders(context, defaults);
        return defaults;
    }

    public static void saveReminders(@NonNull Context context, @NonNull List<Reminder> reminders) {
        StringBuilder sb = new StringBuilder();
        for (Reminder reminder : reminders) {
            if (sb.length() > 0) {
                sb.append(RECORD_SEP);
            }
            sb                    .append(reminder.getId())
                    .append(FIELD_SEP)
                    .append(reminder.getName())
                    .append(FIELD_SEP)
                    .append(reminder.getCategory().name())
                    .append(FIELD_SEP)
                    .append(reminder.getDueDateMs() == null ? NULL_LONG : reminder.getDueDateMs())
                    .append(FIELD_SEP)
                    .append(reminder.getDueMileageKm() == null ? NULL_INT : reminder.getDueMileageKm())
                    .append(FIELD_SEP)
                    .append(reminder.isDone() ? 1 : 0);
        }
        AppPreferences.setReminderRecordsRaw(context, sb.toString());
    }

    @NonNull
    public static List<DashboardAlert> getUpcomingDateAlerts(@NonNull Context context,
                                                           @NonNull List<Reminder> reminders) {
        List<DashboardAlert> alerts = new ArrayList<>();
        for (Reminder reminder : reminders) {
            if (reminder.isDone() || reminder.getDueDateMs() == null) {
                continue;
            }
            long daysUntil = DateInputUtils.fullDaysUntilLocalDate(reminder.getDueDateMs());
            if (daysUntil >= 7) {
                continue;
            }
            alerts.add(new DashboardAlert(
                    reminder.getName(),
                    buildDashboardCountdown(context, daysUntil),
                    reminder.getCategory(),
                    daysUntil < 0,
                    daysUntil));
        }
        alerts.sort(Comparator.comparingLong(alert -> alert.daysUntil));
        return alerts;
    }

    @NonNull
    private static List<Reminder> readSavedReminders(@NonNull Context context) {
        String raw = AppPreferences.getReminderRecordsRaw(context);
        List<Reminder> list = new ArrayList<>();
        if (raw == null || raw.trim().isEmpty()) {
            return list;
        }
        String[] rows = raw.split(RECORD_SEP);
        for (String row : rows) {
            String[] parts = row.split(FIELD_SEP, -1);
            if (parts.length != 6) {
                continue;
            }
            try {
                Long dueDate = Long.parseLong(parts[3]) == NULL_LONG ? null : Long.parseLong(parts[3]);
                Integer dueKm = Integer.parseInt(parts[4]) == NULL_INT ? null : Integer.parseInt(parts[4]);
                list.add(new Reminder(
                        parts[0],
                        parts[1],
                        Reminder.Category.valueOf(parts[2]),
                        dueDate,
                        dueKm,
                        "1".equals(parts[5])));
            } catch (Exception ignored) {
            }
        }
        return list;
    }

    @NonNull
    private static List<Reminder> buildDefaultReminders(@NonNull Context context, int currentVehicleMileage) {
        List<Reminder> reminders = new ArrayList<>();
        long now = System.currentTimeMillis();
        long tuvStart = AppPreferences.getTuvInspectionDateMs(context);
        long insuranceStart = AppPreferences.getInsuranceStartDateMs(context);

        Long tuvExpiry = tuvStart > 0 ? DateInputUtils.addYears(tuvStart, 5) : now + 4L * 24 * 60 * 60 * 1000;
        Long insuranceExpiry = insuranceStart > 0
                ? DateInputUtils.addYears(insuranceStart, 1)
                : now + 20L * 24 * 60 * 60 * 1000;

        reminders.add(new Reminder(context.getString(R.string.reminder_name_tuv),
                Reminder.Category.LEGAL, tuvExpiry, null));
        reminders.add(new Reminder(context.getString(R.string.reminder_name_traffic_insurance),
                Reminder.Category.LEGAL, insuranceExpiry, null));
        reminders.add(new Reminder(context.getString(R.string.reminder_name_kasko),
                Reminder.Category.LEGAL, now + 55L * 24 * 60 * 60 * 1000, null));
        reminders.add(new Reminder(context.getString(R.string.reminder_name_mtv),
                Reminder.Category.LEGAL, now + 85L * 24 * 60 * 60 * 1000, null));
        reminders.add(new Reminder(context.getString(R.string.reminder_name_oil_change),
                Reminder.Category.TECHNICAL, now + 35L * 24 * 60 * 60 * 1000, currentVehicleMileage + 2000));
        reminders.add(new Reminder(context.getString(R.string.reminder_name_brake_pads),
                Reminder.Category.TECHNICAL, null, currentVehicleMileage + 6000));
        reminders.add(new Reminder(context.getString(R.string.reminder_name_tire_rotation),
                Reminder.Category.TECHNICAL, now + 120L * 24 * 60 * 60 * 1000, currentVehicleMileage + 8000));
        return reminders;
    }

    @NonNull
    private static String buildDashboardCountdown(@NonNull Context context, long daysUntil) {
        if (daysUntil < 0) {
            return context.getString(R.string.dashboard_alert_overdue, Math.abs(daysUntil));
        }
        if (daysUntil == 0) {
            return context.getString(R.string.dashboard_alert_today);
        }
        return context.getString(R.string.dashboard_alert_days_left, daysUntil);
    }
}
