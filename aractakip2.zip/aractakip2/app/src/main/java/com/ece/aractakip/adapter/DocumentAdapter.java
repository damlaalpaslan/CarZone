package com.ece.aractakip.adapter;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ece.aractakip.R;
import com.ece.aractakip.databinding.ItemDocumentCardBinding;
import com.ece.aractakip.model.DocumentEntry;
import com.ece.aractakip.model.DocumentTypeOption;
import com.ece.aractakip.util.DocumentFileHelper;
import com.ece.aractakip.util.DocumentTypeCatalog;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class DocumentAdapter extends RecyclerView.Adapter<DocumentAdapter.DocumentViewHolder> {

    public interface DocumentClickListener {
        void onDocumentClick(@NonNull DocumentEntry entry);
    }

    private final LayoutInflater inflater;
    private final List<DocumentEntry> documents = new ArrayList<>();
    @Nullable
    private DocumentClickListener clickListener;

    public DocumentAdapter(@NonNull Context context) {
        this.inflater = LayoutInflater.from(context);
    }

    public void setDocumentClickListener(@Nullable DocumentClickListener listener) {
        this.clickListener = listener;
    }

    public void submitList(@NonNull List<DocumentEntry> items) {
        documents.clear();
        documents.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DocumentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new DocumentViewHolder(ItemDocumentCardBinding.inflate(inflater, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull DocumentViewHolder holder, int position) {
        DocumentEntry entry = documents.get(position);
        Context context = holder.binding.getRoot().getContext();
        DocumentTypeOption visual = DocumentTypeCatalog.optionForType(entry.getType());

        holder.binding.textDocumentTitle.setText(entry.getTitle());
        holder.binding.textDocumentNumber.setText(
                context.getString(R.string.document_number_template, entry.getDocumentNumber()));

        holder.binding.imageDocumentIcon.setImageResource(visual.getIconRes());
        holder.binding.imageDocumentIcon.setColorFilter(
                ContextCompat.getColor(context, visual.getIconTintRes()));
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(ContextCompat.getColor(context, visual.getIconBackgroundRes()));
        holder.binding.frameDocumentIcon.setBackground(circle);

        bindExpiryBadge(holder, entry.getExpiryDateMs());
        bindAttachment(holder, entry);

        holder.binding.getRoot().setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onDocumentClick(entry);
            }
        });
    }

    private void bindAttachment(@NonNull DocumentViewHolder holder, @NonNull DocumentEntry entry) {
        Context context = holder.binding.getRoot().getContext();
        String fileUri = entry.getFileUri();
        boolean hasFile = DocumentFileHelper.hasAttachment(fileUri);

        holder.binding.textDocumentAttachmentBadge.setVisibility(
                hasFile ? View.VISIBLE : View.GONE);
        holder.binding.imageDocumentChevron.setVisibility(
                hasFile ? View.VISIBLE : View.INVISIBLE);

        if (!hasFile || fileUri == null) {
            holder.binding.frameDocumentPreview.setVisibility(View.GONE);
            return;
        }

        if (DocumentFileHelper.isImage(fileUri)) {
            Uri viewUri = DocumentFileHelper.resolveViewUri(context, fileUri);
            if (viewUri != null) {
                holder.binding.frameDocumentPreview.setVisibility(View.VISIBLE);
                Glide.with(context)
                        .load(viewUri)
                        .centerCrop()
                        .into(holder.binding.imageDocumentThumbnail);
                return;
            }
        }

        holder.binding.frameDocumentPreview.setVisibility(View.GONE);
    }

    private void bindExpiryBadge(@NonNull DocumentViewHolder holder, long expiryDateMs) {
        Context context = holder.binding.getRoot().getContext();

        if (expiryDateMs == DocumentEntry.UNLIMITED_EXPIRY_MS) {
            holder.binding.textDocumentExpiryBadge.setText(R.string.document_unlimited_badge);
            applyBadgeStyle(holder, R.color.service_badge_green_bg, R.color.service_accent_green);
            return;
        }

        long daysLeft = TimeUnit.MILLISECONDS.toDays(expiryDateMs - System.currentTimeMillis());

        if (daysLeft < 0) {
            holder.binding.textDocumentExpiryBadge.setText(R.string.document_expired);
            applyBadgeStyle(holder, R.color.service_badge_red_bg, R.color.service_accent_red);
            return;
        }

        holder.binding.textDocumentExpiryBadge.setText(
                context.getString(R.string.document_days_left, daysLeft));
        if (daysLeft <= 7) {
            applyBadgeStyle(holder, R.color.service_badge_red_bg, R.color.service_accent_red);
        } else if (daysLeft <= 30) {
            applyBadgeStyle(holder, R.color.service_badge_orange_bg, R.color.service_accent_orange);
        } else {
            applyBadgeStyle(holder, R.color.service_badge_green_bg, R.color.service_accent_green);
        }
    }

    private void applyBadgeStyle(@NonNull DocumentViewHolder holder,
                                 @DrawableRes int bgRes,
                                 @ColorRes int textColorRes) {
        Context context = holder.binding.getRoot().getContext();
        holder.binding.textDocumentExpiryBadge.setBackgroundResource(bgRes);
        holder.binding.textDocumentExpiryBadge.setTextColor(
                ContextCompat.getColor(context, textColorRes));
    }

    @Override
    public int getItemCount() {
        return documents.size();
    }

    static class DocumentViewHolder extends RecyclerView.ViewHolder {
        private final ItemDocumentCardBinding binding;

        DocumentViewHolder(@NonNull ItemDocumentCardBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
