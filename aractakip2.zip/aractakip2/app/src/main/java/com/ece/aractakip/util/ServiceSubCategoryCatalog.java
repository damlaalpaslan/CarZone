package com.ece.aractakip.util;

import android.content.Context;

import androidx.annotation.NonNull;

import com.ece.aractakip.R;
import com.ece.aractakip.model.ServiceSubCategoryOption;

import java.util.ArrayList;
import java.util.List;

public final class ServiceSubCategoryCatalog {

    public enum MainCategory {
        PERIODIC,
        REPAIR
    }

    private ServiceSubCategoryCatalog() {
    }

    @NonNull
    public static List<ServiceSubCategoryOption> optionsFor(@NonNull Context context,
                                                            @NonNull MainCategory category) {
        List<ServiceSubCategoryOption> options = new ArrayList<>();
        if (category == MainCategory.PERIODIC) {
            options.add(option(context, R.string.service_op_oil_filter,
                    R.drawable.ic_oil_can, R.color.service_tint_amber, R.color.service_tint_amber_bg));
            options.add(option(context, R.string.service_op_filter_set,
                    R.drawable.ic_air_filter, R.color.service_tint_light_blue, R.color.service_tint_light_blue_bg));
            options.add(option(context, R.string.service_op_brake_fluid,
                    R.drawable.ic_fluid_drop, R.color.service_tint_green, R.color.service_tint_green_bg));
            options.add(option(context, R.string.service_op_spark_plug,
                    R.drawable.ic_spark_plug, R.color.service_tint_yellow, R.color.service_tint_yellow_bg));
            options.add(option(context, R.string.service_op_tire,
                    R.drawable.ic_tire, R.color.service_tint_gray, R.color.service_tint_gray_bg));
            options.add(option(context, R.string.service_custom_operation_option,
                    R.drawable.ic_add, R.color.service_tint_dark_gray, R.color.service_tint_dark_gray_bg));
        } else {
            options.add(option(context, R.string.service_op_brake_disc,
                    R.drawable.ic_brake_disc, R.color.service_tint_red, R.color.service_tint_red_bg));
            options.add(option(context, R.string.service_op_battery,
                    R.drawable.ic_battery, R.color.service_tint_green, R.color.service_tint_green_bg));
            options.add(option(context, R.string.service_op_timing_belt,
                    R.drawable.ic_gears, R.color.service_tint_orange, R.color.service_tint_orange_bg));
            options.add(option(context, R.string.service_op_suspension,
                    R.drawable.ic_suspension, R.color.service_tint_blue, R.color.service_tint_blue_bg));
            options.add(option(context, R.string.service_op_clutch,
                    R.drawable.ic_clutch, R.color.service_tint_purple, R.color.service_tint_purple_bg));
            options.add(option(context, R.string.service_op_headlight,
                    R.drawable.ic_headlight, R.color.service_tint_cyan, R.color.service_tint_cyan_bg));
            options.add(option(context, R.string.service_custom_operation_option,
                    R.drawable.ic_add, R.color.service_tint_dark_gray, R.color.service_tint_dark_gray_bg));
        }
        return options;
    }

    @NonNull
    private static ServiceSubCategoryOption option(@NonNull Context context,
                                                   int labelRes,
                                                   int iconRes,
                                                   int tintRes,
                                                   int bgRes) {
        return new ServiceSubCategoryOption(
                context.getString(labelRes),
                iconRes,
                tintRes,
                bgRes
        );
    }
}
