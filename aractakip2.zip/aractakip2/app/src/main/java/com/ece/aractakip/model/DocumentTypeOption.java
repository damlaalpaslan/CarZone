package com.ece.aractakip.model;

import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.StringRes;

import com.ece.aractakip.R;

public class DocumentTypeOption {

    @NonNull
    private final DocumentEntry.Type type;
    @StringRes
    private final int labelRes;
    @DrawableRes
    private final int iconRes;
    @ColorRes
    private final int iconTintRes;
    @ColorRes
    private final int iconBackgroundRes;

    public DocumentTypeOption(@NonNull DocumentEntry.Type type,
                            @StringRes int labelRes,
                            @DrawableRes int iconRes,
                            @ColorRes int iconTintRes,
                            @ColorRes int iconBackgroundRes) {
        this.type = type;
        this.labelRes = labelRes;
        this.iconRes = iconRes;
        this.iconTintRes = iconTintRes;
        this.iconBackgroundRes = iconBackgroundRes;
    }

    @NonNull
    public DocumentEntry.Type getType() {
        return type;
    }

    @StringRes
    public int getLabelRes() {
        return labelRes;
    }

    @DrawableRes
    public int getIconRes() {
        return iconRes;
    }

    @ColorRes
    public int getIconTintRes() {
        return iconTintRes;
    }

    @ColorRes
    public int getIconBackgroundRes() {
        return iconBackgroundRes;
    }
}
